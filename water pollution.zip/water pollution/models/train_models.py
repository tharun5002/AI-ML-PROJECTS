"""
train_models.py
ENHANCED: Trains ML models with Ensemble VotingClassifier (XGBoost + Random Forest)
for the Smart Water-Borne Disease Monitoring System:
1. Water Quality Classifier (Voting Ensemble: XGBoost + RF + DT)
2. Symptom-based Disease Predictor (Voting Ensemble: XGBoost + RF)

Saves trained models + metadata using joblib for fast loading in the dashboard.
Also trains comparison models (Logistic Regression, Decision Tree) for report comparisons.
Includes hyperparameter tuning via GridSearchCV.
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    RandomForestClassifier, VotingClassifier,
    GradientBoostingClassifier
)
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, f1_score, roc_auc_score, confusion_matrix
from sklearn.preprocessing import LabelEncoder, StandardScaler
import joblib

# XGBoost (optional but recommended)
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
    print('[OK] XGBoost available — will use in ensemble.')
except ImportError:
    XGB_AVAILABLE = False
    print('[WARN] XGBoost not installed. Falling back to GradientBoosting.')

# Add parent dir to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.utils.data_generator import (
    generate_water_quality_data,
    generate_disease_symptom_data,
    DISEASE_NAMES,
    save_datasets,
)

# Config
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'trained_models')
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

RANDOM_STATE = 42


def evaluate_model(model, X_test, y_test, model_name, y_prob=None):
    """Evaluate and print model metrics with ROC AUC."""
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    
    # ROC AUC (for binary classifiers or multiclass OvR)
    if y_prob is not None:
        try:
            if len(np.unique(y_test)) == 2:
                auc = roc_auc_score(y_test, y_prob[:, 1])
            else:
                auc = roc_auc_score(y_test, y_prob, multi_class='ovr', average='weighted')
        except Exception:
            auc = None
    else:
        auc = None

    print()
    print('=' * 50)
    print(f'[METRICS] {model_name}')
    print('=' * 50)
    print(f'Accuracy:   {acc:.4f}')
    print(f'F1 Score:   {f1:.4f}')
    if auc:
        print(f'ROC AUC:    {auc:.4f}')
    print()
    print('Classification Report:')
    print(classification_report(y_test, y_pred, zero_division=0))
    
    # Confusion matrix summary
    cm = confusion_matrix(y_test, y_pred)
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        print(f'Confusion: TN={tn}, FP={fp}, FN={fn}, TP={tp}')
    
    return {'accuracy': acc, 'f1_score': f1, 'roc_auc': float(auc) if auc else None}


def train_water_quality_model():
    """Train Water Potability Classifier with ensemble VotingClassifier."""
    print()
    print('#' * 60)
    print('[WATER] TRAINING WATER QUALITY MODEL (ENSEMBLE)')
    print('#' * 60)

    # Load or generate data
    csv_path = os.path.join(DATA_DIR, 'water_potability.csv')
    if os.path.exists(csv_path):
        print('[LOAD] Loading existing dataset...')
        df = pd.read_csv(csv_path)
    else:
        print('[GEN] Generating synthetic water quality dataset...')
        df = generate_water_quality_data()
        df.to_csv(csv_path, index=False)

    print(f'Dataset: {df.shape[0]} rows, {df.shape[1]} columns')
    print(f'Potable: {df["Potability"].sum()}, Non-potable: {(1 - df["Potability"]).sum()}')

    # Feature columns (all except Potability)
    feature_cols = [c for c in df.columns if c != 'Potability']
    X = df[feature_cols].copy()
    y = df['Potability'].values

    # Handle missing values
    missing_before = X.isnull().sum().sum()
    for col in X.columns:
        if X[col].isnull().any():
            X[col] = X[col].fillna(X[col].median())
    print(f'[CLEAN] Filled {missing_before} missing values with median')

    # Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )
    print(f'Split: {len(X_train)} train, {len(X_test)} test')

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # ── Model 1: Random Forest (baseline) ──
    print()
    print('[RF] Training Random Forest...')
    rf_model = RandomForestClassifier(
        n_estimators=200,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=3,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    rf_model.fit(X_train, y_train)
    rf_results = evaluate_model(rf_model, X_test, y_test, 'Random Forest (Water Quality)',
                                 rf_model.predict_proba(X_test))

    # ── Model 2: XGBoost / Gradient Boosting ──
    print()
    if XGB_AVAILABLE:
        print('[XGB] Training XGBoost...')
        booster_model = XGBClassifier(
            n_estimators=150,
            max_depth=8,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=RANDOM_STATE,
            use_label_encoder=False,
            eval_metric='logloss',
            verbosity=0,
        )
        booster_name = 'XGBoost'
    else:
        print('[GB] Training GradientBoosting (XGBoost not available)...')
        booster_model = GradientBoostingClassifier(
            n_estimators=150, max_depth=6, learning_rate=0.1,
            random_state=RANDOM_STATE
        )
        booster_name = 'GradientBoosting'
    
    booster_model.fit(X_train, y_train)
    booster_results = evaluate_model(booster_model, X_test, y_test,
                                      f'{booster_name} (Water Quality)',
                                      booster_model.predict_proba(X_test))

    # ── Model 3: Logistic Regression (for comparison) ──
    print()
    print('[LR] Training Logistic Regression (comparison)...')
    lr_model = LogisticRegression(max_iter=2000, random_state=RANDOM_STATE)
    lr_model.fit(X_train_scaled, y_train)
    lr_results = evaluate_model(lr_model, X_test_scaled, y_test,
                                 'Logistic Regression (Water Quality)',
                                 lr_model.predict_proba(X_test_scaled))

    # ── Model 4: Decision Tree (for comparison) ──
    print()
    print('[DT] Training Decision Tree (comparison)...')
    dt_model = DecisionTreeClassifier(max_depth=10, random_state=RANDOM_STATE)
    dt_model.fit(X_train, y_train)
    dt_results = evaluate_model(dt_model, X_test, y_test,
                                 'Decision Tree (Water Quality)',
                                 dt_model.predict_proba(X_test))

    # ── ENHANCED: Voting Ensemble Classifier ──
    print()
    print('[ENSEMBLE] Building Voting Classifier...')
    estimators = [
        ('Random Forest', rf_model),
        (booster_name.lower().replace(' ', '_'), booster_model),
        ('Decision Tree', dt_model),
    ]
    
    ensemble_model = VotingClassifier(
        estimators=estimators,
        voting='soft',  # Use probability weights
    )
    ensemble_model.fit(X_train, y_train)
    ensemble_results = evaluate_model(ensemble_model, X_test, y_test,
                                       f'Voting Ensemble (Water Quality)',
                                       ensemble_model.predict_proba(X_test))

    # ── Hyperparameter Tuning (GridSearchCV) ──
    print()
    print('[TUNE] Running GridSearchCV on Random Forest...')
    param_grid = {
        'n_estimators': [100, 200, 300],
        'max_depth': [10, 15, 20],
        'min_samples_split': [2, 5, 10],
    }
    grid_search = GridSearchCV(
        RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=-1),
        param_grid,
        cv=3,
        scoring='accuracy',
        verbose=0,
        n_jobs=-1,
    )
    grid_search.fit(X_train, y_train)
    best_rf = grid_search.best_estimator_
    print(f'[TUNE] Best params: {grid_search.best_params_}')
    print(f'[TUNE] Best CV score: {grid_search.best_score_:.4f}')

    # ── Cross-validation on best model ──
    cv_scores = cross_val_score(best_rf, X, y, cv=5, scoring='accuracy')
    print()
    print(f'[CV] 5-Fold CV Accuracy (Best RF): {cv_scores.mean():.4f} +/- {cv_scores.std():.4f}')

    # ── Feature Importance ──
    importance_df = pd.DataFrame({
        'feature': feature_cols,
        'importance': best_rf.feature_importances_
    }).sort_values('importance', ascending=False)
    print()
    print('[FEAT] Top 5 Features by Importance:')
    for _, row in importance_df.head(5).iterrows():
        print(f'   {row["feature"]}: {row["importance"]:.4f}')

    # Compute confusion matrix for ensemble model
    y_pred_ensemble = ensemble_model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred_ensemble)
    cm_labels = ['Unsafe (0)', 'Safe (1)']
    cm_dict = {
        'matrix': cm.tolist(),
        'labels': cm_labels,
        'tn': int(cm[0, 0]), 'fp': int(cm[0, 1]),
        'fn': int(cm[1, 0]), 'tp': int(cm[1, 1]),
    }

    # Save Model & Metadata
    model_data = {
        'model': ensemble_model,          # Primary: Voting Ensemble
        'best_rf': best_rf,               # Best tuned RF
        'feature_cols': feature_cols,
        'metrics': ensemble_results,
        'confusion_matrix': cm_dict,
        'tuned_rf_metrics': evaluate_model(best_rf, X_test, y_test,
                                            'Best Tuned RF (Water Quality)',
                                            best_rf.predict_proba(X_test)),
        'comparison': {
            'Voting Ensemble': ensemble_results,
            f'{booster_name}': booster_results,
            'Random Forest': rf_results,
            'Logistic Regression': lr_results,
            'Decision Tree': dt_results,
        },
        'cv_score': float(cv_scores.mean()),
        'cv_std': float(cv_scores.std()),
        'grid_search_params': grid_search.best_params_,
        'feature_importance': importance_df.to_dict('records'),
        'is_ensemble': True,
        'ensemble_estimators': estimators,
        'scaler': scaler,
    }
    save_path = os.path.join(MODEL_DIR, 'water_quality_model.pkl')
    joblib.dump(model_data, save_path)
    print()
    print(f'[SAVE] Water model (ensemble) saved to {save_path}')

    return model_data


def train_disease_prediction_model():
    """Train Symptom-based Disease Classifier with ensemble."""
    print()
    print('#' * 60)
    print('[DISEASE] TRAINING DISEASE PREDICTION MODEL (ENSEMBLE)')
    print('#' * 60)

    # Load or generate data
    csv_path = os.path.join(DATA_DIR, 'disease_symptoms.csv')
    if os.path.exists(csv_path):
        print('[LOAD] Loading existing dataset...')
        df = pd.read_csv(csv_path)
    else:
        print('[GEN] Generating synthetic disease-symptom dataset...')
        df = generate_disease_symptom_data()
        df.to_csv(csv_path, index=False)

    # Filter to water-borne diseases only
    available_diseases = [d for d in DISEASE_NAMES if d in df['Disease'].unique()]
    df_filtered = df[df['Disease'].isin(available_diseases)].copy()
    print(f'Dataset: {len(df)} total rows, {len(df_filtered)} filtered to water-borne diseases')
    print(f'Diseases: {available_diseases}')
    print(f'Distribution:')
    print(df_filtered['Disease'].value_counts())

    # Feature Engineering
    symptom_cols = [c for c in df_filtered.columns if c != 'Disease']
    X = df_filtered[symptom_cols].values
    y = df_filtered['Disease'].values

    # Label Encoding
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    print()
    print(f'Label mapping: {dict(zip(le.classes_, le.transform(le.classes_)))}')

    # Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=RANDOM_STATE, stratify=y_encoded
    )
    print(f'Split: {len(X_train)} train, {len(X_test)} test')

    # ── Model 1: Random Forest ──
    print()
    print('[RF] Training Random Forest...')
    rf_model = RandomForestClassifier(
        n_estimators=150,
        max_depth=12,
        min_samples_split=4,
        min_samples_leaf=2,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    rf_model.fit(X_train, y_train)
    rf_acc = accuracy_score(y_test, rf_model.predict(X_test))
    rf_f1 = f1_score(y_test, rf_model.predict(X_test), average='weighted')
    print(f'[RF] Accuracy: {rf_acc:.4f}, F1: {rf_f1:.4f}')

    # ── Model 2: XGBoost / Gradient Boosting ──
    if XGB_AVAILABLE:
        print()
        print('[XGB] Training XGBoost...')
        booster = XGBClassifier(
            n_estimators=120,
            max_depth=7,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=RANDOM_STATE,
            use_label_encoder=False,
            eval_metric='mlogloss',
            verbosity=0,
        )
        booster_name = 'XGBoost'
    else:
        print()
        print('[GB] Training GradientBoosting (XGBoost not available)...')
        booster = GradientBoostingClassifier(
            n_estimators=120, max_depth=5, learning_rate=0.1,
            random_state=RANDOM_STATE
        )
        booster_name = 'GradientBoosting'
    
    booster.fit(X_train, y_train)
    booster_acc = accuracy_score(y_test, booster.predict(X_test))
    booster_f1 = f1_score(y_test, booster.predict(X_test), average='weighted')
    print(f'[{booster_name}] Accuracy: {booster_acc:.4f}, F1: {booster_f1:.4f}')

    # ── Model 3: Decision Tree (comparison) ──
    print()
    print('[DT] Training Decision Tree (comparison)...')
    dt_model = DecisionTreeClassifier(max_depth=8, random_state=RANDOM_STATE)
    dt_model.fit(X_train, y_train)
    dt_acc = accuracy_score(y_test, dt_model.predict(X_test))

    # ── ENHANCED: Voting Ensemble Classifier ──
    print()
    print('[ENSEMBLE] Building Voting Classifier...')
    estimators = [
        ('Random Forest', rf_model),
        (booster_name.lower().replace(' ', '_'), booster),
        ('Decision Tree', dt_model),
    ]
    ensemble_model = VotingClassifier(estimators=estimators, voting='soft')
    ensemble_model.fit(X_train, y_train)
    y_pred_ensemble = ensemble_model.predict(X_test)
    ensemble_acc = accuracy_score(y_test, y_pred_ensemble)
    ensemble_f1 = f1_score(y_test, y_pred_ensemble, average='weighted')
    print(f'[ENSEMBLE] Accuracy: {ensemble_acc:.4f}, F1: {ensemble_f1:.4f}')
    print()
    print('Classification Report (Ensemble):')
    print(classification_report(y_test, y_pred_ensemble, target_names=le.classes_, zero_division=0))

    # ── Cross-validation ──
    cv_scores = cross_val_score(ensemble_model, X, y_encoded, cv=5, scoring='accuracy')
    print()
    print(f'[CV] 5-Fold CV Accuracy (Ensemble): {cv_scores.mean():.4f} +/- {cv_scores.std():.4f}')

    # ── Feature Importance (from RF) ──
    importance_df = pd.DataFrame({
        'symptom': symptom_cols,
        'importance': rf_model.feature_importances_
    }).sort_values('importance', ascending=False)
    print()
    print('[FEAT] Top 5 Symptoms by Importance:')
    for _, row in importance_df.head(5).iterrows():
        print(f'   {row["symptom"]}: {row["importance"]:.4f}')

    # Save Model & Metadata
    model_data = {
        'model': ensemble_model,       # Primary: Voting Ensemble
        'rf_model': rf_model,          # Individual models for explainability
        'booster': booster,
        'label_encoder': le,
        'symptom_cols': symptom_cols,
        'disease_names': available_diseases,
        'metrics': {'accuracy': float(ensemble_acc), 'f1_score': float(ensemble_f1)},
        'comparison': {
            'Voting Ensemble': {'accuracy': float(ensemble_acc), 'f1_score': float(ensemble_f1)},
            f'{booster_name}': {'accuracy': float(booster_acc), 'f1_score': float(booster_f1)},
            'Random Forest': {'accuracy': float(rf_acc), 'f1_score': float(rf_f1)},
            'Decision Tree': {'accuracy': float(dt_acc)},
        },
        'cv_score': float(cv_scores.mean()),
        'cv_std': float(cv_scores.std()),
        'feature_importance': importance_df.to_dict('records'),
        'is_ensemble': True,
    }
    save_path = os.path.join(MODEL_DIR, 'disease_prediction_model.pkl')
    joblib.dump(model_data, save_path)
    print()
    print(f'[SAVE] Disease model (ensemble) saved to {save_path}')

    return model_data


def train_all():
    """Run full training pipeline."""
    print('=' * 60)
    print('SMART COMMUNITY HEALTH MONITORING SYSTEM')
    print('   ENHANCED Model Training Pipeline')
    print('=' * 60)

    # Generate datasets first
    print()
    print('[STEP 1] Generating datasets...')
    save_datasets(DATA_DIR)

    # Train both models
    print()
    print()
    print('[STEP 2] Training water quality model (Voting Ensemble)...')
    water_model = train_water_quality_model()

    print()
    print()
    print('[STEP 3] Training disease prediction model (Voting Ensemble)...')
    disease_model = train_disease_prediction_model()

    # Summary
    print()
    print()
    print('=' * 60)
    print('[SUMMARY] ENHANCED TRAINING SUMMARY')
    print('=' * 60)
    print()
    print('[WATER] Water Quality Model (Voting Ensemble):')
    print(f'   Accuracy: {water_model["metrics"]["accuracy"]:.4f}')
    print(f'   F1 Score: {water_model["metrics"]["f1_score"]:.4f}')
    print(f'   CV Score: {water_model["cv_score"]:.4f} +/- {water_model["cv_std"]:.4f}')
    print(f'   Best RF Params: {water_model["grid_search_params"]}')

    print()
    print('[DISEASE] Disease Prediction Model (Voting Ensemble):')
    print(f'   Accuracy: {disease_model["metrics"]["accuracy"]:.4f}')
    print(f'   F1 Score: {disease_model["metrics"]["f1_score"]:.4f}')
    print(f'   CV Score: {disease_model["cv_score"]:.4f} +/- {disease_model["cv_std"]:.4f}')

    print()
    print('[DONE] Enhanced training complete! Models saved to models/trained_models/')
    return water_model, disease_model


if __name__ == '__main__':
    train_all()
