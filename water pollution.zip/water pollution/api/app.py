"""
api/app.py
ENHANCEMENT 4: FastAPI Backend & Webhook Alert Service
Provides REST API endpoints for:
- POST /predict/water — Water quality prediction
- POST /predict/disease — Disease prediction from symptoms
- POST /predict/combined — Combined outbreak risk assessment
- POST /alert/send — Send SMS alert (Twilio integration)
- GET /health — System health check

Usage:
    uvicorn api.app:app --reload --port 8000
"""

import os
import sys
import json
import warnings
from typing import Optional, List, Dict, Any
from datetime import datetime

warnings.filterwarnings('ignore')

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import joblib
import numpy as np
import pandas as pd

from app.utils.data_generator import WATER_FEATURES, ALL_WATER_BORNE_SYMPTOMS, LOCATIONS
from app.utils.risk_fusion import (
    calculate_risk_score, get_risk_level, get_risk_color,
    apply_severity_weight, get_risk_recommendation
)

# ── App Initialization ──
app = FastAPI(
    title="Aarogya Jal — Health Monitoring API",
    description="REST API for Smart Community Health Monitoring & Early Warning System",
    version="2.0.0",
)

# CORS — allow Streamlit dashboard to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global Model Cache ──
_models = {}


def get_model(model_type: str):
    """Load and cache models."""
    if model_type in _models:
        return _models[model_type]

    model_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'models', 'trained_models'
    )

    paths = {
        'water': os.path.join(model_dir, 'water_quality_model.pkl'),
        'disease': os.path.join(model_dir, 'disease_prediction_model.pkl'),
    }

    path = paths.get(model_type)
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=503, detail=f"Model '{model_type}' not found. Run training first.")

    try:
        model_data = joblib.load(path)
        _models[model_type] = model_data
        return model_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error loading model: {str(e)}")


# ── Request/Response Models ──

class WaterQualityInput(BaseModel):
    ph: float = Field(..., ge=0, le=14, description="pH level (0-14)")
    Hardness: float = Field(..., ge=47, le=323, description="Water hardness (mg/L)")
    Solids: float = Field(..., ge=320, le=61227, description="Total solids (mg/L)")
    Chloramines: float = Field(..., ge=0.4, le=13, description="Chloramines (mg/L)")
    Sulfate: float = Field(..., ge=129, le=481, description="Sulfate (mg/L)")
    Conductivity: float = Field(..., ge=180, le=753, description="Conductivity (μS/cm)")
    Organic_carbon: float = Field(..., ge=2.2, le=28, description="Organic carbon (mg/L)")
    Trihalomethanes: float = Field(..., ge=0.7, le=124, description="Trihalomethanes (μg/L)")
    Turbidity: float = Field(..., ge=1.5, le=6.5, description="Turbidity (NTU)")

    class Config:
        json_schema_extra = {
            "example": {
                "ph": 7.2, "Hardness": 180, "Solids": 15000,
                "Chloramines": 4.5, "Sulfate": 350, "Conductivity": 450,
                "Organic_carbon": 12.0, "Trihalomethanes": 60.0, "Turbidity": 3.5
            }
        }


class SymptomInput(BaseModel):
    symptoms: Dict[str, bool] = Field(
        ..., description="Dictionary of symptom -> presence (True/False)"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "symptoms": {
                    "Fever": True, "Diarrhea": True, "Vomiting": True,
                    "Nausea": False, "Abdominal_Pain": False, "Fatigue": True,
                    "Headache": True, "Dehydration": False, "Jaundice": False,
                    "Loss_of_Appetite": False, "Muscle_Cramps": False,
                    "Bloody_Stool": False, "Dark_Urine": False, "Weakness": False,
                    "Constipation": False
                }
            }
        }


class CombinedInput(BaseModel):
    water: WaterQualityInput
    symptoms: Dict[str, bool]
    location: Optional[str] = "Unknown Location"
    population: Optional[int] = 1000
    case_reports: Optional[int] = 0
    water_weight: Optional[float] = 0.5
    disease_weight: Optional[float] = 0.5


class AlertRequest(BaseModel):
    location: str
    risk_level: str
    risk_score: float
    predicted_disease: Optional[str] = None
    phone_numbers: List[str] = Field(..., description="List of phone numbers to alert")
    message_type: str = Field("sms", pattern="^(sms|email)$")


class PredictionResponse(BaseModel):
    prediction: Any
    confidence: float
    risk_level: Optional[str] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


# ── Twilio Alert Service ──
class AlertService:
    """Send SMS alerts via Twilio when risk exceeds threshold."""

    def __init__(self):
        self.twilio_available = False
        self.client = None
        self._init_twilio()

    def _init_twilio(self):
        """Initialize Twilio client if credentials available."""
        account_sid = os.environ.get('TWILIO_ACCOUNT_SID')
        auth_token = os.environ.get('TWILIO_AUTH_TOKEN')
        self.from_number = os.environ.get('TWILIO_FROM_NUMBER')

        if account_sid and auth_token and self.from_number:
            try:
                from twilio.rest import Client
                self.client = Client(account_sid, auth_token)
                self.twilio_available = True
                print('[ALERT] Twilio SMS service initialized.')
            except Exception as e:
                print(f'[ALERT] Twilio init failed: {e}')
        else:
            print('[ALERT] Twilio not configured. Alerts will be logged only.')

    def send_alert(self, location: str, risk_level: str, risk_score: float,
                   predicted_disease: Optional[str] = None,
                   phone_numbers: Optional[List[str]] = None):
        """
        Send alert notification. Falls back to logging if Twilio not configured.

        Args:
            location: Location name
            risk_level: LOW / MEDIUM / HIGH
            risk_score: Numerical risk score (0-1)
            predicted_disease: Optional disease name
            phone_numbers: List of recipient phone numbers

        Returns:
            dict with status and message
        """
        # Build alert message
        if risk_level == 'HIGH':
            emoji = '🚨'
            urgency = 'URGENT'
        elif risk_level == 'MEDIUM':
            emoji = '⚠️'
            urgency = 'CAUTION'
        else:
            emoji = '✅'
            urgency = 'INFO'

        message = (
            f"{emoji} AAROGYA JAL {urgency}: {location}\n"
            f"Risk Level: {risk_level} ({risk_score:.0%})\n"
        )
        if predicted_disease:
            message += f"Suspected: {predicted_disease}\n"

        message += (
            f"\nActions required based on risk level.\n"
            f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )

        result = {
            'status': 'logged',
            'message': message,
            'risk_level': risk_level,
            'location': location,
            'recipients': phone_numbers or [],
        }

        # Send via Twilio if available
        if self.twilio_available and phone_numbers:
            sent_count = 0
            for number in phone_numbers:
                try:
                    self.client.messages.create(
                        body=message[:1600],  # SMS length limit
                        from_=self.from_number,
                        to=number
                    )
                    sent_count += 1
                except Exception as e:
                    print(f'[ALERT] Failed to send to {number}: {e}')

            result['status'] = 'sent'
            result['sent_count'] = sent_count

        # Save alert to log file
        log_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            'data', 'api_alert_log.csv'
        )
        try:
            log_entry = pd.DataFrame([{
                'timestamp': datetime.now().isoformat(),
                'location': location,
                'risk_level': risk_level,
                'risk_score': risk_score,
                'disease': predicted_disease or '',
                'status': result['status'],
            }])
            if os.path.exists(log_path):
                existing = pd.read_csv(log_path)
                log_entry = pd.concat([existing, log_entry], ignore_index=True)
            log_entry.to_csv(log_path, index=False)
        except Exception:
            pass

        return result


alert_service = AlertService()


# ── API Endpoints ──

@app.get("/")
def root():
    """API root with available endpoints."""
    return {
        "name": "Aarogya Jal API",
        "version": "2.0.0",
        "endpoints": {
            "GET /health": "System health check",
            "POST /predict/water": "Predict water potability",
            "POST /predict/disease": "Predict disease from symptoms",
            "POST /predict/combined": "Combined outbreak risk assessment",
            "POST /alert/send": "Send SMS alert via Twilio",
        },
        "status": "operational" if os.path.exists(
            os.path.join(os.path.dirname(os.path.dirname(__file__)),
                         'models', 'trained_models', 'water_quality_model.pkl')
        ) else "models_not_trained",
    }


@app.get("/health")
def health_check():
    """Health check endpoint."""
    model_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'models', 'trained_models'
    )
    water_ok = os.path.exists(os.path.join(model_dir, 'water_quality_model.pkl'))
    disease_ok = os.path.exists(os.path.join(model_dir, 'disease_prediction_model.pkl'))

    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "models": {
            "water_quality": "loaded" if water_ok else "missing",
            "disease_prediction": "loaded" if disease_ok else "missing",
        },
        "twilio_configured": alert_service.twilio_available,
    }


@app.post("/predict/water", response_model=PredictionResponse)
def predict_water(data: WaterQualityInput):
    """
    Predict whether water is potable (safe to drink).
    Returns probability and contamination risk.
    """
    model_data = get_model('water')
    model = model_data['model']  # Voting Ensemble
    feature_cols = model_data['feature_cols']

    # Build input DataFrame
    input_dict = data.model_dump()
    input_df = pd.DataFrame([input_dict])[feature_cols]

    # Fill missing with median
    for col in feature_cols:
        if col in input_df.columns and input_df[col].isnull().any():
            input_df[col] = input_df[col].fillna(input_df[col].median())

    # Predict
    prob_potable = float(model.predict_proba(input_df)[0][1])
    is_potable = prob_potable >= 0.5
    contamination_prob = 1 - prob_potable

    # Get feature importance for explanation
    if hasattr(model, 'estimators_'):
        # For VotingClassifier, use first estimator's feature importances
        first_est = model.estimators_[0] if hasattr(model, 'estimators_') else None
        if hasattr(first_est, 'feature_importances_'):
            importance = first_est.feature_importances_
            top_features = sorted(
                [{'feature': f, 'importance': float(imp)}
                 for f, imp in zip(feature_cols, importance)],
                key=lambda x: x['importance'], reverse=True
            )[:5]
        else:
            top_features = []
    else:
        top_features = []

    return PredictionResponse(
        prediction={
            "potable": bool(is_potable),
            "contamination_risk": round(contamination_prob, 4),
            "potability_probability": round(prob_potable, 4),
        },
        confidence=round(max(prob_potable, 1 - prob_potable), 4),
        risk_level=get_risk_level(contamination_prob),
    )


@app.post("/predict/disease", response_model=PredictionResponse)
def predict_disease(data: SymptomInput):
    """
    Predict water-borne disease from reported symptoms.
    Returns disease name, confidence, and probability distribution.
    """
    model_data = get_model('disease')
    model = model_data['model']  # Voting Ensemble
    symptom_cols = model_data['symptom_cols']
    label_encoder = model_data['label_encoder']

    # Build input
    symptom_dict = {s: 0 for s in symptom_cols}
    for sym, present in data.symptoms.items():
        if sym in symptom_dict:
            symptom_dict[sym] = 1 if present else 0

    input_df = pd.DataFrame([symptom_dict])[symptom_cols]

    # Predict
    probas = model.predict_proba(input_df)[0]
    pred_idx = int(np.argmax(probas))
    predicted_disease = label_encoder.inverse_transform([pred_idx])[0]
    confidence = float(probas[pred_idx])

    # Probability distribution
    prob_dist = {
        label_encoder.inverse_transform([i])[0]: float(probas[i])
        for i in range(len(probas))
    }

    return PredictionResponse(
        prediction={
            "disease": predicted_disease,
            "probability_distribution": prob_dist,
        },
        confidence=confidence,
    )


@app.post("/predict/combined")
def predict_combined(data: CombinedInput):
    """
    Combined outbreak risk assessment.
    Fuses water quality and disease predictions into unified risk score.
    """
    # 1. Water Quality Prediction
    water_model_data = get_model('water')
    water_model = water_model_data['model']
    feature_cols = water_model_data['feature_cols']

    water_dict = data.water.model_dump()
    water_df = pd.DataFrame([water_dict])[feature_cols]
    for col in feature_cols:
        if col in water_df.columns and water_df[col].isnull().any():
            water_df[col] = water_df[col].fillna(water_df[col].median())

    water_prob_potable = float(water_model.predict_proba(water_df)[0][1])
    contamination_prob = 1 - water_prob_potable

    # 2. Disease Prediction
    disease_model_data = get_model('disease')
    disease_model = disease_model_data['model']
    symptom_cols = disease_model_data['symptom_cols']
    label_encoder = disease_model_data['label_encoder']

    symptom_dict = {s: 0 for s in symptom_cols}
    for sym, present in data.symptoms.items():
        if sym in symptom_dict:
            symptom_dict[sym] = 1 if present else 0

    symptom_df = pd.DataFrame([symptom_dict])[symptom_cols]
    probas = disease_model.predict_proba(symptom_df)[0]
    pred_idx = int(np.argmax(probas))
    predicted_disease = label_encoder.inverse_transform([pred_idx])[0]
    disease_confidence = float(probas[pred_idx])

    # 3. Risk Fusion
    adjusted_disease_prob = apply_severity_weight(disease_confidence, predicted_disease)
    combined_score, risk_level, risk_details = calculate_risk_score(
        contamination_prob,
        adjusted_disease_prob,
        data.water_weight,
        data.disease_weight,
    )

    # 4. Recommendations
    is_safe = contamination_prob < 0.5
    rec = get_risk_recommendation(risk_level, predicted_disease, is_safe)

    # 5. Adaptive risk (with population data)
    from app.utils.risk_fusion import calculate_adaptive_risk
    adaptive_score, adaptive_level, adaptive_details = calculate_adaptive_risk(
        contamination_prob, adjusted_disease_prob,
        case_reports=data.case_reports,
        population=data.population,
    )

    # Auto-send alert if HIGH risk
    alert_sent = False
    if risk_level == 'HIGH':
        alert_result = alert_service.send_alert(
            location=data.location,
            risk_level=risk_level,
            risk_score=combined_score,
            predicted_disease=predicted_disease,
        )
        alert_sent = alert_result['status'] == 'sent'

    return {
        "combined_risk": {
            "score": round(combined_score, 4),
            "level": risk_level,
            "color": get_risk_color(combined_score),
        },
        "adaptive_risk": {
            "score": round(adaptive_score, 4),
            "level": adaptive_level,
        },
        "water_quality": {
            "potable": contamination_prob < 0.5,
            "contamination_probability": round(contamination_prob, 4),
        },
        "disease_prediction": {
            "disease": predicted_disease,
            "confidence": round(disease_confidence, 4),
        },
        "risk_components": risk_details,
        "recommendations": rec,
        "alert_sent": alert_sent,
        "timestamp": datetime.now().isoformat(),
    }


@app.post("/alert/send")
def send_alert(request: AlertRequest, background_tasks: BackgroundTasks):
    """
    Send an SMS alert via Twilio (or log if not configured).
    Triggers automatically on HIGH risk but can also be called manually.
    """
    if not request.phone_numbers:
        raise HTTPException(status_code=400, detail="At least one phone number required")

    # Send in background
    background_tasks.add_task(
        alert_service.send_alert,
        location=request.location,
        risk_level=request.risk_level,
        risk_score=request.risk_score,
        predicted_disease=request.predicted_disease,
        phone_numbers=request.phone_numbers,
    )

    return {
        "status": "queued",
        "message": f"Alert queued for {len(request.phone_numbers)} recipient(s)",
        "location": request.location,
        "risk_level": request.risk_level,
    }


@app.get("/locations")
def list_locations():
    """List all monitored locations with metadata."""
    return {
        "locations": [
            {
                "name": loc['name'],
                "lat": loc['lat'],
                "lon": loc['lon'],
                "population": loc['population'],
            }
            for loc in LOCATIONS
        ],
        "count": len(LOCATIONS),
    }


@app.get("/models/info")
def model_info():
    """Get model metadata and performance metrics."""
    try:
        water = get_model('water')
        disease = get_model('disease')

        return {
            "water_quality_model": {
                "type": "Voting Ensemble (RF + XGBoost + DT)",
                "metrics": water.get('metrics', {}),
                "comparison": water.get('comparison', {}),
                "cv_score": water.get('cv_score'),
                "top_features": water.get('feature_importance', [])[:5],
            },
            "disease_prediction_model": {
                "type": "Voting Ensemble (RF + XGBoost + DT)",
                "metrics": disease.get('metrics', {}),
                "comparison": disease.get('comparison', {}),
                "cv_score": disease.get('cv_score'),
                "diseases": disease.get('disease_names', []),
                "top_symptoms": disease.get('feature_importance', [])[:5],
            },
        }
    except HTTPException:
        return {"status": "models_not_loaded"}


if __name__ == '__main__':
    import uvicorn
    print("[API] Starting Aarogya Jal API server...")
    print("[API] Docs: http://localhost:8000/docs")
    uvicorn.run(app, host='0.0.0.0', port=8000)
