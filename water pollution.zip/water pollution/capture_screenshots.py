"""Capture full-page screenshots of all 5 Aarogya Jal pages using Playwright."""
import asyncio
import os
from playwright.async_api import async_playwright

BASE_URL = "http://localhost:8521"
OUTPUT_DIR = "screenshots"
os.makedirs(OUTPUT_DIR, exist_ok=True)

PAGES = [
    {"name": "Overview Dashboard", "url": BASE_URL, "file": "01_overview.png"},
    {"name": "Location Detail & Analysis", "url": f"{BASE_URL}/Location_Detail_&_Analysis", "file": "02_location_detail.png"},
    {"name": "Data Analysis & Upload", "url": f"{BASE_URL}/Data_Analysis_&_Upload", "file": "03_data_analysis.png"},
    {"name": "Alerts Log", "url": f"{BASE_URL}/Alerts_Log", "file": "04_alerts_log.png"},
    {"name": "About & Methodology", "url": f"{BASE_URL}/About_&_Methodology", "file": "05_about.png"},
]


async def capture_all():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=2,
        )
        page = await context.new_page()

        for pg in PAGES:
            print(f"Capturing: {pg['name']} ...")
            await page.goto(pg["url"], wait_until="networkidle", timeout=60000)
            await page.wait_for_timeout(5000)

            # Take full-page screenshot
            path = os.path.join(OUTPUT_DIR, pg["file"])
            await page.screenshot(path=path, full_page=True)
            print(f"  Saved: {path}")

        await browser.close()
    print("\nAll screenshots captured successfully!")


if __name__ == "__main__":
    asyncio.run(capture_all())
