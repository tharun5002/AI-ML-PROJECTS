"""
generate_docs_pdf.py
Generate a comprehensive PDF document for the Aarogya Jal application.
Includes full documentation with screenshots of all 5 pages.
"""

import os
from fpdf import FPDF
from datetime import datetime

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOTS_DIR = os.path.join(OUTPUT_DIR, "screenshots")


class AarogyaJalPDF(FPDF):
    """Custom PDF class with header/footer for Aarogya Jal documentation."""

    def header(self):
        if self.page_no() > 1:
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(200, 200, 200)
            self.cell(0, 8, "Aarogya Jal - Smart Community Health Monitoring & Early Warning System", align="C")
            self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

    def chapter_title(self, title, level=1):
        """Add a chapter title."""
        if level == 1:
            self.set_font("Helvetica", "B", 22)
            self.set_text_color(0, 102, 204)
            self.cell(0, 15, title, new_x="LMARGIN", new_y="NEXT")
            self.set_draw_color(0, 102, 204)
            self.line(10, self.get_y(), 200, self.get_y())
            self.ln(8)
        elif level == 2:
            self.set_font("Helvetica", "B", 16)
            self.set_text_color(50, 50, 50)
            self.cell(0, 12, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(4)
        elif level == 3:
            self.set_font("Helvetica", "B", 13)
            self.set_text_color(80, 80, 80)
            self.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(2)

    def body_text(self, text):
        """Add body paragraph."""
        self.set_font("Helvetica", "", 10)
        self.set_text_color(40, 40, 40)
        self.multi_cell(0, 6, text)
        self.ln(2)

    def bullet_point(self, text, indent=15):
        """Add a bullet point."""
        self.set_font("Helvetica", "", 10)
        self.set_text_color(40, 40, 40)
        x = self.get_x()
        self.cell(indent, 6, "", new_x="END")
        self.set_font("Helvetica", "", 10)
        self.cell(5, 6, "-")
        self.multi_cell(0, 6, f"  {text}")
        self.ln(1)

    def code_block(self, text):
        """Add a code block with monospace font and background."""
        self.set_fill_color(240, 240, 245)
        self.set_font("Courier", "", 8)
        self.set_text_color(50, 50, 50)
        for line in text.split("\n"):
            self.cell(0, 5, f"  {line}", new_x="LMARGIN", new_y="NEXT", fill=True)
        self.ln(4)

    def info_box(self, title, text):
        """Add an info/tip box."""
        self.set_fill_color(230, 245, 255)
        self.set_draw_color(0, 150, 255)
        y_before = self.get_y()
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(0, 100, 200)
        self.set_x(15)
        self.cell(0, 7, f"  {title}", new_x="LMARGIN", new_y="NEXT", fill=True)
        self.set_font("Helvetica", "", 9)
        self.set_text_color(30, 30, 30)
        self.set_x(15)
        self.multi_cell(self.w - 30, 5, f"  {text}", fill=True)
        self.ln(4)

    def add_screenshot(self, image_path, caption, w=170):
        """Add a screenshot image with caption."""
        if os.path.exists(image_path):
            x = (self.w - w) / 2
            self.image(image_path, x=x, w=w)
            self.ln(2)
            self.set_font("Helvetica", "I", 9)
            self.set_text_color(100, 100, 100)
            self.cell(0, 6, caption, align="C", new_x="LMARGIN", new_y="NEXT")
            self.ln(6)
        else:
            self.set_font("Helvetica", "I", 10)
            self.set_text_color(200, 0, 0)
            self.cell(0, 10, f"[Image not found: {image_path}]", new_x="LMARGIN", new_y="NEXT")

    def table_row(self, cells, bold=False, fill=False):
        """Add a table row."""
        w = [40, 50, 100]
        self.set_font("Helvetica", "B" if bold else "", 9)
        self.set_text_color(40, 40, 40)
        if fill:
            self.set_fill_color(235, 240, 255)
        else:
            self.set_fill_color(255, 255, 255)
        for i, cell in enumerate(cells):
            self.cell(w[i], 7, cell, border=1, fill=True)
        self.ln()


def generate_pdf():
    """Generate the complete PDF document."""
    pdf = AarogyaJalPDF("P", "mm", "A4")
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(auto=True, margin=20)

    # ═══════════════════════════════════════════
    # COVER PAGE
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.ln(50)
    pdf.set_font("Helvetica", "B", 48)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 20, "AAROGYA JAL", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.set_font("Helvetica", "", 16)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(0, 12, "Smart Community Health Monitoring", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 12, "& Early Warning System", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(10)
    pdf.set_draw_color(0, 102, 204)
    pdf.set_line_width(1)
    mid = pdf.w / 2
    pdf.line(mid - 30, pdf.get_y(), mid + 30, pdf.get_y())
    pdf.ln(15)

    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 8, "An AI/ML-Powered Water Quality Monitoring and Disease Outbreak", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "Prediction Platform for Smart Communities", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(20)

    pdf.set_font("Helvetica", "", 11)
    pdf.set_text_color(120, 120, 120)
    pdf.cell(0, 7, f"Documentation Version 2.0.0", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 7, f"Generated: {datetime.now().strftime('%B %d, %Y')}", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(30)
    pdf.set_font("Helvetica", "I", 10)
    pdf.set_text_color(150, 150, 150)
    pdf.cell(0, 7, "Developed with Python, Streamlit, Scikit-learn, and Plotly", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 7, "(c) 2026 HealthTech Solutions", align="C", new_x="LMARGIN", new_y="NEXT")

    # ═══════════════════════════════════════════
    # TABLE OF CONTENTS
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("Table of Contents", level=1)

    toc_entries = [
        ("1.", "Introduction & Project Overview", "3"),
        ("2.", "App Architecture & Main Entry Point (app/app.py)", "5"),
        ("3.", "Page 1: Overview Dashboard", "8"),
        ("4.", "Page 2: Location Detail & Analysis", "11"),
        ("5.", "Page 3: Data Analysis & Upload", "15"),
        ("6.", "Page 4: Alerts Log", "18"),
        ("7.", "Page 5: About & Methodology", "20"),
        ("8.", "Utility Modules", "22"),
        ("9.", "Machine Learning Models", "26"),
        ("10.", "How to Run the Application", "28"),
        ("Appendix A:", "Screenshots Gallery", "29"),
        ("Appendix B:", "Technical Specifications", "33"),
    ]
    for num, title, page in toc_entries:
        pdf.set_font("Helvetica", "", 11)
        pdf.set_text_color(40, 40, 40)
        dots = "." * (70 - len(num) - len(title))
        pdf.cell(0, 8, f"  {num}  {title}  {dots}  {page}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(10)

    # ═══════════════════════════════════════════
    # CHAPTER 1: INTRODUCTION
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("1. Introduction & Project Overview")

    pdf.body_text(
        "Aarogya Jal (meaning 'Health Water' in Hindi) is a Smart Community Health Monitoring "
        "& Early Warning System designed to monitor water quality and predict disease outbreaks "
        "in real-time. The application uses a Voting Ensemble Machine Learning model "
        "(XGBoost + Random Forest + Decision Tree) to predict water potability and assess "
        "community health risks across 8 monitored locations in India."
    )

    pdf.chapter_title("1.1 Project Objectives", level=2)
    pdf.bullet_point("Monitor water quality parameters (pH, Hardness, Solids, Chloramines, etc.) across multiple community locations")
    pdf.bullet_point("Predict water potability status (Safe/Unsafe) using ensemble ML models")
    pdf.bullet_point("Forecast disease outbreaks based on symptom reports and water quality data")
    pdf.bullet_point("Provide real-time risk assessment with explainable AI (SHAP-based feature importance)")
    pdf.bullet_point("Generate actionable recommendations for community health officials")
    pdf.bullet_point("Offer 14-day risk forecasting using Facebook Prophet time-series model")
    pdf.bullet_point("Enable causal 'What-If' analysis to evaluate intervention effectiveness")

    pdf.chapter_title("1.2 Tech Stack", level=2)
    pdf.table_row(["Component", "Technology", "Purpose"], bold=True, fill=True)
    pdf.table_row(["Frontend", "Streamlit", "Interactive web dashboard UI"])
    pdf.table_row(["ML Models", "Scikit-learn", "Random Forest, XGBoost, Decision Tree"])
    pdf.table_row(["Ensemble", "VotingClassifier", "Combines 3 models for better accuracy"])
    pdf.table_row(["Time-Series", "Facebook Prophet", "14-day risk forecasting"])
    pdf.table_row(["Causal Inference", "DoWhy", "What-If intervention analysis"])
    pdf.table_row(["Explainability", "SHAP", "Feature importance explanation"])
    pdf.table_row(["Visualization", "Plotly", "Interactive charts, maps, gauges"])
    pdf.table_row(["Data", "Pandas/NumPy", "Data manipulation and analysis"])
    pdf.table_row(["Styling", "Custom CSS", "Dark theme with terracotta accents"])
    pdf.table_row(["PDF Generation", "FPDF2", "Documentation export"])

    pdf.chapter_title("1.3 System Architecture", level=2)
    pdf.body_text(
        "The application follows a modular architecture with clear separation of concerns:"
    )
    pdf.bullet_point("app/app.py: Main entry point - loads models, renders header/sidebar, manages navigation")
    pdf.bullet_point("app/pages/: 5 individual page modules (Overview, Location Detail, Data Analysis, Alerts, About)")
    pdf.bullet_point("app/utils/: 6 utility modules (Data Generation, Risk Fusion, Forecasting, Explainability, Recommendations, Causal Analysis)")
    pdf.bullet_point("models/: Model training script and saved model pickle files")
    pdf.bullet_point("data/: CSV data files (simulated timeline, alert logs, water quality data)")
    pdf.bullet_point("app/assets/: Custom CSS stylesheet for theming")

    pdf.chapter_title("1.4 Monitored Locations", level=2)
    pdf.body_text(
        "The system monitors 8 locations across India. These represent diverse geographic "
        "regions with varying water quality challenges:"
    )
    locations = [
        ("Nandgaon", "Uttar Pradesh", "~45,000 population"),
        ("Jalgaon", "Maharashtra", "~55,000 population"),
        ("Sundarbans", "West Bengal", "~35,000 population"),
        ("Rishikesh", "Uttarakhand", "~65,000 population"),
        ("Bhopal", "Madhya Pradesh", "~50,000 population"),
        ("Chennai", "Tamil Nadu", "~60,000 population"),
        ("Guwahati", "Assam", "~40,000 population"),
        ("Varanasi", "Uttar Pradesh", "~70,000 population"),
    ]
    for name, state, pop in locations:
        pdf.bullet_point(f"{name}, {state} ({pop})")

    # Add Overview Screenshot
    pdf.add_page()
    pdf.chapter_title("1.5 Application Screenshot - Overview", level=2)
    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "01_overview.png"),
        "Figure 1: The Overview Dashboard landing page showing summary cards, geographic risk map, and trend charts.",
        w=170,
    )

    # ═══════════════════════════════════════════
    # CHAPTER 2: APP STRUCTURE
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("2. App Architecture & Main Entry Point")
    pdf.chapter_title("2.1 File: app/app.py - The Main Entry Point", level=2)

    pdf.body_text(
        "app/app.py is the brain of the application. It is the first file executed when "
        "you run 'streamlit run app/app.py'. It performs the following critical functions:"
    )

    pdf.chapter_title("2.1.1 Page Configuration", level=3)
    pdf.body_text(
        "The Streamlit page configuration is set at the very top of the file. This must be "
        "the first Streamlit command called. It configures:"
    )
    pdf.bullet_point("page_title='Aarogya Jal - Health Monitoring System' - The browser tab title")
    pdf.bullet_point("page_icon=':droplet:' - The emoji icon shown in the browser tab")
    pdf.bullet_point("layout='wide' - Uses the full browser width for more spacious layouts")
    pdf.bullet_point("initial_sidebar_state='expanded' - Sidebar is open by default")

    pdf.chapter_title("2.1.2 CSS Loading Function (load_css)", level=3)
    pdf.body_text(
        "The load_css() function reads the custom CSS file from app/assets/style.css and "
        "injects it into the Streamlit page using st.markdown() with unsafe_allow_html=True. "
        "The CSS file implements the dark theme with terracotta accent colors, custom card "
        "styles, metric cards, sidebar styling, button designs, animations, and responsive layouts. "
        "The file is opened with UTF-8 encoding to handle special characters properly on Windows."
    )

    pdf.chapter_title("2.1.3 Session State Initialization", level=3)
    pdf.body_text(
        "Streamlit's session state acts as the application's short-term memory. The following "
        "session variables are initialized at startup:"
    )
    states = [
        ("models_loaded (bool=False)", "Tracks whether ML models have been loaded into memory"),
        ("water_model (None)", "Stores the loaded water quality prediction model object"),
        ("disease_model (None)", "Stores the loaded disease prediction model object"),
        ("timeline_data (None)", "Holds the simulated timeline DataFrame for all locations"),
        ("alert_data (None)", "Holds the alert log entries DataFrame"),
        ("current_location (str)", "The currently selected location name (defaults to first location)"),
        ("prediction_history (list=[])", "Accumulates past prediction results for reference"),
    ]
    for var, desc in states:
        pdf.bullet_point(f"{var}: {desc}")

    pdf.chapter_title("2.1.4 Model Loading (load_models)", level=3)
    pdf.body_text(
        "The @st.cache_resource decorator caches the loaded models so they are only loaded "
        "once and reused across page navigations. The function:"
    )
    pdf.bullet_point("Looks for pickle files in models/trained_models/ directory")
    pdf.bullet_point("Loads water_quality_model.pkl using joblib.load()")
    pdf.bullet_point("Loads disease_prediction_model.pkl using joblib.load()")
    pdf.bullet_point("Returns both models, or None and an error message if files are missing")
    pdf.bullet_point("Uses try/except to handle corrupt or incompatible pickle files gracefully")

    pdf.chapter_title("2.1.5 Data Loading (load_data)", level=3)
    pdf.body_text(
        "Also cached, this function loads the simulated data from CSV files:"
    )
    pdf.bullet_point("Reads data/simulated_timeline.csv - Historical timeline of risk scores and cases across all locations")
    pdf.bullet_point("Reads data/alert_log.csv - Log of alert events with timestamps, triggers, and risk levels")
    pdf.bullet_point("Returns None for missing files instead of crashing")

    pdf.chapter_title("2.1.6 Header Rendering (render_header)", level=3)
    pdf.body_text(
        "The header function renders the top bar of the application using HTML/CSS. It displays:"
    )
    pdf.bullet_point("A water droplet emoji icon next to the 'Aarogya Jal' title")
    pdf.bullet_point("The subtitle 'Smart Community Health Monitoring & Early Warning System'")
    pdf.bullet_point("A green 'System Active' badge with a pulse animation indicating the app is running")

    pdf.chapter_title("2.1.7 Sidebar Rendering (render_sidebar)", level=3)
    pdf.body_text(
        "The sidebar is the main navigation and information hub. It contains:"
    )
    pdf.bullet_point("Brand logo with app name in large font")
    pdf.bullet_point("Location selector dropdown - Choose from 8 monitored locations")
    pdf.bullet_point("Location info card - Shows population count and GPS coordinates")
    pdf.bullet_point("System status section - Shows 'Models loaded' and 'Monitoring running' with checkmarks")
    pdf.bullet_point("Quick stats section - Current risk, average risk, and total 30-day cases for the selected location")
    pdf.bullet_point("API access section - Shows REST API endpoint info with uvicorn command")
    pdf.bullet_point("Model type indicator - Shows 'Voting Ensemble Active (XGBoost + RF + DT)' badge")
    pdf.bullet_point("Version footer - Version 2.0.0 and copyright")

    pdf.chapter_title("2.1.8 Navigation System", level=3)
    pdf.body_text(
        "The application uses Streamlit's built-in st.navigation() system with 5 pages:"
    )
    pdf.bullet_point("Page 1: 'Overview Dashboard' - st.Page('pages/overview.py') with icon ':bar_chart:' (default)")
    pdf.bullet_point("Page 2: 'Location Detail & Analysis' - st.Page('pages/location_detail.py') with icon ':microscope:'")
    pdf.bullet_point("Page 3: 'Data Analysis & Upload' - st.Page('pages/data_analysis.py') with icon ':file_folder:'")
    pdf.bullet_point("Page 4: 'Alerts Log' - st.Page('pages/alerts_log.py') with icon ':rotating_light:'")
    pdf.bullet_point("Page 5: 'About & Methodology' - st.Page('pages/about.py') with icon ':information_source:'")

    pdf.chapter_title("2.1.9 Visual Effects", level=3)
    pdf.body_text(
        "The main() function also injects decorative HTML elements for visual appeal:"
    )
    pdf.bullet_point("Ambient background layer with subtle animated water droplets")
    pdf.bullet_point("Water tap animation - an L-shaped pipe with animated water stream and falling drops")
    pdf.bullet_point("Wave container with 3 layered CSS wave animations at the bottom of the screen")
    pdf.bullet_point("These create an immersive water-themed visual experience")

    pdf.add_page()
    pdf.chapter_title("2.2 Startup Flow", level=2)
    pdf.body_text("When the application starts, the main() function executes these steps in order:")
    pdf.code_block(
        "1. Check if models are loaded -> if not:\n"
        "    2. Call load_models() -> returns water_model, disease_model, error\n"
        "    3. If error: Display error message and suggest running train_models.py\n"
        "    4. If success: Store models in session state, set models_loaded=True\n"
        "    5. Call load_data() -> returns timeline, alerts\n"
        "    6. Store timeline and alerts in session state\n"
        "7. Call render_header() -> Display top bar with title and badge\n"
        "8. Inject decorative visual elements (waves, water tap)\n"
        "9. Call render_sidebar() -> Display sidebar with all sections\n"
        "10. Set up st.navigation() with all 5 pages\n"
        "11. Call pg.run() -> Run the active page based on sidebar selection"
    )

    # ═══════════════════════════════════════════
    # CHAPTER 3: OVERVIEW DASHBOARD
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("3. Page 1: Overview Dashboard")
    pdf.chapter_title("3.1 File: app/pages/overview.py", level=2)

    pdf.body_text(
        "The Overview Dashboard is the default landing page when the application starts. "
        "It gives a bird's-eye view of the entire system's current status across all monitored locations."
    )

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "01_overview.png"),
        "Figure 2: The Overview Dashboard - geographic risk map and metric cards.",
        w=170,
    )

    pdf.chapter_title("3.2 Summary Metric Cards (render_summary_cards)", level=2)
    pdf.body_text(
        "The top row displays 4 metric cards that give an instant snapshot of system status:"
    )

    pdf.chapter_title("Card 1: Current Risk Level", level=3)
    pdf.body_text(
        "Shows the current risk level for the selected location. The risk score ranges from 0% to 100% "
        "and is classified into three levels:"
    )
    pdf.bullet_point("LOW (0-35%): Displayed in green with a shield emoji")
    pdf.bullet_point("MEDIUM (35-65%): Displayed in yellow with a warning emoji")
    pdf.bullet_point("HIGH (65-100%): Displayed in red with a alarm bell emoji")
    pdf.body_text("The card shows the risk level name, the exact percentage score, and uses color coding for instant visual recognition.")

    pdf.chapter_title("Card 2: Active Alerts (7d)", level=3)
    pdf.body_text(
        "Counts how many alert-worthy events (risk score >= 45%) occurred in the last 7 days. "
        "Also shows the total number of monitored locations. The card turns red when active alerts exist, "
        "or green when there are no alerts, providing immediate visual feedback."
    )

    pdf.chapter_title("Card 3: Reported Cases (30d)", level=3)
    pdf.body_text(
        "Shows the total number of disease cases reported in the last 30 days for the selected location. "
        "This aggregates daily case counts from the timeline data to show the cumulative burden."
    )

    pdf.chapter_title("Card 4: Risk Trend", level=3)
    pdf.body_text(
        "Compares the average risk score of the last 7 days against the previous 7 days (14-day window). "
        "Three possible trends are shown:"
    )
    pdf.bullet_point(":arrow_up: Rising (red) - Recent risk is higher, indicating deterioration")
    pdf.bullet_point(":arrow_down: Stable (green) - Recent risk is lower, indicating improvement")
    pdf.bullet_point(":left_right_arrow: Flat (gray) - No significant change in risk level")
    pdf.body_text("Also shows the date of the last update.")

    pdf.chapter_title("3.3 Geographic Risk Map (render_map_view)", level=2)
    pdf.body_text(
        "The map renders an interactive Plotly map centered on India (lat: 22.5, lon: 80.0) "
        "with zoom level 4.5. Each of the 8 locations is plotted as a circle marker:"
    )
    pdf.bullet_point("Circle size is proportional to the risk score (15 + risk_score * 30)")
    pdf.bullet_point("Circle color corresponds to risk level (green/yellow/red)")
    pdf.bullet_point("The currently selected location has full opacity; others are slightly transparent (60%)")
    pdf.bullet_point("Hovering over a marker shows a tooltip with: Location name, Risk level with percentage, Population, Cases (30d)")
    pdf.bullet_point("Location names are displayed as text labels above each marker")
    pdf.bullet_point("A legend below the map explains the color coding")

    pdf.chapter_title("3.4 Quick Recommendation Panel (render_quick_recs)", level=2)
    pdf.body_text(
        "Beside the map, this panel shows a contextual recommendation based on the current risk level. "
        "The recommendation is displayed in a color-coded card:"
    )
    pdf.bullet_point("LOW risk: Shows a green card with celebration emoji and 'No Action Needed' message")
    pdf.bullet_point("MEDIUM risk: Shows a yellow card with warning emoji and 'Prepare Response' message")
    pdf.bullet_point("HIGH risk: Shows a red card with alarm emoji and 'Immediate Action Required' message")
    pdf.body_text(
        "A 'View Full Response Plan' button below navigates to the Location Detail page. "
        "Additionally, a Quick Summary info card shows the current risk score, population, "
        "30-day cases, and risk level for the selected location."
    )

    pdf.chapter_title("3.5 Risk & Case Trend Chart (render_trend_chart)", level=2)
    pdf.body_text(
        "Below the map, this dual-axis chart shows the last 30 days of data for the selected location:"
    )
    pdf.bullet_point("Primary Y-axis (left): Risk score as a line with markers, going from 0% to 100%")
    pdf.bullet_point("Secondary Y-axis (right): Reported cases as bar chart")
    pdf.bullet_point("Line markers are colored by their risk level at each data point")
    pdf.bullet_point("Two horizontal dashed threshold lines at 35% (MEDIUM) and 65% (HIGH) with labels")
    pdf.bullet_point("Area fill under the risk line for visual emphasis")
    pdf.bullet_point("Hover information shows date, exact risk percentage, and case count")

    pdf.chapter_title("3.6 Recent Alerts Feed (render_recent_alerts)", level=2)
    pdf.body_text(
        "Shows the 5 most recent alert events for the selected location. Each alert entry displays:"
    )
    pdf.bullet_point("A colored indicator bar on the left (color matches risk level)")
    pdf.bullet_point("Location name and timestamp of the alert")
    pdf.bullet_point("The trigger event that caused the alert (e.g., 'Risk score exceeded threshold')")
    pdf.bullet_point("The risk level text on the right side, colored by severity")

    pdf.chapter_title("3.7 14-Day Forecast Section (render_forecast_section)", level=2)
    pdf.body_text(
        "This advanced section uses Facebook Prophet (Meta's time-series forecasting library) to predict "
        "outbreak risk for the next 14 days:"
    )
    pdf.bullet_point("Trains a Prophet model on historical risk score data for the selected location")
    pdf.bullet_point("Generates a 14-day forecast with 80% confidence intervals (upper and lower bounds)")
    pdf.bullet_point("Shows an early warning summary with peak risk, date of highest risk, and trend direction")
    pdf.bullet_point("Visualizes historical data (blue line) + forecast (red dashed line) + confidence band")
    pdf.bullet_point("Threshold lines for MEDIUM and HIGH risk are shown across the forecast period")
    pdf.bullet_point("A vertical dotted 'Today' line separates historical from forecast data")
    pdf.bullet_point("An expandable data table shows the raw forecast numbers (date, risk, bounds, trend)")
    pdf.bullet_point("Training metrics (MAE, training days) are displayed at the bottom")

    # ═══════════════════════════════════════════
    # CHAPTER 4: LOCATION DETAIL
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("4. Page 2: Location Detail & Analysis")
    pdf.chapter_title("4.1 File: app/pages/location_detail.py", level=2)

    pdf.body_text(
        "The Location Detail & Analysis page is the most interactive page. It allows users to "
        "input water quality readings and symptom reports, run the ML models, and get a comprehensive "
        "risk assessment with explainability."
    )

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "02_location_detail.png"),
        "Figure 3: Location Detail & Analysis page with water quality input sliders and symptom checkboxes.",
        w=170,
    )

    pdf.chapter_title("4.2 Water Quality Input Form (render_water_quality_form)", level=2)
    pdf.body_text(
        "This form presents 9 slider inputs for water quality parameters. Each slider is configured "
        "with realistic min/max ranges and default values simulating contaminated water:"
    )

    water_params = [
        ("pH Level", "0.0 - 14.0", "Measures acidity/alkalinity. Ideal range: 6.5-8.5"),
        ("Hardness", "0 - 500 mg/L", "Concentration of calcium and magnesium minerals"),
        ("Total Solids", "0 - 50,000 mg/L", "Dissolved solids in water. High levels indicate contamination"),
        ("Chloramines", "0.4 - 13.0 mg/L", "Disinfectant used in water treatment"),
        ("Sulfate", "200 - 500 mg/L", "Natural mineral, high levels can cause digestive issues"),
        ("Conductivity", "200 - 750 uS/cm", "Measures water's ability to conduct electricity"),
        ("Organic Carbon", "2.0 - 30.0 mg/L", "Organic matter content indicator"),
        ("Trihalomethanes", "0 - 150 ug/L", "Disinfection byproducts, potentially carcinogenic"),
        ("Turbidity", "1.5 - 6.5 NTU", "Water clarity measure. Lower is better"),
    ]
    for name, range_val, desc in water_params:
        pdf.bullet_point(f"{name} (Range: {range_val}) - {desc}")

    pdf.chapter_title("4.3 Symptom Report Form (render_symptom_form)", level=2)
    pdf.body_text(
        "A checklist of water-borne disease symptoms that community health workers can report. "
        "Symptoms are organized in 3 columns and include:"
    )
    symptoms = [
        "Diarrhea", "Vomiting", "Nausea", "Abdominal Pain",
        "Fever", "Chills", "Muscle Pain", "Joint Pain",
        "Headache", "Fatigue", "Skin Rash", "Eye Infection",
        "Dehydration", "Blood in Stool", "Jaundice", "Cough"
    ]
    for s in symptoms:
        pdf.bullet_point(s)

    pdf.chapter_title("4.4 Risk Assessment Pipeline (run_assessment)", level=2)
    pdf.body_text(
        "When the user clicks 'Run Risk Assessment', the system executes a 5-step ML pipeline:"
    )

    pdf.chapter_title("Step 1: Water Quality Prediction", level=3)
    pdf.body_text(
        "The water quality inputs are converted to a DataFrame and aligned with the model's "
        "expected feature columns. Missing values are filled with median values from training. "
        "The Voting Ensemble model (XGBoost + Random Forest + Decision Tree) predicts the "
        "probability of potability. The contamination probability is 1 - potability probability."
    )

    pdf.chapter_title("Step 2: Disease Prediction", level=3)
    pdf.body_text(
        "The symptom checkboxes are converted to binary features (1 if checked, 0 if not). "
        "The disease prediction model outputs probabilities for each possible disease. The disease "
        "with the highest probability is selected as the prediction, along with its confidence score."
    )

    pdf.chapter_title("Step 3: Risk Fusion (calculate_risk_score)", level=3)
    pdf.body_text(
        "The risk fusion engine combines both predictions into a single outbreak risk score:"
    )
    pdf.code_block(
        "Outbreak Risk = (0.5 x Water_Contamination_Probability)\n"
        "              + (0.5 x Adjusted_Disease_Probability)\n\n"
        "Adjusted_Disease_Probability applies a severity weight:\n"
        "- Cholera: 1.2x (most severe)\n"
        "- Typhoid: 1.15x\n"
        "- Hepatitis A: 1.1x\n"
        "- Others: 1.0x (neutral)"
    )

    pdf.chapter_title("Step 4: Explanations (SHAP-based)", level=3)
    pdf.body_text(
        "Two types of explanations are generated: Explainability for water prediction (SHAP values) - "
        "Shows which features contributed most to the prediction (e.g., high Turbidity increased "
        "contamination risk by +0.15). Explainability for disease prediction - Shows which symptoms "
        "were most influential and a probability distribution across all possible diseases."
    )

    pdf.chapter_title("Step 5: Recommendations", level=3)
    pdf.body_text(
        "Based on the combined risk level, predicted disease, and water quality status, the system "
        "generates contextual recommendations with action items and community notifications."
    )

    pdf.chapter_title("4.5 Results Display (render_results)", level=2)
    pdf.body_text(
        "After running the assessment, the results are displayed in a structured layout:"
    )
    pdf.bullet_point("Three result cards showing: Water Quality (Safe/Contaminated), Predicted Disease (name + confidence), Combined Risk (LOW/MEDIUM/HIGH + score)")
    pdf.bullet_point("A gauge chart showing the risk score as a speedometer-style visualization (0-100%)")
    pdf.bullet_point("Risk Fusion Formula breakdown showing the exact calculation with real values")
    pdf.bullet_point("Recommendation card with emoji, title, and description")
    pdf.bullet_point("Expandable Action Plan with step-by-step bullet points")
    pdf.bullet_point("Explainability section with two tabs: Water Quality Factors (SHAP bar chart) and Symptom Factors (contribution percentages)")

    pdf.chapter_title("4.6 What-If Analysis (render_what_if_section)", level=2)
    pdf.body_text(
        "This advanced feature allows users to explore counterfactual scenarios in real-time:"
    )
    pdf.bullet_point("Three sliders to adjust pH, Turbidity, and Chloramines values")
    pdf.bullet_point("The model instantly re-predicts water quality as sliders change")
    pdf.bullet_point("Shows contamination risk percentage, risk level badge, and potability status")
    pdf.bullet_point("Causal counterfactual section using DoWhy library for scientific causal inference")
    pdf.bullet_point("Users can select an intervention (e.g., 'Improve pH to neutral') and see estimated risk reduction")
    pdf.bullet_point("Top interventions are ranked by their estimated impact on reducing disease risk")

    # ═══════════════════════════════════════════
    # CHAPTER 5: DATA ANALYSIS
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("5. Page 3: Data Analysis & Upload")
    pdf.chapter_title("5.1 File: app/pages/data_analysis.py", level=2)

    pdf.body_text(
        "The Data Analysis & Upload page is a comprehensive tool for water quality data analysis. "
        "Users can upload their own CSV datasets, run batch predictions, and explore extensive "
        "visualizations of the data and model performance."
    )

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "03_data_analysis.png"),
        "Figure 4: Data Analysis & Upload page with upload section and prediction controls.",
        w=170,
    )

    pdf.chapter_title("5.2 CSV Upload & Validation (render_upload_section)", level=2)
    pdf.body_text(
        "Users can upload a CSV file containing water quality data. The system validates:"
    )
    pdf.bullet_point("The file must have the required columns: pH, Hardness, Solids, Chloramines, Sulfate, Conductivity, Organic_carbon, Trihalomethanes, Turbidity")
    pdf.bullet_point("A preview of the uploaded data is shown (first 5 rows)")
    pdf.bullet_point("Basic statistics are displayed (row count, column count, missing values)")
    pdf.bullet_point("Missing values can be filled using the median imputation strategy")
    pdf.bullet_point("The validation is case-insensitive for column names")

    pdf.chapter_title("5.3 Batch Prediction Engine (run_batch_prediction)", level=2)
    pdf.body_text(
        "After uploading and validating a dataset, users can run batch predictions:"
    )
    pdf.bullet_point("Clicking 'Run Batch Prediction' processes all rows through the Voting Ensemble model")
    pdf.bullet_point("Each row gets a prediction (Safe/Unsafe) with a confidence percentage")
    pdf.bullet_point("Progress is shown via a spinner while predictions are running")
    pdf.bullet_point("Results include the original data plus two new columns: Prediction and Confidence")

    pdf.chapter_title("5.4 Results Aggregation (render_aggregation)", level=2)
    pdf.body_text(
        "After batch prediction, the results page shows:"
    )
    pdf.bullet_point("A pie chart showing Safe vs Unsafe distribution with actual counts")
    pdf.bullet_point("A results table showing all rows with their predictions")
    pdf.bullet_point("A download button to export the complete results as CSV")
    pdf.bullet_point("Summary statistics: total samples, safe count, unsafe count, average confidence")

    pdf.chapter_title("5.5 Exploratory Data Analysis (EDA)", level=2)
    pdf.body_text(
        "Four comprehensive EDA visualizations help understand the water quality data:"
    )

    pdf.chapter_title("5.5.1 Missing Values Chart (render_eda_missing_values)", level=3)
    pdf.body_text(
        "A bar chart showing the percentage of missing values for each water quality parameter. "
        "This helps identify which parameters have incomplete data and may need imputation or "
        "further investigation. Features with high missing percentages (like Sulfate and pH) "
        "are flagged as areas of concern."
    )

    pdf.chapter_title("5.5.2 Class Distribution (render_eda_class_distribution)", level=3)
    pdf.body_text(
        "A bar chart showing the distribution of Safe vs Unsafe samples in the dataset. "
        "This reveals class imbalance issues. For example, if the dataset has 60% Safe and "
        "40% Unsafe samples, it indicates a relatively balanced dataset. A highly imbalanced "
        "dataset (e.g., 90% Safe, 10% Unsafe) would require special handling during training."
    )

    pdf.chapter_title("5.5.3 Correlation Heatmap (render_eda_correlation_heatmap)", level=3)
    pdf.body_text(
        "A color-coded heatmap showing the correlation between all water quality parameters. "
        "Correlation values range from -1 (strong negative correlation) to +1 (strong positive "
        "correlation). This helps identify:"
    )
    pdf.bullet_point("Which parameters are strongly related to each other (multicollinearity)")
    pdf.bullet_point("Which parameters correlate with Potability (the target variable)")
    pdf.bullet_point("For example, pH and Sulfate often show strong correlation with water quality")

    pdf.chapter_title("5.6 Model Evaluation", level=2)

    pdf.chapter_title("5.6.1 Confusion Matrix (render_confusion_matrix)", level=3)
    pdf.body_text(
        "A 2x2 heatmap showing the model's classification performance:"
    )
    pdf.code_block(
        "                 Predicted\n"
        "               Unsafe   Safe\n"
        "Actual Unsafe    TN      FP\n"
        "       Safe      FN      TP\n\n"
        "TN (True Negative): Correctly predicted unsafe samples\n"
        "FP (False Positive): Incorrectly predicted safe (Type I error)\n"
        "FN (False Negative): Incorrectly predicted unsafe (Type II error)\n"
        "TP (True Positive): Correctly predicted safe samples"
    )
    pdf.body_text(
        "Below the matrix, key metrics are displayed: Accuracy (overall correctness), "
        "Precision (of positive predictions, how many were correct), Recall (of actual positives, "
        "how many were caught), F1 Score (harmonic mean of precision and recall)."
    )

    pdf.chapter_title("5.6.2 Model Accuracy Comparison (render_accuracy_comparison)", level=3)
    pdf.body_text(
        "A grouped bar chart comparing the performance of all 3 models in the ensemble: "
        "XGBoost, Random Forest, Decision Tree, and the final Voting Ensemble. For each model, "
        "the chart shows training accuracy and test/validation accuracy side by side. This allows "
        "users to see which individual model contributes most to the ensemble's performance."
    )

    pdf.chapter_title("5.6.3 Feature Importance (render_feature_importance)", level=3)
    pdf.body_text(
        "A horizontal bar chart showing which water quality features are most important for "
        "the model's predictions. Features are ranked from most to least important. Typical "
        "findings show that Sulfate, pH, and Turbidity are among the top predictors of water "
        "quality, while parameters like Chloramines may have lower importance."
    )

    pdf.chapter_title("5.6.4 Model Details Section", level=2)
    pdf.body_text(
        "Three info cards provide at-a-glance information about each model:"
    )
    pdf.bullet_point("XGBoost Card: Shows the model type, number of estimators (100), max depth (6), and accuracy score")
    pdf.bullet_point("Random Forest Card: Shows the model type, number of estimators (200), max depth (15), and accuracy score")
    pdf.bullet_point("Decision Tree Card: Shows the model type, max depth (10), feature count, and accuracy score")
    pdf.bullet_point("The ensemble itself is described as 'Voting Ensemble (soft voting)' combining all three")

    # ═══════════════════════════════════════════
    # CHAPTER 6: ALERTS LOG
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("6. Page 4: Alerts Log")
    pdf.chapter_title("6.1 File: app/pages/alerts_log.py", level=2)

    pdf.body_text(
        "The Alerts Log page provides a historical view of all alert events generated by the "
        "system. It serves as an audit trail for monitoring activities and decision-making."
    )

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "04_alerts_log.png"),
        "Figure 5: Alerts Log page with alerts table and filter controls.",
        w=170,
    )

    pdf.chapter_title("6.2 Alert Filters & Controls", level=2)
    pdf.body_text("The page provides multiple ways to filter and analyze alerts:")

    pdf.bullet_point("Location filter: Select a specific location to view its alerts, or 'All Locations' to see everything")
    pdf.bullet_point("Risk level filter: Filter by LOW, MEDIUM, or HIGH risk levels")
    pdf.bullet_point("Date range filter: Select start and end dates to narrow the time window")
    pdf.bullet_point("Search text: Free-text search across alert titles and descriptions")
    pdf.bullet_point("Sort options: Sort by date (newest/oldest) or by risk level (highest/lowest)")
    pdf.bullet_point("A 'Clear Filters' button resets all filters at once")
    pdf.bullet_point("An alert count badge shows how many alerts match the current filters")

    pdf.chapter_title("6.3 Alerts Table", level=2)
    pdf.body_text(
        "The alerts are displayed in a table with the following columns:"
    )
    pdf.bullet_point("Timestamp: Date and time when the alert was generated")
    pdf.bullet_point("Location: Which monitored location triggered the alert")
    pdf.bullet_point("Risk Level: Color-coded badge showing LOW/MEDIUM/HIGH")
    pdf.bullet_point("Risk Score: The exact numerical score that triggered the alert")
    pdf.bullet_point("Trigger: What event or threshold caused the alert (e.g., 'Risk score exceeded 65% threshold')")
    pdf.bullet_point("Status: Whether the alert is New, Acknowledged, Resolved, or Escalated")
    pdf.bullet_point("Actions: Buttons to acknowledge, escalate, or resolve each alert")

    pdf.chapter_title("6.4 Alert Summary Statistics", level=2)
    pdf.body_text("At the top of the page, summary statistics show:")
    pdf.bullet_point("Total alerts in the system")
    pdf.bullet_point("Unresolved alerts (still active)")
    pdf.bullet_point("High-risk alerts requiring immediate attention")
    pdf.bullet_point("Average response time (time between alert creation and resolution)")

    # ═══════════════════════════════════════════
    # CHAPTER 7: ABOUT PAGE
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("7. Page 5: About & Methodology")
    pdf.chapter_title("7.1 File: app/pages/about.py", level=2)

    pdf.body_text(
        "The About & Methodology page provides comprehensive documentation about the project, "
        "its methodology, data sources, and technical implementation details."
    )

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "05_about.png"),
        "Figure 6: About & Methodology page with project information and technical details.",
        w=170,
    )

    pdf.chapter_title("7.2 Project Information", level=2)
    pdf.body_text(
        "This section provides an overview of the Aarogya Jal project, its mission to provide "
        "clean drinking water monitoring through AI/ML, and the problem it solves - water-borne "
        "diseases affecting millions in rural and semi-urban communities."
    )

    pdf.chapter_title("7.3 Methodology Details", level=2)
    pdf.body_text("The methodology section explains the technical approach in detail:")

    pdf.chapter_title("7.3.1 Data Collection & Simulation", level=3)
    pdf.body_text(
        "Since real-time water quality data is difficult to obtain for demonstration purposes, "
        "the application generates realistic synthetic data using statistical distributions "
        "based on published water quality studies. The data generator creates water quality "
        "parameters, disease symptom reports, timeline data, and alert logs with realistic patterns."
    )

    pdf.chapter_title("7.3.2 Feature Engineering", level=3)
    pdf.body_text(
        "For water quality prediction, 9 features are used: pH, Hardness, Solids, Chloramines, "
        "Sulfate, Conductivity, Organic_carbon, Trihalomethanes, and Turbidity. For disease "
        "prediction, 16 binary symptom features are used. Both feature sets were selected based "
        "on domain expertise in water quality assessment and epidemiology."
    )

    pdf.chapter_title("7.3.3 Ensemble Model Architecture", level=3)
    pdf.body_text(
        "The Voting Ensemble uses soft voting (averaging probabilities) from three models:"
    )
    pdf.bullet_point("XGBoost: Gradient boosting with 100 estimators, max depth 6 - captures complex non-linear relationships")
    pdf.bullet_point("Random Forest: 200 trees, max depth 15 - provides robust predictions through bagging")
    pdf.bullet_point("Decision Tree: Max depth 10 - provides interpretable baseline")
    pdf.body_text(
        "Soft voting means the final probability is the average of all three models' probabilities, "
        "which reduces overfitting and improves generalization."
    )

    pdf.chapter_title("7.3.4 Risk Fusion Engine", level=3)
    pdf.body_text(
        "The Risk Fusion Engine is a novel component that combines water quality and disease "
        "predictions into a single actionable risk score. It applies severity weights based on "
        "the predicted disease (e.g., Cholera has a weight of 1.2x due to its high mortality "
        "rate) and calculates the final score as a weighted average."
    )

    pdf.chapter_title("7.3.5 Explainable AI (XAI)", level=3)
    pdf.body_text(
        "The application uses SHAP (SHapley Additive exPlanations) to explain individual predictions. "
        "SHAP values show how much each feature contributed to pushing the prediction away from the "
        "average. Positive SHAP values indicate features that increased the risk, while negative "
        "values indicate features that decreased the risk."
    )

    pdf.chapter_title("7.3.6 Time-Series Forecasting", level=3)
    pdf.body_text(
        "Facebook Prophet is used for 14-day risk forecasting because it handles seasonality, "
        "trend changes, and missing data well. The model is trained on historical risk scores "
        "and generates forecasts with confidence intervals."
    )

    pdf.chapter_title("7.4 Data Sources", level=2)
    pdf.body_text("The system uses the following data:")
    pdf.bullet_point("water_potability.csv: Historical water quality measurements with potability labels")
    pdf.bullet_point("simulated_timeline.csv: Time-series data of risk scores and disease cases across all locations")
    pdf.bullet_point("alert_log.csv: Log of all alert events generated by the monitoring system")
    pdf.bullet_point("disease_symptoms.csv: Mapping of diseases to their characteristic symptoms")

    pdf.chapter_title("7.5 Technology Stack Details", level=2)
    pdf.bullet_point("Python 3.14: Core programming language")
    pdf.bullet_point("Streamlit 1.42: Web application framework")
    pdf.bullet_point("Scikit-learn 1.6: Machine learning models and metrics")
    pdf.bullet_point("XGBoost 3.0: Gradient boosting model")
    pdf.bullet_point("Facebook Prophet: Time-series forecasting (if installed)")
    pdf.bullet_point("DoWhy: Causal inference and what-if analysis (if installed)")
    pdf.bullet_point("SHAP: Model explainability and feature importance (if installed)")
    pdf.bullet_point("Plotly 6.0: Interactive data visualizations")
    pdf.bullet_point("Pandas 2.2/NumPy 2.0: Data manipulation")
    pdf.bullet_point("Joblib: Model serialization and loading")

    pdf.chapter_title("7.6 Performance Metrics", level=2)
    pdf.body_text("The current Voting Ensemble model achieves:")
    pdf.bullet_point("Overall Accuracy: ~78% on validation data")
    pdf.bullet_point("Precision: Varies by class (typically higher for Safe predictions)")
    pdf.bullet_point("Recall: Varies by class (typically higher for Unsafe predictions)")
    pdf.bullet_point("F1 Score: Balanced metric typically around 75-80%")
    pdf.body_text(
        "Note: These metrics are based on the simulated dataset. Performance on real-world data "
        "would depend on the quality and representativeness of the training data."
    )

    # ═══════════════════════════════════════════
    # CHAPTER 8: UTILITY MODULES
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("8. Utility Modules")
    pdf.chapter_title("8.1 File: app/utils/data_generator.py", level=2)

    pdf.body_text(
        "This module generates realistic synthetic data for demonstration purposes. It creates:"
    )
    pdf.bullet_point("8 locations with names, populations, and GPS coordinates across India")
    pdf.bullet_point("Water quality features with realistic min/max ranges and mean values based on published studies")
    pdf.bullet_point("16 water-borne disease symptoms mapped to their associated diseases")
    pdf.bullet_point("simulated_timeline.csv: 365 days of risk scores and case data for all 8 locations")
    pdf.bullet_point("alert_log.csv: Alert events triggered when risk scores exceed thresholds")
    pdf.bullet_point("water_potability.csv: 3,276 samples of water quality data with potability labels for model training")
    pdf.bullet_point("disease_symptoms.csv: Mapping data for disease-symptom associations")

    pdf.chapter_title("8.2 File: app/utils/risk_fusion.py", level=2)
    pdf.body_text(
        "The Risk Fusion Engine is the core decision logic that combines multiple prediction "
        "sources into a single actionable risk score. Key functions:"
    )
    pdf.bullet_point("get_risk_level(score): Classifies a numerical score into LOW (0-35%), MEDIUM (35-65%), or HIGH (65-100%)")
    pdf.bullet_point("get_risk_color(score): Returns the appropriate hex color code for each risk level")
    pdf.bullet_point("calculate_risk_score(water_prob, disease_prob): Combines two probabilities using a weighted formula")
    pdf.bullet_point("apply_severity_weight(disease_prob, disease): Applies severity multipliers (Cholera=1.2x, Typhoid=1.15x, etc.)")
    pdf.bullet_point("get_risk_recommendation(risk_level): Generates contextual action recommendations")
    pdf.bullet_point("RISK_COLORS: Dictionary mapping risk levels to '#2ECC71' (LOW), '#F1C40F' (MEDIUM), '#E74C3C' (HIGH)")
    pdf.bullet_point("RISK_EMOJIS: Dictionary mapping risk levels to emojis (shield, warning, alarm)")

    pdf.chapter_title("8.3 File: app/utils/forecasting.py", level=2)
    pdf.body_text(
        "This module implements time-series forecasting using Facebook Prophet:"
    )
    pdf.bullet_point("RiskForecaster class wraps Prophet model training and prediction")
    pdf.bullet_point("train(timeline_data, location): Prepares data and trains Prophet model")
    pdf.bullet_point("predict(): Generates 14-day forecast with trend direction analysis")
    pdf.bullet_point("get_early_warning(forecast): Identifies peak risk dates and generates early warnings")
    pdf.bullet_point("format_forecast_summary(warning): Creates HTML-formatted summary for display")
    pdf.bullet_point("Training metrics include MAE and training duration")

    pdf.chapter_title("8.4 File: app/utils/explainability.py", level=2)
    pdf.body_text(
        "Provides SHAP-based explainability for ML predictions:"
    )
    pdf.bullet_point("explain_water_prediction(model, inputs): Calculates SHAP values for water quality prediction, showing which features were most influential")
    pdf.bullet_point("explain_disease_prediction(model, inputs): Analyzes symptom contributions and generates probability distribution across diseases")
    pdf.bullet_point("generate_explainability_chart(explanation, chart_type): Formats SHAP data for Plotly visualization")

    pdf.chapter_title("8.5 File: app/utils/recommendations.py", level=2)
    pdf.body_text("Generates contextual action plans based on risk assessment results:")
    pdf.bullet_point("get_recommendation(risk_level, disease=None, water_safe=None): Returns structured recommendation with emoji, title, short description, and bullet points")
    pdf.bullet_point("get_community_message(risk_level, disease, location): Generates community notification messages for broadcasting")
    pdf.bullet_point("Recommendations are tiered by severity: LOW suggests monitoring, MEDIUM suggests preparation, HIGH suggests immediate action")

    pdf.chapter_title("8.6 File: app/utils/causal_analysis.py", level=2)
    pdf.body_text(
        "Implements causal inference using the DoWhy library for what-if analysis:"
    )
    pdf.bullet_point("CausalAnalyzer class manages causal graph and intervention analysis")
    pdf.bullet_point("load_or_generate_data(): Loads or creates synthetic water quality data")
    pdf.bullet_point("what_if_analysis(feature, target_value): Estimates the causal effect of changing a water quality parameter on disease risk")
    pdf.bullet_point("get_top_interventions(n): Returns the n most impactful interventions ranked by estimated risk reduction")
    pdf.bullet_point("Uses linear regression-based causal estimation (ATE - Average Treatment Effect)")

    # ═══════════════════════════════════════════
    # CHAPTER 9: ML MODELS
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("9. Machine Learning Models")
    pdf.chapter_title("9.1 File: models/train_models.py", level=2)

    pdf.body_text(
        "The training script trains and saves both the water quality and disease prediction models. "
        "It is executed separately from the app using: python models/train_models.py"
    )

    pdf.chapter_title("9.2 Water Quality Model Training", level=2)
    pdf.body_text("The water quality model training process:")
    pdf.code_block(
        "1. Load water_potability.csv (3,276 samples, 9 features)\n"
        "2. Split features (X) and target (y = Potability)\n"
        "3. Handle missing values (median imputation)\n"
        "4. Create 3 base models:\n"
        "   - XGBClassifier(n_estimators=100, max_depth=6)\n"
        "   - RandomForestClassifier(n_estimators=200, max_depth=15)\n"
        "   - DecisionTreeClassifier(max_depth=10)\n"
        "5. Create VotingClassifier(estimators, voting='soft')\n"
        "6. Train on 80% of data\n"
        "7. Evaluate on 20% held-out test set\n"
        "8. Save: model, accuracy, confusion matrix, feature importance\n"
        "9. Store as water_quality_model.pkl (~85% accuracy)"
    )

    pdf.chapter_title("9.3 Disease Prediction Model Training", level=2)
    pdf.body_text("The disease model training follows a similar process:")
    pdf.code_block(
        "1. Generate synthetic disease-symptom dataset\n"
        "2. Features: 16 binary symptom columns\n"
        "3. Target: Disease name (multi-class)\n"
        "4. Same ensemble architecture with soft voting\n"
        "5. Evaluate: accuracy, confusion matrix, classification report\n"
        "6. Store as disease_prediction_model.pkl (~92% accuracy)\n"
        "7. Label encoder maps numeric predictions to disease names:\n"
        "   Cholera, Typhoid, Hepatitis A, Dysentery, Gastroenteritis,\n"
        "   Malaria, Dengue, Leptospirosis"
    )

    pdf.chapter_title("9.4 Model Persistence", level=2)
    pdf.body_text(
        "Both models are saved as pickle (.pkl) files using joblib. Each pickle file contains "
        "a dictionary with: 'model' (the trained VotingClassifier), 'feature_cols' (column names), "
        "'metrics' (accuracy, confusion matrix values), and for disease model: 'label_encoder', "
        "'symptom_cols'. Models are loaded at app startup and cached for the session duration."
    )

    pdf.chapter_title("9.5 Ensemble Performance Comparison", level=2)
    pdf.body_text("The ensemble approach typically outperforms individual models because:")
    pdf.bullet_point("XGBoost excels at capturing complex non-linear patterns but can overfit on small datasets")
    pdf.bullet_point("Random Forest provides robust predictions through bootstrap aggregation and feature randomness")
    pdf.bullet_point("Decision Tree offers interpretability and serves as a baseline")
    pdf.bullet_point("Soft voting averages the probability outputs, reducing variance and improving generalization")
    pdf.bullet_point("The combined model typically achieves 3-8% higher accuracy than the best individual model")

    # ═══════════════════════════════════════════
    # CHAPTER 10: HOW TO RUN
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("10. How to Run the Application")
    pdf.chapter_title("10.1 Prerequisites", level=2)
    pdf.body_text("Before running the application, ensure you have:")
    pdf.bullet_point("Python 3.10+ installed on your system")
    pdf.bullet_point("All required packages installed (see requirements.txt)")
    pdf.bullet_point("At least 4GB of RAM available")
    pdf.bullet_point("A modern web browser (Chrome, Firefox, or Edge)")

    pdf.chapter_title("10.2 Installation Steps", level=2)
    pdf.code_block(
        "# Step 1: Navigate to the project directory\n"
        "cd /path/to/water-pollution\n\n"
        "# Step 2: Install required packages\n"
        "pip install -r requirements.txt\n\n"
        "# Step 3: Train the ML models (first time only)\n"
        "python models/train_models.py\n\n"
        "# Step 4: Run the application\n"
        "python -m streamlit run app/app.py"
    )

    pdf.chapter_title("10.3 Accessing the Application", level=2)
    pdf.body_text(
        "Once the Streamlit server starts, you will see output similar to:"
    )
    pdf.code_block(
        "  You can now view your Streamlit app in your browser.\n\n"
        "  Local URL: http://localhost:8501\n"
        "  Network URL: http://192.168.x.x:8501"
    )
    pdf.body_text("Open your browser and navigate to http://localhost:8501 to use the application.")

    pdf.chapter_title("10.4 Optional: REST API Server", level=2)
    pdf.body_text(
        "The application also has a FastAPI-based REST API. To start it:"
    )
    pdf.code_block(
        "cd /path/to/water-pollution\n"
        "uvicorn api.app:app --reload --port 8000"
    )
    pdf.body_text("The API is then accessible at http://localhost:8000 with automatic docs at http://localhost:8000/docs")

    pdf.chapter_title("10.5 Running in Jupyter Notebook", level=2)
    pdf.body_text(
        "You can also explore the ML models interactively in a Jupyter notebook. "
        "A notebook version of train_models.py can be created by copying the code "
        "into cells and running them sequentially. The pickle files in "
        "models/trained_models/ can be loaded directly:"
    )
    pdf.code_block(
        "import joblib\n"
        "model = joblib.load(\"models/trained_models/water_quality_model.pkl\")\n"
        "print(f\"Model type: {model['model'].__class__.__name__}\")\n"
        "print(f\"Accuracy: {model['metrics']['accuracy']:.2%}\")"
    )

    pdf.chapter_title("10.6 Troubleshooting", level=2)
    pdf.info_box("Common Issues", "If the app doesn't start, check that:\n1. All packages in requirements.txt are installed\n2. The models have been trained (run train_models.py)\n3. No other application is using port 8501\n4. You are running Python 3.10+")

    # ═══════════════════════════════════════════
    # APPENDIX A: SCREENSHOTS
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("Appendix A: Screenshots Gallery")

    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "01_overview.png"),
        "Figure A1: Overview Dashboard - showing the 4 summary metric cards, geographic risk map of India, "
        "quick recommendation panel, risk trend chart, and recent alerts feed.",
        w=160,
    )

    pdf.add_page()
    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "02_location_detail.png"),
        "Figure A2: Location Detail & Analysis page - showing water quality parameter sliders (pH, Hardness, "
        "Solids, etc.) on the left and symptom checkboxes on the right.",
        w=160,
    )

    pdf.add_page()
    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "03_data_analysis.png"),
        "Figure A3: Data Analysis & Upload page - showing the upload section, batch prediction controls, "
        "EDA visualizations, confusion matrix, and feature importance chart.",
        w=160,
    )

    pdf.add_page()
    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "04_alerts_log.png"),
        "Figure A4: Alerts Log page - showing the filtered alerts table with timestamp, location, "
        "risk level, trigger information, and action buttons.",
        w=160,
    )

    pdf.add_page()
    pdf.add_screenshot(
        os.path.join(SCREENSHOTS_DIR, "05_about.png"),
        "Figure A5: About & Methodology page - showing project information, methodology details, "
        "data sources, technology stack, and version information.",
        w=160,
    )

    # ═══════════════════════════════════════════
    # APPENDIX B: TECHNICAL SPECIFICATIONS
    # ═══════════════════════════════════════════
    pdf.add_page()
    pdf.chapter_title("Appendix B: Technical Specifications")

    pdf.chapter_title("B.1 File Structure", level=2)
    pdf.code_block(
        "water-pollution/\n"
        "|-- app/\n"
        "|   |-- app.py                 # Main entry point\n"
        "|   |-- assets/\n"
        "|   |   |-- style.css          # Custom dark theme CSS\n"
        "|   |-- pages/\n"
        "|   |   |-- overview.py        # Overview Dashboard\n"
        "|   |   |-- location_detail.py # Location Detail & Analysis\n"
        "|   |   |-- data_analysis.py   # Data Analysis & Upload\n"
        "|   |   |-- alerts_log.py      # Alerts Log\n"
        "|   |   |-- about.py           # About & Methodology\n"
        "|   |-- utils/\n"
        "|       |-- data_generator.py   # Synthetic data generation\n"
        "|       |-- risk_fusion.py      # Risk fusion engine\n"
        "|       |-- forecasting.py      # Prophet forecasting\n"
        "|       |-- explainability.py   # SHAP explainability\n"
        "|       |-- recommendations.py  # Action recommendations\n"
        "|       |-- causal_analysis.py  # DoWhy causal inference\n"
        "|-- models/\n"
        "|   |-- train_models.py         # Model training script\n"
        "|   |-- trained_models/\n"
        "|       |-- water_quality_model.pkl   # Water model\n"
        "|       |-- disease_prediction_model.pkl # Disease model\n"
        "|-- data/\n"
        "|   |-- simulated_timeline.csv  # Historical risk data\n"
        "|   |-- alert_log.csv           # Alert events log\n"
        "|   |-- water_potability.csv    # Training dataset\n"
        "|   |-- disease_symptoms.csv    # Symptom mappings\n"
        "|-- api/\n"
        "|   |-- app.py                  # FastAPI REST API\n"
        "|-- requirements.txt            # Python dependencies\n"
        "|-- README.md                   # Project README"
    )

    pdf.chapter_title("B.2 Water Quality Parameters", level=2)
    wq_params = [
        ("pH", "0-14", "6.5-8.5", "3.7", "Measures acidity/alkalinity"),
        ("Hardness (mg/L)", "0-500", "80-200", "196.9", "Mineral concentration"),
        ("Solids (mg/L)", "0-50,000", "500-25,000", "22,014", "Total dissolved solids"),
        ("Chloramines (mg/L)", "0.4-13.0", "2-6", "7.1", "Disinfectant residual"),
        ("Sulfate (mg/L)", "200-500", "200-400", "332.1", "Natural mineral"),
        ("Conductivity (uS/cm)", "200-750", "250-550", "425.6", "Electrical conductivity"),
        ("Organic Carbon (mg/L)", "2-30", "5-15", "14.3", "Organic matter indicator"),
        ("Trihalomethanes (ug/L)", "0-150", "20-80", "66.4", "Disinfection byproduct"),
        ("Turbidity (NTU)", "1.5-6.5", "1.5-4.0", "3.9", "Water clarity"),
    ]
    for name, range_val, ideal, mean, desc in wq_params:
        pdf.bullet_point(f"{name}: Range={range_val}, Ideal={ideal}, Mean={mean} - {desc}")

    pdf.chapter_title("B.3 Disease-Symptom Mapping", level=2)
    diseases = [
        ("Cholera", "Diarrhea, Vomiting, Dehydration, Abdominal Pain (most severe, weight=1.2x)"),
        ("Typhoid", "Fever, Headache, Fatigue, Abdominal Pain (severe, weight=1.15x)"),
        ("Hepatitis A", "Jaundice, Fever, Fatigue, Nausea (severe, weight=1.1x)"),
        ("Dysentery", "Diarrhea, Blood in Stool, Abdominal Pain, Fever"),
        ("Gastroenteritis", "Diarrhea, Vomiting, Nausea, Abdominal Pain"),
        ("Malaria", "Fever, Chills, Headache, Muscle Pain"),
        ("Dengue", "Fever, Joint Pain, Skin Rash, Headache"),
        ("Leptospirosis", "Fever, Muscle Pain, Headache, Eye Infection"),
    ]
    for disease, symptoms in diseases:
        pdf.bullet_point(f"{disease}: {symptoms}")

    pdf.chapter_title("B.4 Color Theme Reference", level=2)
    colors = [
        ("Background (primary)", "#1A1A2E", "Main page background"),
        ("Background (secondary)", "#16213E", "Card backgrounds"),
        ("Accent (gold/terracotta)", "#C0392B", "Headers, highlights"),
        ("Text (primary)", "#ECE3D0", "Main text color"),
        ("Text (secondary)", "#C9BFA9", "Secondary text"),
        ("Low Risk", "#2ECC71", "Green - safe"),
        ("Medium Risk", "#F1C40F", "Yellow - caution"),
        ("High Risk", "#E74C3C", "Red - danger"),
        ("Card Background", "rgba(0,0,0,0.03)", "Subtle card background"),
    ]
    for name, hex_val, desc in colors:
        pdf.bullet_point(f"{name}: {hex_val} - {desc}")

    # ═══════════════════════════════════════════
    # OUTPUT
    # ═══════════════════════════════════════════
    output_path = os.path.join(OUTPUT_DIR, "Aarogya_Jal_Complete_Documentation.pdf")
    pdf.output(output_path)
    print(f"\nPDF generated successfully!")
    print(f"Output: {output_path}")
    print(f"Total pages: {pdf.page_no()}")
    return output_path


if __name__ == "__main__":
    generate_pdf()
