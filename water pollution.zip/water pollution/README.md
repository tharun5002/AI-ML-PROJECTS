# 💧 Aarogya Jal — Smart Community Health Monitoring & Early Warning System

A system that predicts **outbreak risk** of water-borne diseases (cholera, typhoid, diarrhea, hepatitis A) by combining **water quality data** with **community symptom reports**, displayed on a live dashboard with automatic alerts and recommendations.

## ✨ Key Novel Features

| Feature | Impact |
|---------|--------|
| **⚡ Risk Fusion Engine** — Combines water + symptom scores into Outbreak Risk Index | Core novelty |
| **🗺️ Geographic Risk Map** — 8 simulated villages with lat-long, colored by risk | High |
| **📈 Trend/Time-Series View** — 60-day simulated timeline with dual-axis charts | High |
| **🔍 Explainability (SHAP)** — Feature importance & SHAP values for every prediction | Very High |
| **📋 Severity-Based Recommendations** — Contextual action plans per risk level | Medium |
| **🖱️ Interactive Multi-Source Input** — Manual entry like a real health worker | High |

## 🏗️ System Architecture

```
Water Quality Data ──→ Model 1: Water Classifier ──┐
                                                    ├─→ Risk Fusion Engine ──→ Dashboard
Symptom Reports ────→ Model 2: Disease Predictor ──┘
                                                    └─→ SHAP Explainability
                                                    └─→ Recommendation Engine
```

## 🧠 Dual ML Model System

### Model 1: Water Quality Classifier
- **Algorithm:** Random Forest (n_estimators=200, max_depth=15)
- **Features:** pH, Hardness, Solids, Chloramines, Sulfate, Conductivity, Organic Carbon, Trihalomethanes, Turbidity
- **Task:** Binary classification — Potable / Not Potable
- **Alternatives compared:** Logistic Regression, Decision Tree

### Model 2: Disease Predictor
- **Algorithm:** Random Forest (n_estimators=150, max_depth=12)
- **Symptoms (12):** Fever, Fatigue, Headache, Diarrhea, Vomiting, Nausea, Abdominal Pain, Dehydration, Jaundice, etc.
- **Diseases (6):** Typhoid, Cholera, Gastroenteritis, Hepatitis A, Dysentery, Diarrheal Disease
- **Key preprocessing:** Filtered to water-borne diseases only

### The Novel Fusion Formula
```
Outbreak Risk Score = (0.5 × Water_Contamination_Prob) + (0.5 × Symptom_Disease_Prob)

Score 0.00–0.35 → LOW (Green)
Score 0.35–0.65 → MEDIUM (Yellow)
Score 0.65–1.00 → HIGH (Red)
```

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Generate Data & Train Models
```bash
python models/train_models.py
```
This generates synthetic datasets and trains both ML models (~2-3 minutes).

### 3. Run the Dashboard
```bash
streamlit run app/app.py
```

## 📊 Dashboard Screens

| Screen | Description |
|--------|-------------|
| **📊 Overview** | Summary cards, geographic risk map, 30-day trend chart, recent alerts |
| **🔬 Location Detail** | Interactive data entry forms, ML predictions, combined risk gauge, SHAP explainability, recommendations |
| **🚨 Alerts Log** | Filterable alerts table, timeline chart, CSV download |
| **ℹ️ About** | System architecture, methodology, model comparison, tech stack |

## 📦 Project Structure

```
water_pollution/
├── app/
│   ├── app.py                 # Main Streamlit entry point
│   ├── assets/
│   │   └── style.css          # Custom styling
│   ├── pages/
│   │   ├── overview.py        # Dashboard landing page
│   │   ├── location_detail.py # Data entry + predictions
│   │   ├── alerts_log.py      # Historical alerts
│   │   └── about.py           # Methodology documentation
│   └── utils/
│       ├── data_generator.py  # Synthetic data generation
│       ├── risk_fusion.py     # Core fusion engine
│       ├── explainability.py  # SHAP explanations
│       └── recommendations.py # Action plan generator
├── data/                      # Generated datasets (CSV)
├── models/
│   ├── train_models.py        # Training pipeline
│   └── trained_models/        # Saved model files (pkl)
├── requirements.txt
└── README.md
```

## 🛠️ Tech Stack

- **Python 3.12** — Core language
- **scikit-learn** — Random Forest, Logistic Regression, Decision Tree
- **Streamlit** — Interactive dashboard
- **Plotly** — Charts, gauges, maps
- **SHAP** — Model explainability
- **pandas / numpy** — Data processing
- **joblib** — Model persistence

## 📐 Data Sources

Synthetic datasets designed to mirror real-world distributions:
- **Water Quality:** ~3,200 samples, 9 features, binary potability label
- **Disease Symptoms:** ~5,000 samples, 12 symptom columns, 6 disease classes
- **Simulated Timeline:** 60 days × 8 locations of risk scores & case reports
- **Alert Log:** ~50+ derived alerts with triggers

## 🔬 Future Work

- Learn optimal fusion weights via logistic regression on real outbreak data
- Live API integration with water sensor networks
- Real-time SMS/email alert delivery
- Integration with national health surveillance systems
- Mobile app for community health worker field reporting

---

*Built with 💙 for smarter community health monitoring*
