"""
app/app.py
Main entry point for the Smart Community Health Monitoring & Early Warning System.
This is a multi-page Streamlit application.
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.utils.data_generator import LOCATIONS
from app.utils.risk_fusion import (
    get_risk_color, get_risk_level, calculate_risk_score,
    apply_severity_weight, get_risk_recommendation, RISK_COLORS, RISK_EMOJIS
)
from app.utils.explainability import (
    explain_water_prediction, explain_disease_prediction,
    generate_explainability_chart
)
from app.utils.recommendations import get_recommendation, get_community_message

# ── Page Configuration (must be first) ──
st.set_page_config(
    page_title="Aarogya Jal — Health Monitoring System",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Load Custom CSS ──
def load_css():
    css_path = os.path.join(os.path.dirname(__file__), 'assets', 'style.css')
    if os.path.exists(css_path):
        # Must use utf-8 encoding on Windows (cp1252 cannot decode emoji/unicode chars)
        with open(css_path, encoding='utf-8') as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# ── Session State Initialization ──
load_css()
if 'models_loaded' not in st.session_state:
    st.session_state.models_loaded = False
if 'water_model' not in st.session_state:
    st.session_state.water_model = None
if 'disease_model' not in st.session_state:
    st.session_state.disease_model = None
if 'timeline_data' not in st.session_state:
    st.session_state.timeline_data = None
if 'alert_data' not in st.session_state:
    st.session_state.alert_data = None
if 'current_location' not in st.session_state:
    st.session_state.current_location = LOCATIONS[0]['name']
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []


# ── Model Loading ──
@st.cache_resource
def load_models():
    """Load pre-trained models from disk."""
    model_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models', 'trained_models')

    water_path = os.path.join(model_dir, 'water_quality_model.pkl')
    disease_path = os.path.join(model_dir, 'disease_prediction_model.pkl')

    if not os.path.exists(water_path) or not os.path.exists(disease_path):
        return None, None, "Models not found. Please run model training first."

    try:
        water_model = joblib.load(water_path)
        disease_model = joblib.load(disease_path)
        return water_model, disease_model, None
    except Exception as e:
        return None, None, str(e)


@st.cache_resource
def load_data():
    """Load simulated timeline and alert data."""
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')

    timeline_path = os.path.join(data_dir, 'simulated_timeline.csv')
    alert_path = os.path.join(data_dir, 'alert_log.csv')

    timeline = pd.read_csv(timeline_path) if os.path.exists(timeline_path) else None
    alerts = pd.read_csv(alert_path) if os.path.exists(alert_path) else None

    return timeline, alerts


# ── Header (with embedded water tap animation) ──
def render_header():
    st.markdown("""
    <div class="app-header">
        <div class="header-title">
            <span class="header-icon">💧</span>
            <div>
                <h1>Aarogya Jal</h1>
                <p class="header-subtitle">Smart Community Health Monitoring & Early Warning System</p>
            </div>
        </div>
        <div class="header-badge">
            <span class="badge-pulse">🟢</span> System Active
        </div>
    </div>
    """, unsafe_allow_html=True)


# ── Sidebar ──
def render_sidebar():
    with st.sidebar:
        st.markdown("""
        <div class="sidebar-brand">
            <div class="sidebar-logo">💧</div>
            <div class="sidebar-title">Aarogya Jal</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # Location selector
        st.markdown("### 📍 Select Location")
        location_names = [loc['name'] for loc in LOCATIONS]

        selected = st.selectbox(
            "Monitoring Location",
            options=location_names,
            index=location_names.index(st.session_state.current_location)
            if st.session_state.current_location in location_names else 0,
            label_visibility="collapsed",
        )
        st.session_state.current_location = selected

        # Show location info
        loc_data = next((l for l in LOCATIONS if l['name'] == selected), LOCATIONS[0])
        st.markdown(f"""
        <div class="location-card">
            <div><strong>Population:</strong> {loc_data['population']:,}</div>
            <div><strong>Coordinates:</strong> {loc_data['lat']:.3f}°N, {loc_data['lon']:.3f}°E</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # System status
        st.markdown("### 🔬 System Status")
        if st.session_state.models_loaded:
            st.markdown("""
            <div class="status-ok">
                ✅ Models loaded<br>
                ✅ Data pipeline active<br>
                ✅ Monitoring running
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="status-warn">
                ⏳ Loading models...
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")

        # Quick stats
        if st.session_state.timeline_data is not None:
            tl = st.session_state.timeline_data
            loc_tl = tl[tl['Location'] == selected]

            if not loc_tl.empty:
                latest = loc_tl.iloc[-1]
                avg_risk = loc_tl['Risk_Score'].mean()

                st.markdown("### 📊 Quick Stats")
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Current Risk", f"{latest['Risk_Score']:.0%}")
                with col2:
                    st.metric("Avg Risk", f"{avg_risk:.0%}")
                st.metric("Total Cases (30d)", int(loc_tl.tail(30)['Reported_Cases'].sum()))

        st.markdown("---")

        # API info
        st.markdown("### 🌐 API Access")
        st.markdown("""
        <div style="font-size: 0.8rem; color: #C9BFA9; line-height: 1.6;">
            REST API available at:
            <code style="display: block; padding: 6px 8px; background: rgba(0,0,0,0.03); border-radius: 6px; margin: 4px 0;">
            http://localhost:8000
            </code>
            <small>uvicorn api.app:app --reload --port 8000</small>
        </div>
        """, unsafe_allow_html=True)

        # Model type indicator
        if st.session_state.models_loaded:
            water_model = st.session_state.water_model
            disease_model = st.session_state.disease_model
            is_ensemble_water = water_model.get('is_ensemble', False) if water_model else False
            is_ensemble_disease = disease_model.get('is_ensemble', False) if disease_model else False
            if is_ensemble_water and is_ensemble_disease:
                st.markdown("""
                <div style="font-size: 0.75rem; color: #8E44AD; margin-top: 8px; padding: 6px 10px; 
                     background: rgba(142, 68, 173, 0.08); border-radius: 8px;">
                    🤖 Voting Ensemble Active<br>
                    <small>(XGBoost + RF + Decision Tree)</small>
                </div>
                """, unsafe_allow_html=True)

        st.markdown("---")
        st.markdown("""
        <div class="sidebar-footer">
            <small>Version 2.0.0<br>© 2026 HealthTech Solutions</small>
        </div>
        """, unsafe_allow_html=True)


# ── Main App ──
def main():
    # Load models if not loaded
    if not st.session_state.models_loaded:
        water_model, disease_model, error = load_models()

        if error:
            st.error(f"❌ Model loading error: {error}")
            st.info("Run `python models/train_models.py` to train the models first.")
            # Still try to load data
            timeline, alerts = load_data()
            if timeline is not None:
                st.session_state.timeline_data = timeline
            if alerts is not None:
                st.session_state.alert_data = alerts
            return
        else:
            st.session_state.water_model = water_model
            st.session_state.disease_model = disease_model
            st.session_state.models_loaded = True

            # Load data
            timeline, alerts = load_data()
            if timeline is not None:
                st.session_state.timeline_data = timeline
            if alerts is not None:
                st.session_state.alert_data = alerts

    # Render UI
    render_header()
    # Ambient background and wave elements
    st.markdown("""
    <div class="bg-layer">
        <div class="bg-ambient"></div>
        <div class="bg-droplets"></div>
    </div>
    <!-- Water Tap Animation — L-shaped pipe, inlet from right, outlet to bottom -->
    <div class="bg-tap">
        <div class="bg-tap-pipe"></div>
        <div class="bg-tap-valve"></div>
        <div class="bg-tap-elbow"></div>
        <div class="bg-tap-stream"></div>
        <div class="bg-tap-drop"></div>
        <div class="bg-tap-drop d2"></div>
        <div class="bg-tap-drop d3"></div>
        <div class="bg-tap-drop d4"></div>
    </div>
    <div class="wave-container">
        <div class="wave wave-1"></div>
        <div class="wave wave-2"></div>
        <div class="wave wave-3"></div>
    </div>
    """, unsafe_allow_html=True)
    render_sidebar()

    # Navigation
    st.markdown("""
    <div class="nav-tabs">
        <a href="/" target="_self" class="nav-tab active">
            <span>📊</span> Overview
        </a>
    </div>
    """, unsafe_allow_html=True)

    # Use Streamlit navigation
    overview_page = st.Page("pages/overview.py", title="Overview Dashboard", icon="📊", default=True)
    detail_page = st.Page("pages/location_detail.py", title="Location Detail & Analysis", icon="🔬")
    data_analysis_page = st.Page("pages/data_analysis.py", title="Data Analysis & Upload", icon="📂")
    alerts_page = st.Page("pages/alerts_log.py", title="Alerts Log", icon="🚨")
    about_page = st.Page("pages/about.py", title="About & Methodology", icon="ℹ️")

    pg = st.navigation([overview_page, detail_page, data_analysis_page, alerts_page, about_page])
    pg.run()


if __name__ == '__main__':
    main()
