"""
Aarogya Jal — Smart Community Health Monitoring & Early Warning System
"""
