"""
data_analysis.py
Data Analysis & Upload Page — provides:
- CSV file upload for water quality data
- Batch prediction (Safe/Unsafe with confidence scores)
- Results aggregation with download capability
- EDA visualizations: missing values, class distribution, correlation heatmap
- Model evaluation: accuracy chart, confusion matrix, feature importance
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import plotly.figure_factory as ff
from io import StringIO
import joblib

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from app.utils.data_generator import WATER_FEATURES
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False
    XGBClassifier = None


# ── Model directory for saving retrained models ──
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'models', 'trained_models')



# ── Required CSV columns ──
REQUIRED_COLS = list(WATER_FEATURES.keys())
SAMPLE_HEADER = ",".join(REQUIRED_COLS)


def render_upload_section():
    """File uploader for water quality CSV data."""
    st.markdown("""
    <div class="form-section">
        <h3 class="form-title">📁 Upload Water Quality Data</h3>
        <p class="form-subtitle">Upload a CSV file with water quality parameters to get batch predictions</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="info-card" style="margin-bottom: 16px;">
        <div class="info-card-title">📋 Required CSV Format</div>
        <div class="info-card-grid">
            <div><strong>Columns needed:</strong> {', '.join(REQUIRED_COLS)}</div>
            <div><strong>Example:</strong> <code style="font-size: 0.75rem;">{SAMPLE_HEADER[:80]}...</code></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "Choose a CSV file",
        type=['csv'],
        help="Upload a CSV file with water quality parameters (pH, Hardness, Solids, etc.)"
    )

    return uploaded_file


def load_and_validate_csv(uploaded_file):
    """Load CSV and validate required columns exist (case-insensitive)."""
    if uploaded_file is None:
        return None, None

    try:
        df = pd.read_csv(uploaded_file)
    except Exception as e:
        return None, f"❌ Error reading CSV: {e}"

    # Normalize column names to lowercase for case-insensitive matching
    df.columns = [c.strip().lower() for c in df.columns]
    df.rename(columns={'potability': 'Potability'}, inplace=True)

    # Check for required columns (now all lowercase)
    required_lower = [c.lower() for c in REQUIRED_COLS]
    missing_cols = [c for c in required_lower if c not in df.columns]
    if missing_cols:
        return None, f"❌ Missing columns: {', '.join(missing_cols)}"

    # Warn about extra columns but don't fail
    extra_cols = [c for c in df.columns if c not in required_lower + ['Potability']]
    if extra_cols:
        st.warning(f"⚠️ Extra columns ignored: {', '.join(extra_cols[:5])}")

    # Keep Potability column if it exists (needed for auto-retrain feature)
    cols_to_return = required_lower.copy()
    if 'Potability' in df.columns:
        cols_to_return.append('Potability')

    return df[cols_to_return].copy(), None


def run_batch_prediction(df, water_model):
    """Run batch prediction on all rows (case-insensitive column matching)."""
    if water_model is None:
        return None, "Models not loaded. Please go to Overview page first."

    feature_cols = water_model['feature_cols']
    inference_model = water_model['model']

    # Normalize column names for case-insensitive matching
    df = df.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    feature_cols_lower = [c.lower() for c in feature_cols]

    # Ensure all required features exist
    missing = [c for c in feature_cols_lower if c not in df.columns]
    if missing:
        return None, f"❌ Missing feature columns: {', '.join(missing)}"

    input_df = df[feature_cols_lower].copy()
    # Restore original column names for model compatibility
    input_df.columns = feature_cols

    # Handle missing values (fill with median)
    for col in input_df.columns:
        if input_df[col].isnull().any():
            input_df[col] = input_df[col].fillna(input_df[col].median())

    # Predict
    probas = inference_model.predict_proba(input_df)
    predictions = inference_model.predict(input_df)

    # Build results
    results = df.copy()
    results['Potability_Prediction'] = predictions
    results['Potable_Confidence'] = np.max(probas, axis=1)
    results['Status'] = results['Potability_Prediction'].apply(
        lambda x: '✅ Safe (Potable)' if x == 1 else '🚫 Unsafe (Contaminated)'
    )
    results['Confidence_Pct'] = results['Potable_Confidence'].apply(lambda x: f"{x:.1%}")

    return results, None


def render_aggregation(results):
    """Show safe vs unsafe counts with download."""
    if results is None:
        return

    total = len(results)
    safe = results['Potability_Prediction'].sum()
    unsafe = total - safe
    safe_pct = safe / total * 100
    unsafe_pct = unsafe / total * 100

    st.markdown("### 📊 Prediction Results")

    # Metric cards
    cols = st.columns(4)
    with cols[0]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Total Samples</div>
            <div class="metric-value">{total}</div>
            <div class="metric-sub">Processed</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[1]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">✅ Safe (Potable)</div>
            <div class="metric-value" style="color: #2ECC71;">{safe}</div>
            <div class="metric-sub">{safe_pct:.1f}% of total</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[2]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">🚫 Unsafe</div>
            <div class="metric-value" style="color: #E74C3C;">{unsafe}</div>
            <div class="metric-sub">{unsafe_pct:.1f}% of total</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[3]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Avg Confidence</div>
            <div class="metric-value" style="color: #3498DB;">{results['Potable_Confidence'].mean():.1%}</div>
            <div class="metric-sub">Model certainty</div>
        </div>
        """, unsafe_allow_html=True)

    # Pie chart
    fig = go.Figure(data=[go.Pie(
        labels=['✅ Safe (Potable)', '🚫 Unsafe (Contaminated)'],
        values=[safe, unsafe],
        marker_colors=['#2ECC71', '#E74C3C'],
        textinfo='label+percent',
        textfont=dict(color='#FFFFFF', size=14),
        hole=0.4,
    )])
    fig.update_layout(
        height=300,
        margin=dict(l=10, r=10, t=10, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
        showlegend=False,
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Show results table
    with st.expander("📋 View Detailed Results", expanded=False):
        display_cols = ['Status', 'Confidence_Pct'] + [c.lower() for c in REQUIRED_COLS[:6]]
        # Only use columns that actually exist in the results
        display_cols = [c for c in display_cols if c in results.columns]
        st.dataframe(
            results[display_cols],
            use_container_width=True,
            hide_index=True,
            height=300,
        )

    # Download button
    csv_buffer = StringIO()
    results.to_csv(csv_buffer, index=False)
    st.download_button(
        label="📥 Download Prediction Results as CSV",
        data=csv_buffer.getvalue(),
        file_name="water_quality_predictions.csv",
        mime="text/csv",
        use_container_width=True,
    )


def train_model_from_data(df):
    """Train a new Voting Ensemble model from uploaded dataset with Potability column."""
    if 'Potability' not in df.columns:
        return None, "❌ Dataset must have a 'Potability' column for training."

    feature_cols = [c for c in df.columns if c != 'Potability']
    X = df[feature_cols].copy()
    y = df['Potability'].values

    # Handle missing values
    for col in X.columns:
        if X[col].isnull().any():
            X[col] = X[col].fillna(X[col].median())

    # Check class distribution
    classes, counts = np.unique(y, return_counts=True)
    if len(classes) < 2:
        return None, "❌ Dataset must contain BOTH Safe (1) and Unsafe (0) samples for training."
    if min(counts) < 5:
        return None, f"❌ Each class needs at least 5 samples. Found: {dict(zip(classes, counts))}"

    # Train/Test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Build models
    rf = RandomForestClassifier(n_estimators=200, max_depth=15, random_state=42, n_jobs=-1)
    dt = DecisionTreeClassifier(max_depth=10, random_state=42)

    if XGB_AVAILABLE:
        xgb = XGBClassifier(n_estimators=150, max_depth=8, random_state=42, verbosity=0)
        estimators = [('XGBoost', xgb), ('Random Forest', rf), ('Decision Tree', dt)]
    else:
        estimators = [('Random Forest', rf), ('Decision Tree', dt)]

    ensemble = VotingClassifier(estimators=estimators, voting='soft')
    ensemble.fit(X_train, y_train)

    # Evaluate
    y_pred = ensemble.predict(X_test)
    y_prob = ensemble.predict_proba(X_test)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    cm = confusion_matrix(y_test, y_pred)

    # Cross-validation
    try:
        cv_scores = cross_val_score(ensemble, X, y, cv=min(5, min(counts)), scoring='accuracy')
        cv_mean = float(cv_scores.mean())
        cv_std = float(cv_scores.std())
    except Exception:
        cv_mean = acc
        cv_std = 0.0

    # Feature importance (from Random Forest)
    rf.fit(X_train, y_train)
    importance = [{'feature': col, 'importance': float(imp)}
                  for col, imp in zip(feature_cols, rf.feature_importances_)]

    # Confusion matrix data
    cm_labels = ['Unsafe (0)', 'Safe (1)']
    if cm.shape == (2, 2):
        cm_dict = {
            'matrix': cm.tolist(), 'labels': cm_labels,
            'tn': int(cm[0, 0]), 'fp': int(cm[0, 1]),
            'fn': int(cm[1, 0]), 'tp': int(cm[1, 1]),
        }
    else:
        cm_dict = None

    # Build model data
    model_data = {
        'model': ensemble,
        'feature_cols': feature_cols,
        'metrics': {'accuracy': float(acc), 'f1_score': float(f1)},
        'confusion_matrix': cm_dict,
        'cv_score': cv_mean,
        'cv_std': cv_std,
        'feature_importance': importance,
        'is_ensemble': True,
        'comparison': {
            'Voting Ensemble': {'accuracy': float(acc), 'f1_score': float(f1)},
        },
        'training_data_shape': list(X.shape),
    }

    # Save to disk
    os.makedirs(MODEL_DIR, exist_ok=True)
    save_path = os.path.join(MODEL_DIR, 'water_quality_model.pkl')
    joblib.dump(model_data, save_path)

    # Update session state
    st.session_state.water_model = model_data
    st.session_state.models_loaded = True

    return model_data, f"✅ Model trained! Accuracy: {acc:.2%}, F1 Score: {f1:.2%}"


def render_eda_missing_values(df):
    """Missing values bar chart."""
    if df is None:
        st.info("No data available for missing values analysis.")
        return
    missing = df.isnull().sum()
    missing_pct = (missing / len(df)) * 100

    if missing.sum() == 0:
        st.info("✅ No missing values found in the uploaded data.")
        return

    missing_df = pd.DataFrame({
        'Feature': missing.index,
        'Missing Count': missing.values,
        'Missing %': missing_pct.values,
    }).sort_values('Missing %', ascending=False)

    fig = go.Figure(go.Bar(
        x=missing_df['Feature'],
        y=missing_df['Missing %'],
        marker_color='#E74C3C',
        text=[f"{v:.1f}%" for v in missing_df['Missing %']],
        textposition='outside',
        hovertemplate='%{x}: %{y:.1f}% missing<extra></extra>',
    ))
    fig.update_layout(
        title=dict(
            text='<b>Missing Values by Feature</b>',
            font=dict(color='#ECE3D0', size=16),
            x=0,
        ),
        xaxis=dict(title='Feature', tickfont=dict(color='#C9BFA9')),
        yaxis=dict(title='Missing (%)', tickfont=dict(color='#C9BFA9'),
                   gridcolor='rgba(255,255,255,0.06)'),
        height=350,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})


def render_eda_class_distribution(df):
    """Show class distribution if Potability column exists."""
    if 'Potability' not in df.columns:
        st.info("ℹ️ Upload data with a 'Potability' column to see class distribution.")
        return

    counts = df['Potability'].value_counts().sort_index()
    labels = ['Unsafe (0)', 'Safe (1)']

    fig = go.Figure(go.Bar(
        x=labels,
        y=counts.values,
        marker_color=['#E74C3C', '#2ECC71'],
        text=counts.values,
        textposition='outside',
        hovertemplate='%{x}: %{y} samples<extra></extra>',
    ))
    fig.update_layout(
        title=dict(
            text='<b>Class Distribution — Safe vs Unsafe</b>',
            font=dict(color='#ECE3D0', size=16),
            x=0,
        ),
        xaxis=dict(title='Class', tickfont=dict(color='#C9BFA9')),
        yaxis=dict(title='Count', tickfont=dict(color='#C9BFA9'),
                   gridcolor='rgba(255,255,255,0.06)'),
        height=350,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Imbalance ratio
    total = counts.sum()
    ratio = counts.iloc[0] / counts.iloc[1] if counts.iloc[1] > 0 else float('inf')
    st.markdown(f"""
    <div style="font-size: 0.85rem; color: #C9BFA9; margin-top: 4px;">
        <strong>Imbalance Ratio:</strong> {ratio:.2f}:1 (Unsafe : Safe) | 
        <strong>Total:</strong> {total} samples
    </div>
    """, unsafe_allow_html=True)


def render_eda_correlation_heatmap(df):
    """Correlation heatmap of water quality features (case-insensitive)."""
    # Normalize df columns to lowercase for matching
    df = df.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    corr_cols = [c.lower() for c in REQUIRED_COLS if c.lower() in df.columns]
    if len(corr_cols) < 3:
        st.info("Not enough features for correlation heatmap.")
        return

    corr_df = df[corr_cols].corr()

    fig = ff.create_annotated_heatmap(
        z=corr_df.values,
        x=list(corr_df.columns),
        y=list(corr_df.columns),
        colorscale='RdBu_r',
        zmin=-1, zmax=1,
        showscale=True,
        font_colors=['white', 'white'],
    )
    fig.update_layout(
        title=dict(
            text='<b>Feature Correlation Heatmap</b>',
            font=dict(color='#ECE3D0', size=16),
            x=0,
        ),
        height=500,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0', size=10),
        xaxis=dict(tickfont=dict(color='#C9BFA9', size=9)),
        yaxis=dict(tickfont=dict(color='#C9BFA9', size=9)),
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Key insights
    st.markdown("""
    <div style="font-size: 0.8rem; color: #C9BFA9; margin-top: 4px;">
        <strong>🔍 Insight:</strong> Red = positive correlation, Blue = negative correlation.
        Features with strong correlations may be redundant for modeling.
    </div>
    """, unsafe_allow_html=True)


def render_confusion_matrix():
    """Render a real confusion matrix heatmap from model data."""
    if not st.session_state.models_loaded:
        return

    water_model = st.session_state.water_model
    if water_model is None:
        return

    cm_data = water_model.get('confusion_matrix', None)
    if cm_data is None:
        st.info("Confusion matrix not available. Retrain the models to generate it.")
        return

    st.markdown("### 🎯 Confusion Matrix")

    matrix = cm_data['matrix']
    labels = cm_data['labels']

    fig = ff.create_annotated_heatmap(
        z=matrix,
        x=labels,
        y=labels,
        colorscale='Blues',
        showscale=True,
        font_colors=['white', 'white'],
        text=[
            [f'TN: {matrix[0][0]}<br>(Correct Reject)', f'FP: {matrix[0][1]}<br>(False Alarm)'],
            [f'FN: {matrix[1][0]}<br>(Missed)', f'TP: {matrix[1][1]}<br>(Correct Hit)'],
        ],
        hoverinfo='text',
    )
    fig.update_layout(
        title=dict(
            text='<b>True Labels vs Predicted Labels</b>',
            font=dict(color='#ECE3D0', size=16),
            x=0,
        ),
        xaxis=dict(title='Predicted Label', tickfont=dict(color='#C9BFA9')),
        yaxis=dict(title='True Label', tickfont=dict(color='#C9BFA9')),
        height=380,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
    )
    # Fix annotation font colors
    for i in range(len(fig.layout.annotations)):
        fig.layout.annotations[i].font.color = '#FFFFFF'
        fig.layout.annotations[i].font.size = 13
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Metrics from confusion matrix
    tn = cm_data['tn']
    fp = cm_data['fp']
    fn = cm_data['fn']
    tp = cm_data['tp']
    total = tn + fp + fn + tp

    accuracy = (tp + tn) / total if total > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

    cols = st.columns(4)
    with cols[0]:
        st.markdown(f'<div style="text-align:center; font-size:0.85rem; color:#C9BFA9;"><strong>Accuracy</strong><br><span style="color:#2ECC71; font-size:1.2rem;">{accuracy:.1%}</span></div>', unsafe_allow_html=True)
    with cols[1]:
        st.markdown(f'<div style="text-align:center; font-size:0.85rem; color:#C9BFA9;"><strong>Precision</strong><br><span style="color:#3498DB; font-size:1.2rem;">{precision:.1%}</span></div>', unsafe_allow_html=True)
    with cols[2]:
        st.markdown(f'<div style="text-align:center; font-size:0.85rem; color:#C9BFA9;"><strong>Recall</strong><br><span style="color:#E8A33D; font-size:1.2rem;">{recall:.1%}</span></div>', unsafe_allow_html=True)
    with cols[3]:
        st.markdown(f'<div style="text-align:center; font-size:0.85rem; color:#C9BFA9;"><strong>F1 Score</strong><br><span style="color:#9B59B6; font-size:1.2rem;">{f1:.1%}</span></div>', unsafe_allow_html=True)


def render_accuracy_comparison():
    """Show accuracy and F1 comparison chart across all trained models."""
    if not st.session_state.models_loaded:
        st.info("Train the models first to see accuracy comparison.")
        return

    water_model = st.session_state.water_model
    if water_model is None:
        return

    st.markdown("### 🎯 Confusion Matrix")

    # We can't get the actual confusion matrix from saved model data directly
    # but we can show the comparison metrics visually
    comparison = water_model.get('comparison', {})
    if not comparison:
        st.info("Model comparison data not available.")
        return

    # Accuracy comparison chart
    models_list = list(comparison.keys())
    accuracies = [comparison[m].get('accuracy', 0) * 100 for m in models_list]
    f1_scores = [comparison[m].get('f1_score', 0) * 100 for m in models_list]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name='Accuracy (%)',
        x=models_list,
        y=accuracies,
        marker_color='#3498DB',
        text=[f"{v:.1f}%" for v in accuracies],
        textposition='outside',
    ))
    fig.add_trace(go.Bar(
        name='F1 Score (%)',
        x=models_list,
        y=f1_scores,
        marker_color='#2ECC71',
        text=[f"{v:.1f}%" for v in f1_scores],
        textposition='outside',
    ))

    fig.update_layout(
        title=dict(
            text='<b>Model Performance Comparison</b>',
            font=dict(color='#ECE3D0', size=16),
            x=0,
        ),
        barmode='group',
        xaxis=dict(title='Model', tickfont=dict(color='#C9BFA9')),
        yaxis=dict(title='Score (%)', tickfont=dict(color='#C9BFA9'),
                   gridcolor='rgba(255,255,255,0.06)', range=[0, 100]),
        height=400,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
        legend=dict(
            orientation='h', yanchor='bottom', y=1.02,
            xanchor='right', x=1,
            font=dict(color='#C9BFA9'),
        ),
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Ensemble highlight
    if 'Voting Ensemble' in comparison:
        ensemble = comparison['Voting Ensemble']
        st.markdown(f"""
        <div class="rec-card rec-low" style="margin-top: 8px;">
            <div class="rec-header">
                <span class="rec-emoji">🏆</span>
                <span class="rec-title">Voting Ensemble Performance</span>
            </div>
            <p class="rec-text">
                Accuracy: <strong>{ensemble.get('accuracy', 0):.2%}</strong> | 
                F1 Score: <strong>{ensemble.get('f1_score', 0):.2%}</strong>
                {f'| ROC AUC: <strong>{ensemble.get("roc_auc", 0):.2%}</strong>' if ensemble.get('roc_auc') else ''}
            </p>
        </div>
        """, unsafe_allow_html=True)


def render_feature_importance():
    """Feature importance bar chart from trained model."""
    if not st.session_state.models_loaded:
        return

    water_model = st.session_state.water_model
    if water_model is None:
        return

    importance = water_model.get('feature_importance', [])
    if not importance:
        st.info("Feature importance data not available.")
        return

    st.markdown("### 🔬 Feature Importance")

    imp_df = pd.DataFrame(importance).sort_values('importance', ascending=True)
    imp_df['importance_pct'] = imp_df['importance'] * 100

    fig = go.Figure(go.Bar(
        x=imp_df['importance_pct'],
        y=imp_df['feature'],
        orientation='h',
        marker=dict(
            color=imp_df['importance_pct'],
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(title='Importance %', tickfont=dict(color='#C9BFA9')),
        ),
        text=[f"{v:.1f}%" for v in imp_df['importance_pct']],
        textposition='outside',
        hovertemplate='%{y}: %{x:.1f}%<extra></extra>',
    ))
    fig.update_layout(
        title=dict(
            text='<b>Which features matter most for water quality prediction?</b>',
            font=dict(color='#ECE3D0', size=14),
            x=0,
        ),
        xaxis=dict(title='Importance (%)', tickfont=dict(color='#C9BFA9'),
                   gridcolor='rgba(255,255,255,0.06)'),
        yaxis=dict(tickfont=dict(color='#C9BFA9'), autorange="reversed"),
        height=400,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#ECE3D0'),
    )
    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Top features summary
    top_features = imp_df.tail(3)
    st.markdown("""
    <div style="font-size: 0.85rem; color: #C9BFA9; margin-top: 4px;">
        <strong>🎯 Key Insight:</strong> The model relies most on 
    """ + ", ".join([f"<strong>{row['feature']}</strong> ({row['importance_pct']:.1f}%)"
                     for _, row in top_features.iterrows()]) + 
    """ to determine water potability.
    </div>
    """, unsafe_allow_html=True)


def render_accuracy_card():
    """Show model accuracy prominently."""
    if not st.session_state.models_loaded:
        return

    water_model = st.session_state.water_model
    if water_model is None:
        return

    metrics = water_model.get('metrics', {})
    cv_score = water_model.get('cv_score', 0)
    cv_std = water_model.get('cv_std', 0)

    st.markdown("### 📈 Model Accuracy")

    cols = st.columns(3)
    with cols[0]:
        accuracy = metrics.get('accuracy', 0)
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">🎯 Accuracy</div>
            <div class="result-card-value" style="color: #2ECC71;">{accuracy:.1%}</div>
            <div class="result-card-sub">Random Forest Ensemble</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[1]:
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">📊 Cross-Validation</div>
            <div class="result-card-value" style="color: #3498DB;">{cv_score:.1%} ± {cv_std:.2%}</div>
            <div class="result-card-sub">5-Fold CV Score</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[2]:
        f1 = metrics.get('f1_score', 0)
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">📏 F1 Score</div>
            <div class="result-card-value" style="color: #E8A33D;">{f1:.1%}</div>
            <div class="result-card-sub">Weighted F1 Score</div>
        </div>
        """, unsafe_allow_html=True)


def render():
    """Main render function."""
    st.markdown("<h2 class='page-title'>📊 Data Analysis & Upload</h2>", unsafe_allow_html=True)
    st.markdown("""
    <p class="page-subtitle">
        Upload water quality data, run batch predictions, explore EDA visuals, and evaluate model performance
    </p>
    """, unsafe_allow_html=True)

    # ── Section 1: Model Accuracy (always visible if models loaded) ──
    if st.session_state.models_loaded:
        render_accuracy_card()
        st.markdown("---")

    # ── Section 2: CSV Upload & Batch Prediction ──
    uploaded_file = render_upload_section()

    if uploaded_file is not None:
        df, err = load_and_validate_csv(uploaded_file)

        if err:
            st.error(err)
        elif df is not None:
            st.success(f"✅ Loaded {len(df)} rows with {len(df.columns)} water quality features")

            # Show preview
            with st.expander("👁️ Preview Uploaded Data", expanded=False):
                st.dataframe(df.head(10), use_container_width=True, hide_index=True)
                st.markdown(f"""
                <div style="font-size: 0.8rem; color: #C9BFA9;">
                    Showing first 10 of {len(df)} rows | {df.memory_usage(deep=True).sum() / 1024:.1f} KB
                </div>
                """, unsafe_allow_html=True)

            st.markdown("---")

            # Run batch prediction
            if st.session_state.models_loaded:
                with st.spinner("🔄 Running batch predictions on uploaded data..."):
                    results, pred_err = run_batch_prediction(df, st.session_state.water_model)

                if pred_err:
                    st.error(pred_err)
                elif results is not None:
                    render_aggregation(results)

            st.markdown("---")

            # ── Retrain Model Button (Potability column already normalized by load_and_validate_csv) ──
            if 'Potability' in df.columns:

                st.markdown("""
                <div class="section-header">
                    <span class="section-icon">🤖</span>
                    <span>Auto-Retrain Model on Uploaded Data</span>
                </div>
                """, unsafe_allow_html=True)

                st.markdown(f"""
                <div class="info-card" style="margin-bottom: 8px;">
                    <div class="info-card-grid">
                        <div><strong>Potability column detected!</strong></div>
                        <div>Your dataset has <strong>{len(df)} rows</strong> with ground-truth labels.</div>
                        <div style="color: #C9BFA9; font-size: 0.85rem;">
                            Click below to train a brand-new Voting Ensemble model on your data. 
                            The current model will be replaced.
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                col1, col2, col3 = st.columns([1, 1, 1])
                with col2:
                    retrain_clicked = st.button(
                        "🤖 Retrain Model on This Data",
                        type="primary",
                        use_container_width=True,
                    )

                if retrain_clicked:
                    with st.spinner("🔄 Training Voting Ensemble model on your data..."):
                        new_model, msg = train_model_from_data(df)

                    if new_model is not None:
                        st.success(msg)
                        st.balloons()

                        # Show training results
                        st.markdown("### 🏆 Training Results")
                        metrics = new_model['metrics']
                        cv = new_model['cv_score']
                        cm_data = new_model.get('confusion_matrix')

                        res_cols = st.columns(3)
                        with res_cols[0]:
                            st.markdown(f'<div class="result-card"><div class="result-card-header">🎯 Accuracy</div><div class="result-card-value" style="color:#2ECC71;">{metrics["accuracy"]:.2%}</div><div class="result-card-sub">On test set</div></div>', unsafe_allow_html=True)
                        with res_cols[1]:
                            st.markdown(f'<div class="result-card"><div class="result-card-header">📏 F1 Score</div><div class="result-card-value" style="color:#3498DB;">{metrics["f1_score"]:.2%}</div><div class="result-card-sub">Weighted average</div></div>', unsafe_allow_html=True)
                        with res_cols[2]:
                            st.markdown(f'<div class="result-card"><div class="result-card-header">📊 CV Score</div><div class="result-card-value" style="color:#E8A33D;">{cv:.2%}</div><div class="result-card-sub">Cross-validation</div></div>', unsafe_allow_html=True)

                        if cm_data:
                            st.markdown("<br>", unsafe_allow_html=True)
                            tn, fp, fn, tp = cm_data['tn'], cm_data['fp'], cm_data['fn'], cm_data['tp']
                            st.markdown(f"""
                            <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; font-size: 0.9rem; color: #C9BFA9;">
                                <span>✅ <strong>TN:</strong> {tn}</span>
                                <span>⚠️ <strong>FP:</strong> {fp}</span>
                                <span>⚠️ <strong>FN:</strong> {fn}</span>
                                <span>✅ <strong>TP:</strong> {tp}</span>
                                <span><strong>Samples:</strong> {new_model.get('training_data_shape', ['N/A'])[0]}</span>
                            </div>
                            """, unsafe_allow_html=True)

                        st.info("🔄 Refresh the page to see updated Confusion Matrix, Accuracy Chart, and Feature Importance based on your new model!")
                    else:
                        st.error(msg)

            else:
                st.info("💡 Upload a dataset with a 'Potability' column to enable auto-retraining of the model on your custom data.")

    st.markdown("---")

    # ── Section 3: EDA Dashboard ──
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">📊</span>
        <span>Exploratory Data Analysis (EDA)</span>
    </div>
    """, unsafe_allow_html=True)

    # Use uploaded data if available
    eda_df = df if (uploaded_file is not None and df is not None) else None

    # Helper to get the water potability CSV path
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
    water_csv = os.path.join(data_dir, 'water_potability.csv')

    if eda_df is not None or os.path.exists(water_csv):
        tab1, tab2, tab3 = st.tabs(["📉 Missing Values", "📊 Class Distribution", "🔗 Correlation Matrix"])

        with tab1:
            if eda_df is not None:
                render_eda_missing_values(eda_df)
            else:
                st.info("Upload a CSV file to see missing values analysis.")

        with tab2:
            # Load original water data for class distribution
            if os.path.exists(water_csv):
                water_data = pd.read_csv(water_csv)
                if 'Potability' in water_data.columns:
                    render_eda_class_distribution(water_data)

        with tab3:
            if uploaded_file is not None and df is not None:
                render_eda_correlation_heatmap(df)
            elif os.path.exists(water_csv):
                water_data = pd.read_csv(water_csv)
                render_eda_correlation_heatmap(water_data)
            else:
                st.info("Upload water quality CSV data to see correlation heatmap.")
    else:
        st.markdown("""
        <div class="placeholder-card">
            <div class="placeholder-icon">📊</div>
            <div class="placeholder-text">
                <h3>Upload Data to Explore</h3>
                <p>Upload a CSV file above to see Missing Values, Class Distribution, and Correlation Heatmap visualizations.</p>
            </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Section 4: Model Evaluation ──
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🧪</span>
        <span>Model Evaluation Metrics</span>
    </div>
    """, unsafe_allow_html=True)

    if st.session_state.models_loaded:
        # Show real confusion matrix first
        render_confusion_matrix()
        st.markdown("<br>", unsafe_allow_html=True)

        col1, col2 = st.columns(2)

        with col1:
            render_accuracy_comparison()

        with col2:
            render_feature_importance()

        # Cross-validation details
        water_model = st.session_state.water_model
        disease_model = st.session_state.disease_model
        if water_model and disease_model:
            st.markdown("---")
            st.markdown("### 📋 Model Details")

            mcol1, mcol2 = st.columns(2)
            with mcol1:
                st.markdown(f"""
                <div class="info-card">
                    <div class="info-card-title">💧 Water Quality Model</div>
                    <div class="info-card-grid">
                        <div><strong>Algorithm:</strong> Voting Ensemble</div>
                        <div><strong>Estimators:</strong> XGBoost + RF + DT</div>
                        <div><strong>CV Score:</strong> {water_model.get('cv_score', 'N/A'):.2%}</div>
                        <div><strong>Is Ensemble:</strong> {'✅ Yes' if water_model.get('is_ensemble') else '❌ No'}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

            with mcol2:
                st.markdown(f"""
                <div class="info-card">
                    <div class="info-card-title">🦠 Disease Prediction Model</div>
                    <div class="info-card-grid">
                        <div><strong>Algorithm:</strong> Voting Ensemble</div>
                        <div><strong>Estimators:</strong> XGBoost + RF + DT</div>
                        <div><strong>CV Score:</strong> {disease_model.get('cv_score', 'N/A'):.2%}</div>
                        <div><strong>Is Ensemble:</strong> {'✅ Yes' if disease_model.get('is_ensemble') else '❌ No'}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

    else:
        st.info("Train the models first to see evaluation metrics. Run `python models/train_models.py`")


st.markdown("""<div class=\"page-content\">""", unsafe_allow_html=True)
render()
st.markdown("""</div>""", unsafe_allow_html=True)
