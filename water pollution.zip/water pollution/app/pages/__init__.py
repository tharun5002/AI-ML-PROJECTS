"""
Aarogya Jal — Streamlit dashboard pages.
"""
