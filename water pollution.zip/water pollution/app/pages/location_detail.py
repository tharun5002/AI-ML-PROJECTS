"""
location_detail.py
Location Detail & Data Entry Screen.
Interactive form for entering water quality readings and symptom reports,
then runs both ML models and displays the fused outbreak risk.

Features:
- Water quality input sliders
- Symptom report checkboxes
- Model prediction + combined risk
- Explainability panel (SHAP/feature importance)
- Recommendation box
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from app.utils.data_generator import LOCATIONS, WATER_FEATURES, ALL_WATER_BORNE_SYMPTOMS
from app.utils.risk_fusion import (
    get_risk_level, get_risk_color, calculate_risk_score,
    apply_severity_weight, get_risk_recommendation, RISK_COLORS, RISK_EMOJIS
)
from app.utils.explainability import (
    explain_water_prediction, explain_disease_prediction,
    generate_explainability_chart
)
from app.utils.recommendations import get_recommendation


def render_water_quality_form():
    """Interactive form for water quality parameters."""
    st.markdown("""
    <div class="form-section">
        <h3 class="form-title">💧 Water Quality Parameters</h3>
        <p class="form-subtitle">Enter water test readings from the community source</p>
    </div>
    """, unsafe_allow_html=True)

    cols = st.columns(3)
    inputs = {}

    features_list = list(WATER_FEATURES.keys())
    for i, feature in enumerate(features_list):
        config = WATER_FEATURES[feature]
        col = cols[i % 3]

        # Friendly names
        display_names = {
            'ph': 'pH Level',
            'Hardness': 'Hardness (mg/L)',
            'Solids': 'Total Solids (mg/L)',
            'Chloramines': 'Chloramines (mg/L)',
            'Sulfate': 'Sulfate (mg/L)',
            'Conductivity': 'Conductivity (μS/cm)',
            'Organic_carbon': 'Organic Carbon (mg/L)',
            'Trihalomethanes': 'Trihalomethanes (μg/L)',
            'Turbidity': 'Turbidity (NTU)',
        }

        # Default values (typical unsafe water)
        default_vals = {
            'ph': 5.8,
            'Hardness': 250,
            'Solids': 35000,
            'Chloramines': 7.5,
            'Sulfate': 280,
            'Conductivity': 550,
            'Organic_carbon': 18,
            'Trihalomethanes': 95,
            'Turbidity': 5.2,
        }

        default = default_vals.get(feature, config['mean'])
        val = col.slider(
            display_names.get(feature, feature),
            min_value=float(config['min']),
            max_value=float(config['max']),
            value=float(default),
            format="%.1f",
            help=f"Range: {config['min']:.1f} - {config['max']:.1f}",
            key=f"water_{feature}",
        )
        inputs[feature] = val

    return inputs


def render_symptom_form():
    """Interactive form for symptom reporting."""
    st.markdown("""
    <div class="form-section">
        <h3 class="form-title">🩺 Community Symptom Reports</h3>
        <p class="form-subtitle">Select symptoms reported in the community (last 7 days)</p>
    </div>
    """, unsafe_allow_html=True)

    cols = st.columns(3)
    symptoms = {}

    for i, symptom in enumerate(ALL_WATER_BORNE_SYMPTOMS):
        col = cols[i % 3]
        display_name = symptom.replace('_', ' ')
        symptoms[symptom] = col.checkbox(display_name, key=f"symptom_{symptom}")

    return symptoms


def align_water_input_keys(input_dict, feature_cols):
    """
    Align water input dictionary keys to the model's feature columns.
    This handles mixed capitalization and ensures the dataframe columns match
    the expected feature order for model prediction.
    """
    normalized = {k.strip().lower(): v for k, v in input_dict.items()}
    aligned = {}
    for col in feature_cols:
        if col in input_dict:
            aligned[col] = input_dict[col]
        else:
            aligned[col] = normalized.get(col.lower(), np.nan)
    return aligned


def render_gauge(score, title="Outbreak Risk Score"):
    """Render a gauge chart for risk score."""
    risk_level = get_risk_level(score)
    risk_color = get_risk_color(score)

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score * 100,
        title={'text': title, 'font': {'size': 16, 'color': '#ECE3D0'}},
        delta={'reference': 50, 'position': 'top'},
        number={'suffix': '%', 'font': {'size': 28, 'color': risk_color}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': '#8A8272',
                     'tickfont': {'color': '#C9BFA9'}},
            'bar': {'color': risk_color, 'thickness': 0.3},
            'bgcolor': 'rgba(0,0,0,0)',
            'borderwidth': 0,
            'steps': [
                {'range': [0, 35], 'color': 'rgba(46, 204, 113, 0.15)'},
                {'range': [35, 65], 'color': 'rgba(241, 196, 15, 0.15)'},
                {'range': [65, 100], 'color': 'rgba(231, 76, 60, 0.15)'},
            ],
            'threshold': {
                'line': {'color': risk_color, 'width': 4},
                'thickness': 0.75,
                'value': score * 100,
            },
        }
    ))

    fig.update_layout(
        height=250,
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': '#ECE3D0', 'family': 'Inter, sans-serif'},
    )

    return fig


def render_explainability_chart(water_explanation, disease_explanation):
    """Render explainability visualizations."""
    tab1, tab2 = st.tabs(["💧 Water Quality Factors", "🦠 Symptom Factors"])

    with tab1:
        chart_data = generate_explainability_chart(water_explanation, 'bar')
        if chart_data and chart_data.get('values'):
            fig = go.Figure(go.Bar(
                x=chart_data['values'],
                y=chart_data['labels'],
                orientation='h',
                marker_color=chart_data['colors'],
                text=[f"{v:.3f}" for v in chart_data['values']],
                textposition='outside',
                hovertemplate='%{y}: %{x:.4f}<extra></extra>',
            ))
            fig.update_layout(
                title=chart_data['title'],
                height=300,
                margin=dict(l=10, r=10, t=40, b=10),
                xaxis_title='SHAP Value (impact on prediction)',
                xaxis=dict(tickfont=dict(color='#C9BFA9'), title_font=dict(color='#C9BFA9')),
                yaxis=dict(autorange="reversed", tickfont=dict(color='#C9BFA9')),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font={'color': '#ECE3D0'},
            )
            st.plotly_chart(fig, use_container_width=True)

        # Show raw contributions table
        with st.expander("📋 View detailed feature contributions"):
            contributions = water_explanation.get('contributions', [])
            if contributions:
                if 'shap_value' in contributions[0]:
                    contrib_df = pd.DataFrame(contributions[:8])
                    contrib_df.columns = ['Feature', 'Value', 'SHAP Value', 'Impact', 'Abs Impact']
                else:
                    contrib_df = pd.DataFrame(contributions[:8])
                    contrib_df.columns = ['Feature', 'Value', 'Importance', 'Abs Impact', 'Impact']
                    contrib_df = contrib_df[['Feature', 'Value', 'Importance']]

                st.dataframe(contrib_df, use_container_width=True, hide_index=True)

    with tab2:
        disease_expl = disease_explanation
        symptoms = disease_expl.get('top_contributing_symptoms', [])

        if symptoms:
            sym_df = pd.DataFrame(symptoms)
            fig = go.Figure(go.Bar(
                x=sym_df['contribution_pct'],
                y=sym_df['symptom'],
                orientation='h',
                marker_color='rgba(231, 76, 60, 0.7)',
                text=[f"{v:.1f}%" for v in sym_df['contribution_pct']],
                textposition='outside',
                hovertemplate='%{y}: %{x:.1f}% contribution<extra></extra>',
            ))
            fig.update_layout(
                title='Top Symptoms Contributing to Prediction',
                height=300,
                margin=dict(l=10, r=10, t=40, b=10),
                xaxis_title='Contribution (%)',
                xaxis=dict(tickfont=dict(color='#C9BFA9'), title_font=dict(color='#C9BFA9')),
                yaxis=dict(autorange="reversed", tickfont=dict(color='#C9BFA9')),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font={'color': '#ECE3D0'},
            )
            st.plotly_chart(fig, use_container_width=True)

            # Disease probability distribution
            prob_dist = disease_expl.get('probability_distribution', {})
            if prob_dist:
                prob_df = pd.DataFrame([
                    {'Disease': d, 'Probability': p}
                    for d, p in prob_dist.items()
                ]).sort_values('Probability', ascending=True)

                fig2 = go.Figure(go.Bar(
                    x=prob_df['Probability'],
                    y=prob_df['Disease'],
                    orientation='h',
                    marker_color='rgba(52, 152, 219, 0.7)',
                    text=[f"{v:.1%}" for v in prob_df['Probability']],
                    textposition='outside',
                    hovertemplate='%{y}: %{x:.1%}<extra></extra>',
                ))
                fig2.update_layout(
                    title='Disease Probability Distribution',
                    height=250,
                    margin=dict(l=10, r=10, t=40, b=10),
                    xaxis_title='Probability',
                    xaxis=dict(tickformat='.0%', tickfont=dict(color='#C9BFA9'), title_font=dict(color='#C9BFA9')),
                    yaxis=dict(autorange="reversed", tickfont=dict(color='#C9BFA9')),
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font={'color': '#ECE3D0'},
                )
                st.plotly_chart(fig2, use_container_width=True)


def run_assessment(water_inputs, symptom_inputs, water_model, disease_model):
    """
    ENHANCEMENT 3: Run the full ML assessment pipeline and return results.
    Called both on button click AND on slider change (real-time mode).
    """
    # ── 1. Water Quality Prediction (Ensemble model) ──
    aligned_water_inputs = align_water_input_keys(water_inputs, water_model['feature_cols'])
    water_features = pd.DataFrame([aligned_water_inputs])[water_model['feature_cols']]

    # Handle missing values (fill with median from training)
    for col in water_model['feature_cols']:
        if col in water_features.columns and water_features[col].isnull().any():
            water_features[col] = water_features[col].fillna(water_features[col].median())

    # The model is now a Voting Ensemble - use it directly
    water_prob_potable = water_model['model'].predict_proba(water_features)[0][1]
    water_is_safe = water_prob_potable >= 0.5
    water_contamination_prob = 1 - water_prob_potable

    # ── 2. Disease Prediction (Ensemble model) ──
    symptom_df = pd.DataFrame([symptom_inputs])
    for col in disease_model['symptom_cols']:
        if col not in symptom_df.columns:
            symptom_df[col] = 0

    symptom_df = symptom_df[disease_model['symptom_cols']]
    disease_pred_probas = disease_model['model'].predict_proba(symptom_df)[0]
    disease_pred_idx = np.argmax(disease_pred_probas)
    disease_pred = disease_model['label_encoder'].inverse_transform([disease_pred_idx])[0]
    disease_confidence = float(disease_pred_probas[disease_pred_idx])

    # ── 3. Risk Fusion ──
    adjusted_disease_prob = apply_severity_weight(disease_confidence, disease_pred)
    combined_score, risk_level, risk_details = calculate_risk_score(
        water_contamination_prob, adjusted_disease_prob
    )

    # ── 4. Explanations ──
    water_explanation = explain_water_prediction(water_model, aligned_water_inputs)
    disease_explanation = explain_disease_prediction(disease_model, symptom_inputs)

    # ── 5. Recommendations ──
    rec = get_recommendation(risk_level, disease_pred, water_is_safe)

    return {
        'water_is_safe': water_is_safe,
        'water_prob_potable': water_prob_potable,
        'water_contamination_prob': water_contamination_prob,
        'disease_pred': disease_pred,
        'disease_confidence': disease_confidence,
        'combined_score': combined_score,
        'risk_level': risk_level,
        'risk_details': risk_details,
        'water_explanation': water_explanation,
        'disease_explanation': disease_explanation,
        'rec': rec,
    }


def render_results(results):
    """Display assessment results in the UI."""
    if results is None:
        return

    water_is_safe = results['water_is_safe']
    water_prob_potable = results['water_prob_potable']
    disease_pred = results['disease_pred']
    disease_confidence = results['disease_confidence']
    combined_score = results['combined_score']
    risk_level = results['risk_level']
    risk_details = results['risk_details']
    water_explanation = results['water_explanation']
    disease_explanation = results['disease_explanation']
    rec = results['rec']

    st.markdown("""
    <div class="results-section">
        <h2>📋 Assessment Results</h2>
    </div>
    """, unsafe_allow_html=True)

    # Three columns for results
    res_col1, res_col2, res_col3 = st.columns(3)

    with res_col1:
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">💧 Water Quality</div>
            <div class="result-card-value" style="color: {'#2ECC71' if water_is_safe else '#E74C3C'}">
                {'✅ Potable' if water_is_safe else '🚫 Contaminated'}
            </div>
            <div class="result-card-sub">
                Confidence: {max(water_prob_potable, 1-water_prob_potable):.1%}
            </div>
        </div>
        """, unsafe_allow_html=True)

    with res_col2:
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">🦠 Predicted Disease</div>
            <div class="result-card-value" style="color: {'#E74C3C' if disease_confidence > 0.5 else '#2ECC71'}">
                {disease_pred}
            </div>
            <div class="result-card-sub">
                Confidence: {disease_confidence:.1%}
            </div>
        </div>
        """, unsafe_allow_html=True)

    with res_col3:
        st.markdown(f"""
        <div class="result-card">
            <div class="result-card-header">🔬 Combined Risk</div>
            <div class="result-card-value" style="color: {RISK_COLORS[risk_level]}">
                {RISK_EMOJIS[risk_level]} {risk_level}
            </div>
            <div class="result-card-sub">
                Score: {combined_score:.1%}
            </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Gauge ──
    st.markdown("<br>", unsafe_allow_html=True)
    gauge_col1, gauge_col2 = st.columns([3, 2])

    with gauge_col1:
        gauge_fig = render_gauge(combined_score)
        st.plotly_chart(gauge_fig, use_container_width=True, config={'displayModeBar': False})

        # Risk formula breakdown
        st.markdown(f"""
        <div class="formula-box">
            <strong>Risk Fusion Formula (Voting Ensemble):</strong><br>
            <code>Outbreak Risk = (0.5 × {risk_details['water_contamination_prob']:.1%}) + (0.5 × {risk_details['disease_probability']:.1%})</code>
            <br>
            <code>= {risk_details['combined_score']:.1%} → <span style="color: {RISK_COLORS[risk_level]}">{risk_level}</span></code>
        </div>
        """, unsafe_allow_html=True)

    with gauge_col2:
        # Recommendation box
        st.markdown(f"""
        <div class="rec-card rec-{risk_level.lower()}">
            <div class="rec-header">
                <span class="rec-emoji">{rec['emoji']}</span>
                <span class="rec-title">{rec['title']}</span>
            </div>
            <p class="rec-text">{rec['short_description']}</p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Action items
        with st.expander("📋 View Action Plan", expanded=True):
            for item in rec['bullet_points']:
                st.markdown(f"- {item}")

    # ── Explainability Section ──
    st.markdown("---")
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🔍</span>
        <span>Explainability — Why this prediction?</span>
    </div>
    """, unsafe_allow_html=True)
    render_explainability_chart(water_explanation, disease_explanation)


def render_what_if_section():
    """
    ENHANCEMENT 3: Real-time What-If Analysis.
    Shows how changing key parameters affects the risk score.
    """
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🎯</span>
        <span>Real-Time What-If Analysis</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <p style="color: #C9BFA9; font-size: 0.9rem; margin-bottom: 16px;">
        Adjust these parameters to see how changing water quality affects outbreak risk in real time.
    </p>
    """, unsafe_allow_html=True)

    water_model = st.session_state.water_model

    col1, col2, col3 = st.columns(3)

    with col1:
        what_if_ph = st.slider(
            "What if pH was...",
            min_value=0.0, max_value=14.0,
            value=7.0, step=0.1,
            key="whatif_ph",
            help="Neutral pH (7.0) is ideal for drinking water"
        )

    with col2:
        what_if_turbidity = st.slider(
            "What if Turbidity was...",
            min_value=1.5, max_value=6.5,
            value=2.0, step=0.1,
            key="whatif_turbidity",
            help="Lower turbidity (clear water) is better"
        )

    with col3:
        what_if_chloramines = st.slider(
            "What if Chloramines was...",
            min_value=0.4, max_value=13.0,
            value=4.0, step=0.1,
            key="whatif_chloramines",
            help="Moderate chloramines (2-6 mg/L) is ideal"
        )

    # Build what-if input and run prediction
    if water_model:
        # Use default values for other features
        default_vals = {
            'Hardness': 200, 'Solids': 15000, 'Sulfate': 333,
            'Conductivity': 426, 'Organic_carbon': 12,
            'Trihalomethanes': 60,
        }
        what_if_inputs = {
            'ph': what_if_ph,
            'Turbidity': what_if_turbidity,
            'Chloramines': what_if_chloramines,
            **default_vals
        }

        # Predict
        feat_cols = water_model['feature_cols']
        aligned_inputs = align_water_input_keys(what_if_inputs, feat_cols)
        wif_df = pd.DataFrame([aligned_inputs])[feat_cols]
        wif_prob = water_model['model'].predict_proba(wif_df)[0][1]
        wif_contamination = 1 - wif_prob

        current_risk = get_risk_level(wif_contamination)

        st.markdown(f"""
        <div class="what-if-result" style="
            padding: 16px;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            border: 1px solid rgba(0,0,0,0.08);
            margin-top: 8px;
        ">
            <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                <span style="font-size: 0.85rem; color: #C9BFA9;">Contamination Risk:</span>
                <span style="font-size: 1.4rem; font-weight: 700; color: {get_risk_color(wif_contamination)};">
                    {wif_contamination:.1%}
                </span>
                <span style="font-size: 1rem; padding: 4px 12px; border-radius: 20px; 
                      background: {get_risk_color(wif_contamination)}22;
                      color: {get_risk_color(wif_contamination)};
                      font-weight: 600;">
                    {current_risk}
                </span>
                <span style="font-size: 0.8rem; color: #C9BFA9; margin-left: auto;">
                    {('🚫 NOT Potable' if wif_contamination > 0.5 else '✅ Potable')}
                </span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Causal what-if section
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🧪</span>
        <span>Causal Counterfactual: What If We Improve Water Quality?</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <p style="color: #C9BFA9; font-size: 0.85rem;">
        Uses DoWhy causal inference to estimate the impact of water quality interventions
        on disease risk. Select an intervention below.
    </p>
    """, unsafe_allow_html=True)

    try:
        from app.utils.causal_analysis import CausalAnalyzer
        analyzer = CausalAnalyzer()
        analyzer.load_or_generate_data()

        col1, col2 = st.columns(2)
        with col1:
            intervention_options = [
                ('ph', 'Improve pH to neutral (7.0)'),
                ('Turbidity', 'Reduce turbidity (2.0 NTU)'),
                ('Chloramines', 'Optimize chloramines (4.0 mg/L)'),
                ('Organic_carbon', 'Reduce organic carbon (10 mg/L)'),
            ]
            selected_intervention = st.selectbox(
                "Choose intervention",
                options=[label for _, label in intervention_options],
                key="causal_intervention"
            )

        if selected_intervention:
            # Find the matching key
            intervention_key = next(
                k for k, label in intervention_options
                if label == selected_intervention
            )
            targets = {
                'ph': 7.0, 'Turbidity': 2.0,
                'Chloramines': 4.0, 'Organic_carbon': 10.0
            }
            target_val = targets.get(intervention_key, 0)

            result = analyzer.what_if_analysis(intervention_key, target_val)

            if 'estimated_risk_change' in result and result['estimated_risk_change'] is not None:
                direction_color = '#2ECC71' if result['estimated_risk_change'] < 0 else '#E74C3C'
                st.markdown(f"""
                <div class="causal-result" style="
                    padding: 16px;
                    background: rgba(255,255,255,0.05);
                    border-radius: 12px;
                    border: 1px solid rgba(155,89,182,0.2);
                    margin-top: 8px;
                ">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <span style="font-size: 1.5rem;">🧪</span>
                        <div>
                            <div style="font-size: 0.9rem; color: #ECE3D0;">
                                <strong>{result['intervention']}:</strong>
                                {result['current_value']} → {result['intervention_value']}
                            </div>
                            <div style="font-size: 1.2rem; font-weight: 700; color: {direction_color};">
                                {result['direction']}: {abs(result['estimated_risk_change_pct']):.1f}%
                            </div>
                            <div style="font-size: 0.8rem; color: #C9BFA9;">
                                {result['interpretation']}
                            </div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.info(result.get('interpretation', 'Analysis unavailable'))

    except ImportError as e:
        st.info(f"Causal analysis requires DoWhy: {e}")
    except Exception as e:
        st.info(f"Causal analysis unavailable: {str(e)[:100]}")

    # Top interventions summary
    st.markdown("<br>", unsafe_allow_html=True)
    try:
        top_interventions = analyzer.get_top_interventions(4) if 'analyzer' in dir() and analyzer else None
        if not top_interventions:
            from app.utils.causal_analysis import CausalAnalyzer
            temp_analyzer = CausalAnalyzer()
            temp_analyzer.load_or_generate_data()
            top_interventions = temp_analyzer.get_top_interventions(4)
        
        if top_interventions:
            st.markdown("""
            <div style="font-size: 0.9rem; font-weight: 600; color: #ECE3D0; margin-bottom: 8px;">
                📊 Most Impactful Water Quality Interventions
            </div>
            """, unsafe_allow_html=True)

            for interv in top_interventions:
                change = interv.get('estimated_risk_change', 0)
                pct = interv.get('estimated_risk_change_pct', 0)
                color = '#2ECC71' if change < 0 else '#E74C3C'
                emoji = '✅' if change < 0 else '⚠️'
                st.markdown(f"""
                <div style="
                    display: flex; justify-content: space-between; align-items: center;
                    padding: 8px 12px; margin-bottom: 4px;
                    background: rgba(255,255,255,0.03);
                    border-radius: 8px;
                    font-size: 0.85rem;
                ">
                    <span>{emoji} <strong>{interv.get('intervention', '')}</strong>: 
                        {interv.get('current_value', '')} → {interv.get('intervention_value', '')}</span>
                    <span style="color: {color}; font-weight: 700;">
                        {interv.get('direction', '')} ({abs(pct):.1f}%)
                    </span>
                </div>
                """, unsafe_allow_html=True)
    except Exception:
        pass


def render():
    """Main render function for the location detail page."""
    st.markdown("<h2 class='page-title'>🔬 Location Detail & Analysis</h2>", unsafe_allow_html=True)

    # Check if models are loaded
    if not st.session_state.models_loaded:
        st.warning("⚠️ Models not loaded. Please go to the Overview page first.")
        return

    water_model = st.session_state.water_model
    disease_model = st.session_state.disease_model

    st.markdown(f"""
    <div class="page-subtitle">
        Analyzing: <strong>{st.session_state.current_location}</strong>
        <span style="margin-left: 16px; font-size: 0.8rem; color: #C9BFA9;">
            (Voting Ensemble: XGBoost + Random Forest + Decision Tree)
        </span>
    </div>
    """, unsafe_allow_html=True)

    # Input forms in two columns
    col1, col2 = st.columns(2)

    with col1:
        water_inputs = render_water_quality_form()

    with col2:
        symptom_inputs = render_symptom_form()

    st.markdown("---")

    # Predict button
    predict_col1, predict_col2, predict_col3 = st.columns([1, 2, 1])
    with predict_col2:
        predict_clicked = st.button(
            "🔮 Run Risk Assessment",
            type="primary",
            use_container_width=True,
        )

    st.markdown("---")

    if predict_clicked:
        with st.spinner("🔄 Running ensemble models and fusing risk scores..."):
            results = run_assessment(water_inputs, symptom_inputs, water_model, disease_model)

        render_results(results)

        # ── Store in history ──
        st.session_state.prediction_history.append({
            'timestamp': datetime.now().isoformat(),
            'location': st.session_state.current_location,
            'water_safe': bool(results['water_is_safe']),
            'predicted_disease': results['disease_pred'],
            'combined_risk': float(results['combined_score']),
            'risk_level': results['risk_level'],
        })

    else:
        # Show placeholder before first prediction
        st.markdown("""
        <div class="placeholder-card">
            <div class="placeholder-icon">🔬</div>
            <div class="placeholder-text">
                <h3>Ready for Analysis</h3>
                <p>Adjust the water quality parameters and symptom reports, then click
                <strong>"Run Risk Assessment"</strong> to get the combined outbreak risk prediction
                from the <strong>Voting Ensemble</strong> (XGBoost + Random Forest + Decision Tree).</p>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # ── What-If Analysis Section (always visible) ──
    st.markdown("---")
    render_what_if_section()


st.markdown("""<div class="page-content">""", unsafe_allow_html=True)
render()
st.markdown("""</div>""", unsafe_allow_html=True)
