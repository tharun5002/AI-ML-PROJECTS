"""
overview.py
Overview Dashboard — the landing page showing:
- Summary cards (current risk, active alerts, monitored locations, last updated)
- Map view with location pins colored by risk level
- Trend chart showing risk over last 30 days
- Recent alerts feed
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from app.utils.risk_fusion import (
    get_risk_level, get_risk_color, RISK_COLORS, RISK_EMOJIS,
    calculate_risk_score
)
from app.utils.recommendations import get_recommendation
from app.utils.forecasting import RiskForecaster, format_forecast_summary


def render_summary_cards():
    """Top row of summary metric cards."""
    timeline = st.session_state.timeline_data
    if timeline is None:
        st.warning("No timeline data available.")
        return

    current_loc = st.session_state.current_location
    loc_tl = timeline[timeline['Location'] == current_loc].copy()

    if loc_tl.empty:
        return

    # Convert Date column to datetime for reliable comparisons
    loc_tl['Date'] = pd.to_datetime(loc_tl['Date'])

    latest = loc_tl.iloc[-1]
    current_risk = latest['Risk_Score']
    risk_level = get_risk_level(current_risk)
    risk_color = get_risk_color(current_risk)

    # Active alerts (last 7 days)
    last_7d = loc_tl[loc_tl['Date'] >= (pd.Timestamp.now() - timedelta(days=7))]
    active_alerts = last_7d[last_7d['Risk_Score'] >= 0.45].shape[0]

    # Total locations
    total_locations = timeline['Location'].nunique()

    # Total cases this month
    total_cases = int(loc_tl.tail(30)['Reported_Cases'].sum())

    # Risk trend (is it increasing?)
    if len(loc_tl) >= 14:
        recent_avg = loc_tl.tail(7)['Risk_Score'].mean()
        prev_avg = loc_tl.tail(14).head(7)['Risk_Score'].mean()
        trend = "↑ Rising" if recent_avg > prev_avg else "↓ Stable" if recent_avg < prev_avg else "→ Flat"
        trend_color = "#E74C3C" if "Rising" in trend else "#2ECC71"
    else:
        trend = "→ N/A"
        trend_color = "#C9BFA9"

    cols = st.columns(4)

    with cols[0]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Current Risk Level</div>
            <div class="metric-value" style="color: {risk_color}">
                {RISK_EMOJIS[risk_level]} {risk_level}
            </div>
            <div class="metric-sub">Score: {current_risk:.1%}</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[1]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Active Alerts (7d)</div>
            <div class="metric-value" style="color: {'#E74C3C' if active_alerts > 0 else '#2ECC71'}">
                {active_alerts}
            </div>
            <div class="metric-sub">{total_locations} locations monitored</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[2]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Reported Cases (30d)</div>
            <div class="metric-value">{total_cases:,}</div>
            <div class="metric-sub">{current_loc}</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[3]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Risk Trend</div>
            <div class="metric-value" style="color: {trend_color}; font-size: 1.4rem;">
                {trend}
            </div>
            <div class="metric-sub">Last updated: {latest['Date'].strftime('%Y-%m-%d')}</div>
        </div>
        """, unsafe_allow_html=True)


def render_map_view():
    """Render the geographic risk map using Plotly."""
    timeline = st.session_state.timeline_data
    if timeline is None:
        return

    # Get latest risk for each location
    latest_risks = timeline.groupby('Location').last().reset_index()
    latest_risks['Risk_Level'] = latest_risks['Risk_Score'].apply(get_risk_level)
    latest_risks['Risk_Color'] = latest_risks['Risk_Level'].map(RISK_COLORS)
    latest_risks['Size'] = 15 + latest_risks['Risk_Score'] * 30
    latest_risks['Population_Scale'] = latest_risks['Population'] / 100

    # Highlight selected location
    latest_risks['Opacity'] = latest_risks['Location'].apply(
        lambda x: 1.0 if x == st.session_state.current_location else 0.6
    )

    fig = go.Figure()

    # Add base map tiles
    fig.update_layout(
        mapbox_style="carto-positron",
        mapbox_zoom=4.5,
        mapbox_center={"lat": 22.5, "lon": 80.0},
        margin={"r": 0, "t": 0, "l": 0, "b": 0},
        height=450,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )

    # Add scatter points
    for _, row in latest_risks.iterrows():
        fig.add_trace(go.Scattermapbox(
            lat=[row['Latitude']],
            lon=[row['Longitude']],
            mode='markers+text',
            marker=dict(
                size=row['Size'],
                color=row['Risk_Color'],
                opacity=row['Opacity'],
                sizemode='area',
            ),
            text=[row['Location']],
            textposition='top center',
            textfont=dict(
                size=10,
                color='#ECE3D0',
                family='Inter, sans-serif',
            ),
            hovertext=[f"<b>{row['Location']}</b><br>"
                       f"Risk: {row['Risk_Level']} ({row['Risk_Score']:.1%})<br>"
                       f"Population: {row['Population']:,}<br>"
                       f"Cases (30d): {int(row['Reported_Cases'])}"],
            hoverinfo='text',
            name=row['Location'],
            showlegend=False,
        ))

    # Add a subtle border
    fig.update_layout(
        shapes=[dict(
            type="rect",
            xref="paper", yref="paper",
            x0=0, y0=0, x1=1, y1=1,
            line=dict(color="rgba(0,0,0,0.1)", width=1),
        )]
    )

    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Legend
    st.markdown(f"""
    <div class="map-legend">
        <span><span style="color: {RISK_COLORS['LOW']}">●</span> LOW </span>
        <span><span style="color: {RISK_COLORS['MEDIUM']}">●</span> MEDIUM </span>
        <span><span style="color: {RISK_COLORS['HIGH']}">●</span> HIGH </span>
        <span style="margin-left: 16px;">📍 Selected: <strong>{st.session_state.current_location}</strong></span>
    </div>
    """, unsafe_allow_html=True)


def render_trend_chart():
    """Render the 30-day risk trend line chart."""
    timeline = st.session_state.timeline_data
    if timeline is None:
        return

    current_loc = st.session_state.current_location
    loc_tl = timeline[timeline['Location'] == current_loc].tail(30).copy()

    if loc_tl.empty:
        st.info("No trend data available for this location.")
        return

    # Convert Date to datetime
    loc_tl['Date'] = pd.to_datetime(loc_tl['Date'])

    fig = go.Figure()

    # Risk score line
    fig.add_trace(go.Scatter(
        x=loc_tl['Date'],
        y=loc_tl['Risk_Score'],
        mode='lines+markers',
        name='Risk Score',
        line=dict(color='#3498DB', width=3),
        marker=dict(
            size=8,
            color=loc_tl['Risk_Score'].apply(get_risk_color),
            line=dict(color='white', width=1),
        ),
        fill='tozeroy',
        fillcolor='rgba(52, 152, 219, 0.1)',
        hovertemplate='<b>%{x|%b %d}</b><br>Risk: %{y:.1%}<extra></extra>',
    ))

    # Threshold lines
    fig.add_hline(y=0.35, line_dash="dash", line_color="#F1C40F", opacity=0.5,
                  annotation_text="MEDIUM threshold",
                  annotation_font=dict(color='#C9BFA9', size=11))
    fig.add_hline(y=0.65, line_dash="dash", line_color="#E74C3C", opacity=0.5,
                  annotation_text="HIGH threshold",
                  annotation_font=dict(color='#C9BFA9', size=11))

    # Cases bar chart (secondary axis)
    fig.add_trace(go.Bar(
        x=loc_tl['Date'],
        y=loc_tl['Reported_Cases'],
        name='Reported Cases',
        yaxis='y2',
        marker=dict(
            color='rgba(231, 76, 60, 0.3)',
            line=dict(color='rgba(231, 76, 60, 0.6)', width=1),
        ),
        hovertemplate='<b>%{x|%b %d}</b><br>Cases: %{y}<extra></extra>',
    ))

    fig.update_layout(
        title=dict(
            text=f'<b>Risk Score & Case Trends</b> — {current_loc}',
            font=dict(size=16, color='#ECE3D0'),
            x=0,
        ),
        xaxis=dict(
            title='Date',
            gridcolor='rgba(255,255,255,0.06)',
            showgrid=True,
            tickfont=dict(color='#C9BFA9'),
            title_font=dict(color='#C9BFA9'),
        ),
        yaxis=dict(
            title='Risk Score',
            tickformat='.0%',
            range=[0, 1],
            gridcolor='rgba(255,255,255,0.06)',
            showgrid=True,
            tickfont=dict(color='#C9BFA9'),
            title_font=dict(color='#C9BFA9'),
        ),
        yaxis2=dict(
            title='Reported Cases',
            overlaying='y',
            side='right',
            showgrid=False,
            rangemode='nonnegative',
            tickfont=dict(color='#C9BFA9'),
            title_font=dict(color='#C9BFA9'),
        ),
        hovermode='x unified',
        height=400,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1,
        ),
    )

    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})


def render_recent_alerts():
    """Show recent alerts in a compact table."""
    alerts = st.session_state.alert_data
    if alerts is None or alerts.empty:
        st.info("No recent alerts.")
        return

    current_loc = st.session_state.current_location
    loc_alerts = alerts[alerts['Location'] == current_loc].head(5)

    if loc_alerts.empty:
        st.info(f"No recent alerts for {current_loc}.")
        return

    st.markdown("### 🚨 Recent Alerts")

    for _, alert in loc_alerts.iterrows():
        risk_color = get_risk_color(alert['Risk_Score'])
        st.markdown(f"""
        <div class="alert-item">
            <div class="alert-indicator" style="background: {risk_color};"></div>
            <div class="alert-content">
                <div class="alert-header">
                    <span class="alert-location">{alert['Location']}</span>
                    <span class="alert-time">{alert['Timestamp'][:16]}</span>
                </div>
                <div class="alert-trigger">{alert['Trigger']}</div>
            </div>
            <div class="alert-risk" style="color: {risk_color};">
                {alert['Risk_Level']}
            </div>
        </div>
        """, unsafe_allow_html=True)


def render_quick_recs():
    """Show quick recommendation based on current risk level."""
    timeline = st.session_state.timeline_data
    if timeline is None:
        return

    current_loc = st.session_state.current_location
    loc_tl = timeline[timeline['Location'] == current_loc]

    if loc_tl.empty:
        return

    latest = loc_tl.iloc[-1]
    risk_level = get_risk_level(latest['Risk_Score'])
    rec = get_recommendation(risk_level)

    st.markdown(f"""
    <div class="rec-card rec-{risk_level.lower()}">
        <div class="rec-header">
            <span class="rec-emoji">{rec['emoji']}</span>
            <span class="rec-title">{rec['title']}</span>
        </div>
        <p class="rec-text">{rec['short_description']}</p>
    </div>
    """, unsafe_allow_html=True)


def render():
    """Main render function for the overview page."""
    st.markdown("<h2 class='page-title'>📊 Overview Dashboard</h2>", unsafe_allow_html=True)

    # Summary cards
    render_summary_cards()

    st.markdown("---")
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🗺️</span>
        <span>Geographic Risk Map</span>
    </div>
    """, unsafe_allow_html=True)

    # Map and trend side by side on large screens, stacked on mobile
    col1, col2 = st.columns([3, 2])

    with col1:
        render_map_view()

    with col2:
        render_quick_recs()
        if st.button("View Full Response Plan →", key="nav_to_detail", use_container_width=True):
            st.switch_page("pages/location_detail.py")
        st.markdown("<br>", unsafe_allow_html=True)

        # Show current location recommendation
        timeline = st.session_state.timeline_data
        if timeline is not None:
            current_loc = st.session_state.current_location
            loc_tl = timeline[timeline['Location'] == current_loc]
            if not loc_tl.empty:
                latest = loc_tl.iloc[-1]
                st.markdown(f"""
                <div class="info-card">
                    <div class="info-card-title">📍 {current_loc} — Quick Summary</div>
                    <div class="info-card-grid">
                        <div><strong>Current Score:</strong> {latest['Risk_Score']:.1%}</div>
                        <div><strong>Population:</strong> {int(latest['Population']):,}</div>
                        <div><strong>30d Cases:</strong> {int(loc_tl.tail(30)['Reported_Cases'].sum())}</div>
                        <div><strong>Risk Level:</strong> <span style="color: {get_risk_color(latest['Risk_Score'])}">{get_risk_level(latest['Risk_Score'])}</span></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">📈</span>
        <span>Risk & Case Trends (Last 30 Days)</span>
    </div>
    """, unsafe_allow_html=True)

    render_trend_chart()

    st.markdown("---")
    render_recent_alerts()


def render_forecast_section():
    """ENHANCEMENT 1: Render 14-day risk forecast chart."""
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🔮</span>
        <span>14-Day Risk Forecast (Prophet ML)</span>
    </div>
    """, unsafe_allow_html=True)

    timeline = st.session_state.timeline_data
    if timeline is None or timeline.empty:
        st.info("Timeline data required for forecasting.")
        return

    current_loc = st.session_state.current_location

    with st.spinner("🔄 Training Prophet forecasting model..."):
        try:
            forecaster = RiskForecaster(forecast_days=14)
            forecaster.train(timeline, current_loc)
            forecast = forecaster.predict()
            early_warning = forecaster.get_early_warning(forecast)
        except Exception as e:
            st.warning(f"Forecasting unavailable: {e}")
            return

    # Early warning summary
    st.markdown(format_forecast_summary(early_warning), unsafe_allow_html=True)

    # Forecast chart
    loc_data = timeline[timeline['Location'] == current_loc].copy()
    loc_data['Date'] = pd.to_datetime(loc_data['Date'])
    
    # Combine historical and forecast
    historical_tail = loc_data.tail(30)
    
    fig = go.Figure()

    # Historical risk
    fig.add_trace(go.Scatter(
        x=historical_tail['Date'],
        y=historical_tail['Risk_Score'],
        mode='lines+markers',
        name='Historical Risk',
        line=dict(color='#3498DB', width=3),
        marker=dict(size=6, color='#3498DB'),
    ))

    # Forecast
    fig.add_trace(go.Scatter(
        x=forecast['ds'],
        y=forecast['yhat'],
        mode='lines+markers',
        name='Forecast (Prophet)',
        line=dict(color='#E74C3C', width=3, dash='dash'),
        marker=dict(size=8, color='#E74C3C', symbol='diamond'),
    ))

    # Confidence interval
    fig.add_trace(go.Scatter(
        x=pd.concat([forecast['ds'], forecast['ds'][::-1]]),
        y=pd.concat([forecast['yhat_upper'], forecast['yhat_lower'][::-1]]),
        fill='toself',
        fillcolor='rgba(231, 76, 60, 0.1)',
        line=dict(color='rgba(231, 76, 60, 0)', width=0),
        name='80% Confidence Interval',
        showlegend=True,
    ))

    # Threshold lines
    fig.add_hline(y=0.35, line_dash="dash", line_color="#F1C40F", opacity=0.4,
                  annotation_text="MEDIUM",
                  annotation_font=dict(color='#C9BFA9', size=11))
    fig.add_hline(y=0.65, line_dash="dash", line_color="#E74C3C", opacity=0.4,
                  annotation_text="HIGH",
                  annotation_font=dict(color='#C9BFA9', size=11))

    # Vertical line separating past from future
    last_date = historical_tail['Date'].iloc[-1]
    fig.add_vline(x=pd.Timestamp(last_date), line_dash="dot", line_color="#8A8272", opacity=0.5,
                  annotation_text="Today",
                  annotation_font=dict(color='#C9BFA9', size=11))

    fig.update_layout(
        title=dict(
            text=f'<b>14-Day Outbreak Risk Forecast</b> — {current_loc}',
            font=dict(size=14, color='#ECE3D0'),
            x=0,
        ),
        xaxis=dict(title='Date', gridcolor='rgba(255,255,255,0.06)',
                   tickfont=dict(color='#C9BFA9'), title_font=dict(color='#C9BFA9')),
        yaxis=dict(title='Risk Score', tickformat='.0%', range=[0, 1],
                   gridcolor='rgba(255,255,255,0.06)',
                   tickfont=dict(color='#C9BFA9'), title_font=dict(color='#C9BFA9')),
        hovermode='x unified',
        height=380,
        margin=dict(l=10, r=10, t=50, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        legend=dict(
            orientation='h', yanchor='bottom', y=1.02,
            xanchor='right', x=1,
            font=dict(color='#C9BFA9'),
        ),
    )

    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

    # Forecast table
    with st.expander("📋 View Forecast Data Table"):
        table_data = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper', 'trend_direction']].copy()
        table_data['ds'] = table_data['ds'].dt.strftime('%Y-%m-%d')
        table_data.columns = ['Date', 'Forecasted Risk', 'Lower Bound', 'Upper Bound', 'Trend']
        table_data['Forecasted Risk'] = table_data['Forecasted Risk'].apply(lambda x: f'{x:.1%}')
        table_data['Lower Bound'] = table_data['Lower Bound'].apply(lambda x: f'{x:.1%}')
        table_data['Upper Bound'] = table_data['Upper Bound'].apply(lambda x: f'{x:.1%}')
        st.dataframe(table_data, use_container_width=True, hide_index=True)

    # Training metrics
    st.markdown(f"""
    <div style="font-size: 0.8rem; color: #8A8272; margin-top: 8px;">
        Model: Prophet (Meta) | Training MAE: {forecaster.training_metrics.get('mae', 'N/A'):.4f} | 
        Training days: {forecaster.training_metrics.get('training_days', 'N/A')}
    </div>
    """, unsafe_allow_html=True)


def render():
    """Main render function for the overview page."""
    st.markdown("<h2 class='page-title'>📊 Overview Dashboard</h2>", unsafe_allow_html=True)

    # Summary cards
    render_summary_cards()

    st.markdown("---")
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">🗺️</span>
        <span>Geographic Risk Map</span>
    </div>
    """, unsafe_allow_html=True)

    # Map and trend side by side on large screens, stacked on mobile
    col1, col2 = st.columns([3, 2])

    with col1:
        render_map_view()

    with col2:
        render_quick_recs()
        if st.button("View Full Response Plan →", key="nav_to_detail", use_container_width=True):
            st.switch_page("pages/location_detail.py")
        st.markdown("<br>", unsafe_allow_html=True)

        # Show current location recommendation
        timeline = st.session_state.timeline_data
        if timeline is not None:
            current_loc = st.session_state.current_location
            loc_tl = timeline[timeline['Location'] == current_loc]
            if not loc_tl.empty:
                latest = loc_tl.iloc[-1]
                st.markdown(f"""
                <div class="info-card">
                    <div class="info-card-title">📍 {current_loc} — Quick Summary</div>
                    <div class="info-card-grid">
                        <div><strong>Current Score:</strong> {latest['Risk_Score']:.1%}</div>
                        <div><strong>Population:</strong> {int(latest['Population']):,}</div>
                        <div><strong>30d Cases:</strong> {int(loc_tl.tail(30)['Reported_Cases'].sum())}</div>
                        <div><strong>Risk Level:</strong> <span style="color: {get_risk_color(latest['Risk_Score'])}">{get_risk_level(latest['Risk_Score'])}</span></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">📈</span>
        <span>Risk & Case Trends (Last 30 Days)</span>
    </div>
    """, unsafe_allow_html=True)

    render_trend_chart()

    st.markdown("---")
    render_recent_alerts()

    # ── FORECAST SECTION (NEW) ──
    st.markdown("---")
    render_forecast_section()


# This is called by the navigation system
st.markdown("""<div class="page-content">""", unsafe_allow_html=True)
render()
st.markdown("""</div>""", unsafe_allow_html=True)
