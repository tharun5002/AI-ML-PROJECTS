"""
alerts_log.py
Alerts Log screen showing past alerts from the simulated timeline data.
Includes filtering by location, risk level, and date range.
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from app.utils.risk_fusion import get_risk_level, get_risk_color, RISK_COLORS


def render_alert_stats(alerts_df):
    """Render alert summary statistics."""
    total = len(alerts_df)
    high = len(alerts_df[alerts_df['Risk_Level'] == 'HIGH'])
    medium = len(alerts_df[alerts_df['Risk_Level'] == 'MEDIUM'])
    locations = alerts_df['Location'].nunique()

    cols = st.columns(4)

    with cols[0]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Total Alerts</div>
            <div class="metric-value">{total}</div>
            <div class="metric-sub">System lifetime</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[1]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">High Risk</div>
            <div class="metric-value" style="color: {RISK_COLORS['HIGH']}">{high}</div>
            <div class="metric-sub">{high/total*100:.1f}% of alerts</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[2]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Medium Risk</div>
            <div class="metric-value" style="color: {RISK_COLORS['MEDIUM']}">{medium}</div>
            <div class="metric-sub">{medium/total*100:.1f}% of alerts</div>
        </div>
        """, unsafe_allow_html=True)

    with cols[3]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Affected Locations</div>
            <div class="metric-value">{locations}</div>
            <div class="metric-sub">of 8 monitored</div>
        </div>
        """, unsafe_allow_html=True)


def render_alert_timeline(alerts_df):
    """Render alert timeline chart."""
    if alerts_df.empty:
        return

    alerts_over_time = alerts_df.copy()
    alerts_over_time['Date'] = pd.to_datetime(alerts_over_time['Timestamp']).dt.date
    daily_counts = alerts_over_time.groupby(['Date', 'Risk_Level']).size().reset_index(name='Count')
    daily_counts['Date'] = pd.to_datetime(daily_counts['Date'])

    colors = {'HIGH': RISK_COLORS['HIGH'], 'MEDIUM': RISK_COLORS['MEDIUM']}

    fig = px.bar(
        daily_counts,
        x='Date',
        y='Count',
        color='Risk_Level',
        color_discrete_map=colors,
        title='Alerts Over Time by Risk Level',
        labels={'Count': 'Number of Alerts', 'Date': 'Date'},
        barmode='stack',
        height=350,
    )

    fig.update_layout(
        margin=dict(l=10, r=10, t=40, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font={'color': '#ECE3D0'},
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1,
            font=dict(color='#C9BFA9'),
        ),
    )

    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})


def render_alerts_table(alerts_df):
    """Render the main alerts data table."""
    if alerts_df.empty:
        st.info("No alerts matching the current filters.")
        return

    # Format the dataframe for display
    display_df = alerts_df.copy()
    display_df['Timestamp'] = pd.to_datetime(display_df['Timestamp']).dt.strftime('%Y-%m-%d %H:%M')
    display_df['Risk_Score'] = display_df['Risk_Score'].apply(lambda x: f"{x:.1%}")

    # Display as styled HTML table
    st.markdown("""
    <style>
    .alert-table-container {
        max-height: 600px;
        overflow-y: auto;
        border-radius: 12px;
        border: 1px solid rgba(0,0,0,0.05);
    }
    </style>
    """, unsafe_allow_html=True)

    # Use Streamlit's dataframe for interactivity
    st.dataframe(
        display_df,
        column_config={
            'Timestamp': st.column_config.TextColumn('Timestamp', width='medium'),
            'Location': st.column_config.TextColumn('Location', width='medium'),
            'Risk_Score': st.column_config.TextColumn('Risk Score', width='small'),
            'Risk_Level': st.column_config.TextColumn('Risk Level', width='small'),
            'Trigger': st.column_config.TextColumn('Trigger Reason', width='large'),
            'Cases_Reported': st.column_config.NumberColumn('Cases', width='small'),
        },
        use_container_width=True,
        hide_index=True,
        height=500,
    )


def render():
    """Main render function for alerts log."""
    st.markdown("<h2 class='page-title'>🚨 Alerts Log</h2>", unsafe_allow_html=True)

    alerts = st.session_state.alert_data

    if alerts is None or alerts.empty:
        st.warning("No alert data available. Run data generation first.")
        return

    # ── Filters ──
    st.markdown("""
    <div class="filters-bar">
        <span class="filters-label">🔍 Filter Alerts</span>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)

    with col1:
        # Location filter
        all_locations = ['All Locations'] + sorted(alerts['Location'].unique().tolist())
        selected_location = st.selectbox("Location", all_locations)

    with col2:
        # Risk level filter
        risk_filter = st.selectbox("Risk Level", ['All', 'LOW', 'MEDIUM', 'HIGH'])

    with col3:
        # Date range
        date_options = ['All Time', 'Last 7 Days', 'Last 30 Days', 'Last 90 Days']
        date_filter = st.selectbox("Time Period", date_options)

    # ── Apply Filters ──
    filtered = alerts.copy()

    if selected_location != 'All Locations':
        filtered = filtered[filtered['Location'] == selected_location]

    if risk_filter != 'All':
        filtered = filtered[filtered['Risk_Level'] == risk_filter]

    if date_filter != 'All Time':
        filtered['Timestamp'] = pd.to_datetime(filtered['Timestamp'])
        days_map = {'Last 7 Days': 7, 'Last 30 Days': 30, 'Last 90 Days': 90}
        cutoff = pd.Timestamp.now() - timedelta(days=days_map[date_filter])
        filtered = filtered[filtered['Timestamp'] >= cutoff]

    st.markdown("---")

    # ── Stats ──
    render_alert_stats(filtered)

    st.markdown("---")

    # ── Alert Timeline Chart ──
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">📈</span>
        <span>Alert Trend</span>
    </div>
    """, unsafe_allow_html=True)
    render_alert_timeline(filtered)

    st.markdown("---")

    # ── Alerts Table ──
    st.markdown("""
    <div class="section-header">
        <span class="section-icon">📋</span>
        <span>Alert Records ({})</span>
    </div>
    """.format(len(filtered)), unsafe_allow_html=True)
    render_alerts_table(filtered)

    # ── Download button ──
    if not filtered.empty:
        st.markdown("<br>", unsafe_allow_html=True)
        csv = filtered.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download Alerts as CSV",
            data=csv,
            file_name=f"alert_log_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv",
            use_container_width=True,
        )


st.markdown("""<div class="page-content">""", unsafe_allow_html=True)
render()
st.markdown("""</div>""", unsafe_allow_html=True)
