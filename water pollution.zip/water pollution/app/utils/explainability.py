"""
explainability.py
Provides model explainability using SHAP (SHapley Additive exPlanations)
and built-in feature importance from tree-based models.

This module addresses the "Explainability" novel feature requirement.
Examiners value being able to see WHY a model made a particular prediction.
"""

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# Conditional import - SHAP is optional but recommended
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


def explain_water_prediction(model_data, input_features):
    """
    Explain a water quality prediction using SHAP TreeExplainer.
    Uses best_rf (tuned Random Forest) from model_data for compatibility with
    VotingClassifier ensembles (SHAP needs a single tree model).

    Parameters:
    - model_data: dict loaded from joblib (contains model, feature_cols, etc.)
    - input_features: dict or DataFrame with feature values

    Returns:
    - explanation dict with feature contributions
    """
    # Use best_rf for explainability (VotingClassifier doesn't have feature_importances_)
    # If best_rf not available, fall back to the ensemble's predict_proba
    feature_cols = model_data['feature_cols']
    explain_model = model_data.get('best_rf', model_data.get('rf_model', model_data['model']))
    inference_model = model_data['model']  # Use ensemble for actual predictions

    # Convert input to DataFrame
    if isinstance(input_features, dict):
        input_df = pd.DataFrame([input_features])
    else:
        input_df = pd.DataFrame(input_features)

    # Ensure all features present
    for col in feature_cols:
        if col not in input_df.columns:
            input_df[col] = 0  # Should not happen in normal flow

    input_df = input_df[feature_cols]

    # Fall back to feature_importances_ if SHAP not available
    if not SHAP_AVAILABLE:
        return _feature_importance_fallback(
            explain_model,
            feature_cols,
            input_df,
            feature_importances=model_data.get('feature_importance')
        )

    try:
        explainer = shap.TreeExplainer(explain_model)
        shap_values = explainer.shap_values(input_df)

        # For binary classification, shap_values[1] is for class 1 (potable)
        if isinstance(shap_values, list):
            shap_vals = shap_values[1][0]
        else:
            shap_vals = shap_values[0]

        # Build contributions
        contributions = []
        for i, col in enumerate(feature_cols):
            contributions.append({
                'feature': col,
                'value': float(input_df[col].iloc[0]),
                'shap_value': float(shap_vals[i]),
                'impact': 'increases' if shap_vals[i] > 0 else 'decreases',
                'absolute_impact': abs(float(shap_vals[i])),
            })

        contributions.sort(key=lambda x: x['absolute_impact'], reverse=True)

        # Base value
        base_value = float(explainer.expected_value[1] if isinstance(explainer.expected_value, list)
                          else explainer.expected_value)
        prediction = float(inference_model.predict_proba(input_df)[0][1])

        return {
            'method': 'SHAP TreeExplainer',
            'base_value': base_value,
            'prediction': prediction,
            'contributions': contributions[:10],  # Top 10 features
            'num_features': len(contributions),
        }

    except Exception as e:
        # Fallback on error
        return _feature_importance_fallback(
            explain_model,
            feature_cols,
            input_df,
            error=str(e),
            feature_importances=model_data.get('feature_importance')
        )


def explain_disease_prediction(model_data, input_symptoms):
    """
    Explain a disease prediction using feature importance.
    Uses rf_model (Random Forest) from model_data for feature_importances_,
    since VotingClassifier ensembles don't have this attribute.

    Parameters:
    - model_data: dict loaded from joblib
    - input_symptoms: dict with symptom presence (0/1)

    Returns:
    - explanation dict with symptom contributions
    """
    # Use rf_model for feature importance (VotingClassifier doesn't have it)
    explain_model = model_data.get('rf_model', model_data.get('model'))
    inference_model = model_data['model']
    symptom_cols = model_data['symptom_cols']
    label_encoder = model_data['label_encoder']

    # Convert input
    if isinstance(input_symptoms, dict):
        input_df = pd.DataFrame([input_symptoms])
    else:
        input_df = pd.DataFrame(input_symptoms)

    # Ensure all symptom columns present
    for col in symptom_cols:
        if col not in input_df.columns:
            input_df[col] = 0

    input_df = input_df[symptom_cols]

    # Get feature importance for the model
    if hasattr(explain_model, 'feature_importances_'):
        importance = explain_model.feature_importances_
    else:
        # Fallback to uniform importance
        importance = np.ones(len(symptom_cols)) / len(symptom_cols)

    # Get prediction probabilities
    probas = inference_model.predict_proba(input_df)[0]
    predicted_class_idx = np.argmax(probas)
    predicted_disease = label_encoder.inverse_transform([predicted_class_idx])[0]
    confidence = float(probas[predicted_class_idx])

    # Top contributing symptoms (present symptoms with highest importance)
    contributions = []
    for i, col in enumerate(symptom_cols):
        if input_df[col].iloc[0] > 0:  # Only present symptoms
            contributions.append({
                'symptom': col,
                'present': True,
                'importance': float(importance[i]),
                'contribution_pct': float(importance[i] / importance.sum() * 100),
            })

    contributions.sort(key=lambda x: x['importance'], reverse=True)

    # All symptoms sorted by importance (for display)
    all_sorted = sorted(
        [{'symptom': col, 'importance': float(importance[i])}
         for i, col in enumerate(symptom_cols)],
        key=lambda x: x['importance'],
        reverse=True
    )

    return {
        'method': 'Feature Importance (Gini)',
        'predicted_disease': predicted_disease,
        'confidence': confidence,
        'top_contributing_symptoms': contributions[:8],
        'all_symptoms_ranked': all_sorted,
        'probability_distribution': {
            label_encoder.inverse_transform([i])[0]: float(probas[i])
            for i in range(len(probas))
        },
    }


def _feature_importance_fallback(model, feature_cols, input_df, error=None, feature_importances=None):
    """
    Fallback explanation using built-in Random Forest feature_importances_
    or stored feature importance metadata when the model is an ensemble.
    """
    if feature_importances is not None:
        if isinstance(feature_importances, list) and feature_importances:
            if isinstance(feature_importances[0], dict) and 'importance' in feature_importances[0]:
                importance = [float(item['importance']) for item in feature_importances]
            else:
                importance = [float(item) for item in feature_importances]
        else:
            importance = np.ones(len(feature_cols)) / len(feature_cols)
    elif hasattr(model, 'feature_importances_'):
        importance = model.feature_importances_
    else:
        importance = np.ones(len(feature_cols)) / len(feature_cols)

    prediction = float(model.predict_proba(input_df)[0][1])

    contributions = []
    for i, col in enumerate(feature_cols):
        contributions.append({
            'feature': col,
            'value': float(input_df[col].iloc[0]),
            'importance': float(importance[i]),
            'absolute_impact': float(importance[i]),
            'impact': 'important',
        })

    contributions.sort(key=lambda x: x['absolute_impact'], reverse=True)

    result = {
        'method': 'Feature Importance (Gini)',
        'prediction': prediction,
        'contributions': contributions[:10],
        'num_features': len(contributions),
    }

    if error:
        result['shap_error'] = error

    return result


def generate_explainability_chart(explanation, chart_type='bar'):
    """
    Return data formatted for Plotly chart rendering.
    chart_type: 'bar' or 'waterfall'
    """
    if chart_type == 'bar':
        contributions = explanation.get('contributions', [])
        if not contributions:
            return None

        if 'shap_value' in contributions[0]:
            # SHAP style
            labels = [c['feature'] for c in contributions[:8]]
            values = [c['shap_value'] for c in contributions[:8]]
            colors = ['#E74C3C' if v > 0 else '#2ECC71' for v in values]
            title = 'SHAP Feature Contributions (impact on prediction)'
        else:
            # Feature importance style
            labels = [c['feature'] for c in contributions[:8]]
            values = [c['importance'] * 100 for c in contributions[:8]]
            colors = ['#3498DB'] * len(values)
            title = 'Feature Importance (%)'

        return {
            'labels': labels,
            'values': values,
            'colors': colors,
            'title': title,
        }

    return None
