"""
recommendations.py
Generates contextual, severity-based public health recommendations
based on the combined outbreak risk level and predicted disease.

Part of the "Severity-based recommendation" novel feature.
"""

from typing import Dict, List, Optional, Tuple


# ── Action templates ──
ACTIONS = {
    'LOW': {
        'title': '✅ Routine Monitoring',
        'emoji': '🟢',
        'short': 'No action needed. Continue regular surveillance.',
        'long': (
            'All monitored parameters are within normal ranges. '
            'No public health intervention required at this time. '
            'Continue routine water quality testing and community health surveillance.'
        ),
        'bullet_points': [
            'Continue standard water treatment protocols',
            'Maintain regular health surveillance',
            'No restrictions on water usage',
            'Routine reporting to health department',
        ],
    },
    'MEDIUM': {
        'title': '⚠️ Precautionary Measures',
        'emoji': '🟡',
        'short': 'Boil water recommended. Notify health workers.',
        'long': (
            'Water quality parameters and/or symptom reports indicate elevated risk. '
            'Precautionary measures should be implemented to prevent potential outbreak. '
            'Increased surveillance and community awareness recommended.'
        ),
        'bullet_points': [
            'Issue boil-water advisory as precaution',
            'Increase water testing frequency to daily',
            'Alert local community health workers',
            'Distribute hygiene awareness materials',
            'Monitor vulnerable populations (children, elderly, immunocompromised)',
            'Stock oral rehydration supplies',
        ],
    },
    'HIGH': {
        'title': '🚨 EMERGENCY RESPONSE',
        'emoji': '🔴',
        'short': 'URGENT: Active outbreak risk. Full response protocol.',
        'long': (
            'CRITICAL: The combined risk assessment indicates a HIGH probability '
            'of ongoing or imminent water-borne disease outbreak. Immediate public '
            'health intervention is required to prevent widespread illness.'
        ),
        'bullet_points': [
            'ISSUE IMMEDIATE BOIL-WATER ADVISORY for all residents',
            'Notify District Health Officer and local authorities',
            'Deploy emergency water treatment to affected areas',
            'Activate emergency health surveillance system',
            'Set up ORS (Oral Rehydration Solution) distribution points',
            'Deploy mobile health teams to affected communities',
            'Coordinate with nearest hospital for case management',
            'Restrict access to confirmed contaminated water sources',
            'Begin public health awareness broadcasting',
        ],
    },
}

# ── Disease-specific additions ──
DISEASE_ADDONS: Dict[str, Dict[str, List[str]]] = {
    'Cholera': {
        'LOW': [],
        'MEDIUM': [
            '🚽 Ensure proper sanitation facilities',
            '🧴 Distribute hand washing stations',
        ],
        'HIGH': [
            '💧 Prepare oral rehydration stations immediately',
            '🏥 Alert nearest treatment center for cholera cases',
            '📦 Pre-position IV fluids and ORS supplies',
            '🧪 Collect stool samples for laboratory confirmation',
        ],
    },
    'Typhoid': {
        'LOW': [],
        'MEDIUM': [
            '🌡️ Educate community on fever monitoring',
            '💊 Ensure antibiotic availability at health center',
        ],
        'HIGH': [
            '🌡️ Set up fever surveillance in community',
            '💊 Pre-position typhoid treatment courses',
            '🧪 Blood/stool culture testing for suspected cases',
            '📋 Trace contacts of any confirmed cases',
        ],
    },
    'Hepatitis_A': {
        'LOW': [],
        'MEDIUM': [
            '💉 Assess vaccination coverage in community',
        ],
        'HIGH': [
            '💉 Consider targeted vaccination campaign',
            '🧹 Enhanced sanitation and hand hygiene promotion',
            '📋 Case reporting and contact tracing',
            '⚠️ Pregnant women and elderly: prioritize monitoring',
        ],
    },
    'Dysentery': {
        'LOW': [],
        'MEDIUM': [
            '🧴 Promote hand washing with soap',
        ],
        'HIGH': [
            '💧 Ensure safe drinking water supply',
            '🏥 Prepare for bloody diarrhea case management',
            '🧪 Stool microscopy for confirmation',
            '💊 Stock appropriate antibiotics',
        ],
    },
    'Gastroenteritis': {
        'LOW': [],
        'MEDIUM': [
            '🧴 Hand hygiene promotion',
        ],
        'HIGH': [
            '💧 ORS distribution in affected area',
            '🏥 Monitor for dehydration cases',
            '📋 Report case numbers daily',
        ],
    },
    'Diarrheal_Disease': {
        'LOW': [],
        'MEDIUM': [
            '🧴 Promote hand washing',
            '💧 Ensure water storage hygiene',
        ],
        'HIGH': [
            '💧 ORS distribution and hydration awareness',
            '🏥 Health facility preparedness',
            '📋 Daily case reporting',
            '🧪 Water source testing',
        ],
    },
}


def get_recommendation(risk_level: str, predicted_disease: Optional[str] = None,
                       water_safe: Optional[bool] = None) -> Dict:
    """
    Get comprehensive recommendations for a given risk level and disease.
    """
    risk_level = risk_level.upper()
    if risk_level not in ACTIONS:
        risk_level = 'LOW'

    base = ACTIONS[risk_level]
    disease_addon = DISEASE_ADDONS.get(predicted_disease, {})

    bullet_points = list(base['bullet_points'])

    # Add disease-specific bullets
    if predicted_disease:
        additional = disease_addon.get(risk_level, [])
        bullet_points.extend(additional)

    # Water safety context
    if water_safe is not None and not water_safe:
        if '🚫 Water source confirmed contaminated' not in bullet_points:
            bullet_points.insert(0, '🚫 Water source confirmed contaminated — do NOT drink untreated')
    elif water_safe is not None and water_safe:
        if risk_level == 'HIGH':
            bullet_points.insert(0, '⚠️ Water source currently tests safe — but outbreak risk remains high')

    # Build response
    return {
        'title': base['title'],
        'emoji': base['emoji'],
        'short_description': base['short'],
        'long_description': base['long'],
        'bullet_points': bullet_points,
        'risk_level': risk_level,
        'predicted_disease': predicted_disease,
        'severity': 'Emergency' if risk_level == 'HIGH' else 'Warning' if risk_level == 'MEDIUM' else 'Info',
    }


def get_community_message(risk_level: str, location_name: str,
                          predicted_disease: Optional[str] = None) -> str:
    """
    Generate a public-facing community message for announcement/posters.
    """
    messages = {
        'LOW': (
            f"📢 {location_name} — Water Quality Advisory\n\n"
            "Your water supply is within safe parameters. Continue normal use. "
            "Remember to practice good hygiene. Report any illness to your health worker.\n\n"
            "— Community Health Team"
        ),
        'MEDIUM': (
            f"⚠️ {location_name} — PRECAUTIONARY ADVISORY\n\n"
            "As a precaution, please boil all drinking water for at least 1 minute. "
            "Watch for symptoms: fever, diarrhea, vomiting. "
            "Report any cases to your community health worker immediately.\n\n"
            "— Community Health Team"
        ),
        'HIGH': (
            f"🚨 URGENT: {location_name} — PUBLIC HEALTH EMERGENCY\n\n"
            "BOIL ALL WATER BEFORE USE. An outbreak risk has been detected. "
            "If you or your family members experience fever, diarrhea, or vomiting, "
            "report to the nearest health center IMMEDIATELY.\n\n"
            "DO NOT drink untreated water. Use only boiled or chlorinated water.\n\n"
            "— District Health Office"
        ),
    }

    msg = messages.get(risk_level, messages['LOW'])

    if predicted_disease and risk_level in ('MEDIUM', 'HIGH'):
        msg += f"\n\n⚠️ Suspected disease: {predicted_disease}"

    return msg
