"""
causal_analysis.py
ENHANCEMENT 5: Causal Analysis with DoWhy
Provides counterfactual reasoning capabilities:
- "What if pH improves by 1 unit?"
- "What if turbidity is reduced?"
- "Which intervention has the biggest impact on reducing outbreak risk?"

Uses DoWhy for causal graph specification, identification, and estimation.
Falls back to sklearn-based sensitivity analysis if DoWhy is not available.
"""

import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd

try:
    import dowhy
    from dowhy import CausalModel
    DOWHY_AVAILABLE = True
except ImportError:
    DOWHY_AVAILABLE = False

try:
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.inspection import partial_dependence
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ── Causal Graph Definition ──
# This defines our domain knowledge about how water parameters affect disease risk
CAUSAL_GRAPH = """
digraph {
    # Water quality parameters (observable)
    ph -> Potability;
    Turbidity -> Potability;
    Chloramines -> Potability;
    Organic_carbon -> Potability;
    Trihalomethanes -> Potability;
    Solids -> Potability;
    Hardness -> Potability;
    Sulfate -> Potability;
    Conductivity -> Potability;

    # Potability affects disease risk
    Potability -> DiseaseRisk;

    # Confounders
    SeasonalFactor -> DiseaseRisk;
    SeasonalFactor -> Potability;
    PopulationDensity -> DiseaseRisk;
    SanitationLevel -> DiseaseRisk;

    # Symptom pathway (separate from water)
    SanitationLevel -> SymptomSeverity;
    SymptomSeverity -> DiseaseRisk;

    # Intervention nodes
    Intervention -> Potability;
    Intervention -> SanitationLevel;
}
"""

# Water features used for causal analysis (must match data_generator)
CAUSAL_WATER_FEATURES = [
    'ph', 'Hardness', 'Solids', 'Chloramines',
    'Sulfate', 'Conductivity', 'Organic_carbon',
    'Trihalomethanes', 'Turbidity'
]


def generate_causal_dataset(n_samples=5000, seed=42):
    """
    Generate a synthetic dataset suitable for causal inference.
    Includes confounders (SeasonalFactor, SanitationLevel, PopulationDensity)
    and an outcome (DiseaseRisk).

    Returns:
        pd.DataFrame with features, confounders, treatment, and outcome
    """
    rng = np.random.default_rng(seed)

    data = {}

    # ── Confounders ──
    # SeasonalFactor: 0=Dry, 1=Wet (rainy season increases disease risk)
    data['SeasonalFactor'] = rng.binomial(1, 0.4, n_samples)
    # SanitationLevel: 0=Poor, 1=Moderate, 2=Good
    data['SanitationLevel'] = rng.choice([0, 1, 2], n_samples, p=[0.3, 0.4, 0.3])
    # PopulationDensity: continuous (people per sq km)
    data['PopulationDensity'] = rng.lognormal(mean=7.5, sigma=0.5, size=n_samples)

    # ── Water Parameters (influenced by confounders) ──
    # pH: slightly lower in wet season due to runoff
    ph_mean = 7.0 + 0.3 * data['SeasonalFactor'] - 0.1 * data['SanitationLevel']
    data['ph'] = rng.normal(ph_mean, 0.5)

    # Turbidity: higher in wet season, higher with poor sanitation
    turb_mean = 3.5 + 1.5 * data['SeasonalFactor'] + 0.5 * (2 - data['SanitationLevel'])
    data['Turbidity'] = np.clip(rng.normal(turb_mean, 0.8), 0.5, 8.0)

    # Chloramines: slightly lower when sanitation is poor
    chlor_mean = 4.0 - 0.5 * data['SeasonalFactor'] - 0.3 * data['SanitationLevel']
    data['Chloramines'] = np.clip(rng.normal(chlor_mean, 1.0), 0.0, 10.0)

    # Organic Carbon: higher in wet season
    oc_mean = 14.0 + 2.0 * data['SeasonalFactor'] + 1.0 * (2 - data['SanitationLevel'])
    data['Organic_carbon'] = np.clip(rng.normal(oc_mean, 2.0), 0.0, 30.0)

    # Trihalomethanes
    data['Trihalomethanes'] = np.clip(rng.normal(65, 15), 0, 120)

    # Solids
    data['Solids'] = np.clip(rng.normal(20000, 5000), 300, 60000)

    # Hardness
    data['Hardness'] = np.clip(rng.normal(196, 30), 47, 323)

    # Sulfate
    data['Sulfate'] = np.clip(rng.normal(333, 40), 129, 481)

    # Conductivity
    data['Conductivity'] = np.clip(rng.normal(426, 75), 180, 750)

    # ── Outcome: Disease Risk (influenced by water quality + confounders) ──
    # Potability proxy: combination of good parameters
    ph_good = ((data['ph'] >= 6.5) & (data['ph'] <= 8.5)).astype(float)
    turb_good = (data['Turbidity'] < 4.5).astype(float)
    chlor_good = ((data['Chloramines'] >= 2.0) & (data['Chloramines'] <= 6.0)).astype(float)
    oc_good = (data['Organic_carbon'] < 15.0).astype(float)

    potability_score = (0.25 * ph_good + 0.25 * turb_good +
                        0.20 * chlor_good + 0.20 * oc_good +
                        0.10 * rng.uniform(0, 1, n_samples))

    # Disease risk is higher with:
    # - Poor water quality (low potability)
    # - Wet season (SeasonalFactor=1)
    # - Poor sanitation
    # - High population density
    risk = (
        0.4 * (1 - potability_score) +
        0.2 * data['SeasonalFactor'] +
        0.2 * (1 - data['SanitationLevel'] / 2) +
        0.1 * np.log(data['PopulationDensity']) / 10 +
        0.1 * rng.normal(0, 0.1, n_samples)
    )
    data['DiseaseRisk'] = np.clip(risk, 0.0, 1.0)

    # Binary treatment flag: good water quality (for causal estimation)
    data['GoodWaterQuality'] = (potability_score >= 0.6).astype(int)

    df = pd.DataFrame(data)
    return df


class CausalAnalyzer:
    """
    Performs causal analysis to answer counterfactual questions
    about water quality interventions.
    """

    def __init__(self):
        self.data = None
        self.model = None
        self.causal_estimate = None
        self.is_ready = False

    def load_or_generate_data(self):
        """Load or generate causal inference dataset."""
        self.data = generate_causal_dataset()
        self.is_ready = True
        return self

    def estimate_effect_of_water_quality(self):
        """
        Estimate the causal effect of good water quality on disease risk
        using DoWhy (if available) or propensity score matching.

        Returns:
            dict with causal effect estimate, confidence intervals, method used
        """
        if not self.is_ready:
            self.load_or_generate_data()

        df = self.data

        if DOWHY_AVAILABLE and len(df) > 100:
            return self._estimate_dowhy(df)
        else:
            return self._estimate_sklearn(df)

    def _estimate_dowhy(self, df):
        """Use DoWhy for causal estimation."""
        try:
            model = CausalModel(
                data=df,
                treatment='GoodWaterQuality',
                outcome='DiseaseRisk',
                common_causes=['SeasonalFactor', 'SanitationLevel', 'PopulationDensity'],
            )

            # Identify the causal effect
            identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)

            # Estimate using propensity score matching
            estimate = model.estimate_effect(
                identified_estimand,
                method_name='backdoor.propensity_score_matching',
                target_units='ate',
            )

            # Refutation: Add random common cause
            refutation = model.refute_estimate(
                identified_estimand, estimate,
                method_name='random_common_cause'
            )

            return {
                'method': 'DoWhy Causal Inference',
                'estimated_effect': float(estimate.value),
                'interpretation': (
                    f'Good water quality reduces disease risk by '
                    f'{abs(estimate.value)*100:.1f}% on average.'
                    if estimate.value < 0 else
                    f'Good water quality increases disease risk by '
                    f'{estimate.value*100:.1f}% on average (unexpected).'
                ),
                'refutation_p_value': float(refutation.new_effect),
                'target_units': 'ATE (Average Treatment Effect)',
            }

        except Exception as e:
            return {
                'method': f'DoWhy (error: {str(e)[:50]})',
                'estimated_effect': None,
                'interpretation': 'DoWhy estimation failed. See fallback below.',
                'fallback': self._estimate_sklearn_ate(df),
            }

    def _estimate_sklearn(self, df):
        """Use sklearn Random Forest for feature importance + partial dependence."""
        if not SKLEARN_AVAILABLE:
            return {'method': 'No ML library available', 'estimated_effect': None}

        feature_cols = ['ph', 'Turbidity', 'Chloramines', 'Organic_carbon',
                        'SeasonalFactor', 'SanitationLevel', 'PopulationDensity',
                        'Trihalomethanes']
        X = df[feature_cols].values
        y = df['DiseaseRisk'].values

        rf = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42)
        rf.fit(X, y)

        # Feature importance
        importance = pd.DataFrame({
            'feature': feature_cols,
            'importance': rf.feature_importances_
        }).sort_values('importance', ascending=False)

        # Partial dependence for key features
        pd_results = {}
        for feat_name in ['ph', 'Turbidity', 'Chloramines', 'SanitationLevel']:
            if feat_name in feature_cols:
                feat_idx = feature_cols.index(feat_name)
                try:
                    pd_values = partial_dependence(
                        rf, X, features=[feat_idx],
                        grid_resolution=20,
                        kind='average'
                    )
                    pd_results[feat_name] = {
                        'values': pd_values['values'][0].tolist(),
                        'average': pd_values['average'][0].tolist(),
                    }
                except Exception:
                    pass

        return {
            'method': 'Random Forest + Partial Dependence (DoWhy fallback)',
            'feature_importance': importance.head(8).to_dict('records'),
            'partial_dependence': pd_results,
            'interpretation': (
                'Top factors influencing disease risk: ' +
                ', '.join([f"{r['feature']} ({r['importance']:.1%})"
                          for _, r in importance.head(3).iterrows()])
            ),
        }

    def _estimate_sklearn_ate(self, df):
        """Simple ATE estimation using difference in means."""
        treated = df[df['GoodWaterQuality'] == 1]['DiseaseRisk'].mean()
        control = df[df['GoodWaterQuality'] == 0]['DiseaseRisk'].mean()
        ate = control - treated

        return {
            'method': 'Simple Difference-in-Means',
            'ate': float(ate),
            'mean_risk_good_water': float(treated),
            'mean_risk_poor_water': float(control),
            'interpretation': (
                f'Communities with good water quality have {ate*100:.1f}% '
                f'lower disease risk on average.'
            ),
        }

    def what_if_analysis(self, intervention_type, intervention_value):
        """
        Answer counterfactual: "What if we change X to Y?"

        Args:
            intervention_type: e.g., 'ph', 'Turbidity', 'Chloramines'
            intervention_value: Target value for the intervention

        Returns:
            dict with estimated impact on disease risk
        """
        if not self.is_ready:
            self.load_or_generate_data()

        df = self.data

        # Current average value
        if intervention_type not in df.columns:
            return {'error': f'Unknown feature: {intervention_type}'}

        current_mean = df[intervention_type].mean()
        current_risk = df['DiseaseRisk'].mean()

        # Estimate impact using partial dependence if available
        if SKLEARN_AVAILABLE:
            try:
                feature_cols = ['ph', 'Turbidity', 'Chloramines', 'Organic_carbon',
                                'SeasonalFactor', 'SanitationLevel', 'PopulationDensity',
                                'Trihalomethanes', 'Solids', 'Hardness']
                available = [f for f in feature_cols if f in df.columns]
                X = df[available].values
                y = df['DiseaseRisk'].values

                rf = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42)
                rf.fit(X, y)

                # Simulate the intervention
                X_intervention = X.copy()
                if intervention_type in available:
                    idx = available.index(intervention_type)
                    X_intervention[:, idx] = intervention_value

                    y_pred_current = rf.predict(X)
                    y_pred_intervention = rf.predict(X_intervention)

                    avg_impact = (y_pred_intervention - y_pred_current).mean()
                else:
                    avg_impact = 0

                change_pct = avg_impact / current_risk * 100 if current_risk > 0 else 0

                return {
                    'intervention': intervention_type,
                    'current_value': round(float(current_mean), 2),
                    'intervention_value': intervention_value,
                    'current_avg_risk': round(float(current_risk), 3),
                    'estimated_risk_change': round(float(avg_impact), 4),
                    'estimated_risk_change_pct': round(float(change_pct), 1),
                    'direction': 'DECREASE (beneficial)' if avg_impact < 0
                                 else 'INCREASE (harmful)' if avg_impact > 0
                                 else 'NO CHANGE',
                    'interpretation': (
                        f"Changing {intervention_type} from {current_mean:.1f} to "
                        f"{intervention_value} would {'reduce' if avg_impact < 0 else 'increase' if avg_impact > 0 else 'not change'} "
                        f"disease risk by approximately {abs(avg_impact)*100:.2f}% "
                        f"({abs(change_pct):.1f}% relative change)."
                    ),
                }

            except Exception as e:
                return {
                    'intervention': intervention_type,
                    'error': str(e),
                    'interpretation': f'Could not estimate effect of {intervention_type} intervention.',
                }

        return {'intervention': intervention_type, 'error': 'No ML library available'}

    def get_top_interventions(self, n_top=5):
        """
        Find the most impactful interventions by testing realistic changes
        to each water quality parameter.

        Returns:
            List of dicts sorted by estimated impact
        """
        if not self.is_ready:
            self.load_or_generate_data()

        # Realistic intervention targets for each parameter
        intervention_targets = {
            'ph': 7.0,              # Neutral pH
            'Turbidity': 2.0,       # Low turbidity (clear water)
            'Chloramines': 4.0,     # Moderate chloramines
            'Organic_carbon': 10.0, # Low organic carbon
            'Trihalomethanes': 40.0,# Low THMs
        }

        results = []
        for param, target in intervention_targets.items():
            if param in self.data.columns:
                result = self.what_if_analysis(param, target)
                if 'estimated_risk_change' in result and result['estimated_risk_change'] is not None:
                    results.append(result)

        results.sort(key=lambda x: x.get('estimated_risk_change', 0))
        return results[:n_top]

    def generate_causal_report(self):
        """Generate a comprehensive causal analysis report."""
        effect = self.estimate_effect_of_water_quality()
        interventions = self.get_top_interventions()

        return {
            'causal_effect': effect,
            'top_interventions': interventions,
            'dataset_size': len(self.data) if self.data is not None else 0,
            'features_analyzed': list(self.data.columns) if self.data is not None else [],
        }
