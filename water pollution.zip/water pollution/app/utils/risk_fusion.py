"""
risk_fusion.py
The core novel component: Risk Fusion Engine.
Combines Water Quality contamination probability with Symptom-based disease probability
into a single Outbreak Risk Index using a weighted scoring formula.

Outbreak_Risk_Score = (0.5 × Water_Contamination_Probability)
                     + (0.5 × Symptom_Disease_Probability)

Justification: Equal weighting as a simplifying assumption (see About page for discussion).
"""

import numpy as np
import pandas as pd


# ── Risk Thresholds ──
RISK_THRESHOLDS = {
    'LOW':    (0.0, 0.35),
    'MEDIUM': (0.35, 0.65),
    'HIGH':   (0.65, 1.0),
}

RISK_COLORS = {
    'LOW':    '#2ECC71',   # Green
    'MEDIUM': '#F1C40F',   # Yellow/Amber
    'HIGH':   '#E74C3C',   # Red
}

RISK_EMOJIS = {
    'LOW':    '🟢',
    'MEDIUM': '🟡',
    'HIGH':   '🔴',
}


def get_risk_level(score):
    """Classify a continuous risk score into LOW / MEDIUM / HIGH."""
    if score < 0.35:
        return 'LOW'
    elif score < 0.65:
        return 'MEDIUM'
    else:
        return 'HIGH'


def get_risk_color(score):
    """Get the color code for a risk score."""
    return RISK_COLORS[get_risk_level(score)]


def calculate_risk_score(water_prob, disease_prob, water_weight=0.5, disease_weight=0.5):
    """
    Calculate the combined Outbreak Risk Index.

    Parameters:
    - water_prob: Probability that water is NOT potable (contamination probability).
                  If water_potability_model outputs "potable" probability = 0.8,
                  then contamination probability = 1 - 0.8 = 0.2.
    - disease_prob: Probability that symptoms indicate a water-borne disease.
                    From the disease prediction model's confidence.
    - water_weight: Weight for water quality factor (default 0.5).
    - disease_weight: Weight for symptom factor (default 0.5).

    Returns:
    - combined_score: Float between 0 and 1.
    - risk_level: 'LOW', 'MEDIUM', or 'HIGH'.
    - details: dict with component breakdown for explainability.
    """
    # Clamp inputs
    water_prob = np.clip(water_prob, 0.0, 1.0)
    disease_prob = np.clip(disease_prob, 0.0, 1.0)

    combined = (water_weight * water_prob) + (disease_weight * disease_prob)
    combined = np.clip(combined, 0.0, 1.0)

    risk_level = get_risk_level(combined)

    details = {
        'water_contamination_prob': round(water_prob, 4),
        'disease_probability': round(disease_prob, 4),
        'water_weight': water_weight,
        'disease_weight': disease_weight,
        'combined_score': round(combined, 4),
        'risk_level': risk_level,
    }

    return combined, risk_level, details


def calculate_adaptive_risk(water_prob, disease_prob, case_reports=None, population=None):
    """
    Adaptive risk calculation that considers additional epidemiological factors.
    This is an enhanced version for future work.

    Factors:
    - Case rate relative to population (attack rate)
    - Temporal trend (if multiple data points available)
    - Severity of reported symptoms
    """
    base_score, risk_level, details = calculate_risk_score(water_prob, disease_prob)

    adjustments = []

    # Factor 1: Attack rate adjustment
    if case_reports is not None and population is not None and population > 0:
        attack_rate = case_reports / population
        if attack_rate > 0.05:  # More than 5% affected
            base_score = min(1.0, base_score + 0.10)
            adjustments.append('High attack rate (+0.10)')
        elif attack_rate > 0.02:
            base_score = min(1.0, base_score + 0.05)
            adjustments.append('Moderate attack rate (+0.05)')

    # Factor 2: Disease severity adjustment (for cholera/dysentery)
    # (Handled externally by passing adjusted disease_prob)

    details['adjustments'] = adjustments
    details['adjusted_score'] = round(base_score, 4)
    details['risk_level'] = get_risk_level(base_score)

    return base_score, get_risk_level(base_score), details


# ── Disease severity multipliers ──
DISEASE_SEVERITY = {
    'Cholera': 1.3,           # Most severe — rapid dehydration
    'Dysentery': 1.2,         # Severe — bloody stool
    'Typhoid': 1.15,          # Severe — prolonged fever
    'Hepatitis_A': 1.1,       # Moderate — liver involvement
    'Gastroenteritis': 1.0,   # Moderate
    'Diarrheal_Disease': 0.9, # Mild to moderate
}


def apply_severity_weight(disease_prob, predicted_disease):
    """
    Adjust disease probability based on the severity of the predicted disease.
    """
    multiplier = DISEASE_SEVERITY.get(predicted_disease, 1.0)
    return np.clip(disease_prob * multiplier, 0.0, 1.0)


def get_risk_recommendation(risk_level, predicted_disease=None, water_safe=None):
    """
    Generate contextual recommendations based on risk level.
    """
    recommendations = {
        'LOW': {
            'title': '✅ Normal Conditions',
            'actions': [
                'Routine monitoring continues',
                'No immediate action required',
                'Maintain standard water treatment protocols',
            ],
            'public_health': 'No public health advisory needed. Continue regular hygiene practices.',
        },
        'MEDIUM': {
            'title': '⚠️ Caution Advised',
            'actions': [
                'Increased water quality testing recommended',
                'Notify local health workers',
                'Boil water before drinking as precaution',
                'Monitor for additional symptom reports',
            ],
            'public_health': 'Advisory: Consider boiling drinking water. Monitor children and elderly for symptoms.',
        },
        'HIGH': {
            'title': '🚨 URGENT: Outbreak Risk Detected',
            'actions': [
                'IMMEDIATELY notify district health officer',
                'Issue boil-water advisory to all residents',
                'Deploy emergency water treatment',
                'Activate community health surveillance',
                'Prepare medical response for potential cases',
                'Restrict use of contaminated water sources',
            ],
            'public_health': 'EMERGENCY: High risk of water-borne disease outbreak. Boil all water. Report any symptoms to health authorities immediately.',
        },
    }

    rec = recommendations.get(risk_level, recommendations['LOW'])

    # Disease-specific additions
    if predicted_disease and risk_level in ('MEDIUM', 'HIGH'):
        if predicted_disease == 'Cholera':
            rec['actions'].append('Oral rehydration solution stations recommended')
            rec['public_health'] += ' ⚡ Cholera suspected — rapid dehydration risk. Ensure ORS availability.'
        elif predicted_disease == 'Typhoid':
            rec['actions'].append('Monitor for prolonged fever cases')
            rec['public_health'] += ' ⚡ Typhoid suspected — monitor for sustained fever cases.'
        elif predicted_disease == 'Hepatitis_A':
            rec['actions'].append('Vaccination assessment for close contacts')
            rec['public_health'] += ' ⚡ Hepatitis A suspected — vaccination may be recommended for contacts.'

    return rec
