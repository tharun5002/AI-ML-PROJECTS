"""
Aarogya Jal — Utility modules for the Smart Community Health Monitoring System.
"""
