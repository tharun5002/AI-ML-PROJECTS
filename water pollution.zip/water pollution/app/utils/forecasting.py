"""
forecasting.py
ENHANCEMENT 1: Time-Series Forecasting Module
Uses Prophet (Meta) to forecast outbreak risk scores 14 days into the future.
Turns the system from REACTIVE (monitoring current risk) to PREDICTIVE (anticipating outbreaks).

Key capabilities:
- Train Prophet model on historical risk data per location
- Generate 14-day forecast with confidence intervals
- Detect emerging upward trends (early warning)
- Return structured forecast data for dashboard visualization
"""

import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Prophet is optional — provides best results
try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except ImportError:
    PROPHET_AVAILABLE = False

try:
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import mean_absolute_error, mean_squared_error
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


class RiskForecaster:
    """
    Forecasts outbreak risk scores using Prophet (or linear regression fallback).
    Trained per-location on historical timeline data.
    """

    def __init__(self, forecast_days=14, uncertainty_interval=0.80):
        """
        Args:
            forecast_days: Number of days to forecast into future (default 14)
            uncertainty_interval: Prophet uncertainty interval width (default 0.80 = 80% CI)
        """
        self.forecast_days = forecast_days
        self.uncertainty_interval = uncertainty_interval
        self.model = None
        self.fallback_model = None
        self.is_trained = False
        self.training_metrics = {}
        self.location = None

    def _prepare_data(self, timeline_df, location_name):
        """Extract and prepare time series for a specific location."""
        loc_data = timeline_df[timeline_df['Location'] == location_name].copy()
        if loc_data.empty:
            raise ValueError(f"No data found for location: {location_name}")

        loc_data['Date'] = pd.to_datetime(loc_data['Date'])
        loc_data = loc_data.sort_values('Date')

        # Prophet requires columns: ds (date) and y (value)
        prophet_df = pd.DataFrame({
            'ds': loc_data['Date'],
            'y': loc_data['Risk_Score'].values,
        })

        # Also keep cases for reference
        self._cases = loc_data[['Date', 'Reported_Cases']].copy()

        return prophet_df

    def _train_fallback(self, prophet_df):
        """Train a simple linear regression as Prophet fallback."""
        if not SKLEARN_AVAILABLE:
            return

        X = np.arange(len(prophet_df)).reshape(-1, 1)
        y = prophet_df['y'].values

        self.fallback_model = LinearRegression()
        self.fallback_model.fit(X, y)

        # Evaluate
        y_pred = self.fallback_model.predict(X)
        mae = mean_absolute_error(y, y_pred)
        rmse = np.sqrt(mean_squared_error(y, y_pred))

        self.training_metrics = {
            'method': 'Linear Regression (Fallback)',
            'mae': float(mae),
            'rmse': float(rmse),
            'r2': float(self.fallback_model.score(X, y)),
        }

    def _predict_fallback(self, n_future_days):
        """Generate forecast using fallback model."""
        last_idx = len(self._prophet_df)
        future_X = np.arange(last_idx, last_idx + n_future_days).reshape(-1, 1)
        y_pred = self.fallback_model.predict(future_X)
        y_pred = np.clip(y_pred, 0.0, 1.0)

        # Simple confidence intervals (± historical std)
        residuals_std = np.std(self._prophet_df['y'].values - 
                                self.fallback_model.predict(
                                    np.arange(len(self._prophet_df)).reshape(-1, 1))
                                )
        last_date = self._prophet_df['ds'].iloc[-1]
        future_dates = pd.date_range(start=last_date + timedelta(days=1), periods=n_future_days)

        forecast_df = pd.DataFrame({
            'ds': future_dates,
            'yhat': y_pred,
            'yhat_lower': np.clip(y_pred - 1.96 * residuals_std, 0.0, 1.0),
            'yhat_upper': np.clip(y_pred + 1.96 * residuals_std, 0.0, 1.0),
        })
        return forecast_df

    def train(self, timeline_df, location_name):
        """
        Train forecasting model on historical data for a location.

        Args:
            timeline_df: DataFrame with columns [Date, Location, Risk_Score, ...]
            location_name: Name of the location to train for
        """
        self.location = location_name
        prophet_df = self._prepare_data(timeline_df, location_name)
        self._prophet_df = prophet_df

        if PROPHET_AVAILABLE and len(prophet_df) >= 14:
            # ── Train Prophet Model ──
            self.model = Prophet(
                interval_width=self.uncertainty_interval,
                yearly_seasonality=False,
                weekly_seasonality=True,
                daily_seasonality=False,
                changepoint_prior_scale=0.05,
                seasonality_prior_scale=10.0,
            )

            # Add monthly seasonality for longer trends
            self.model.add_seasonality(name='monthly', period=30.5, fourier_order=5)

            self.model.fit(prophet_df)

            # Training metrics: in-sample MAE
            forecast_train = self.model.predict(prophet_df)
            mae = mean_absolute_error(prophet_df['y'].values, forecast_train['yhat'].values)
            rmse = np.sqrt(mean_squared_error(prophet_df['y'].values, forecast_train['yhat'].values))

            self.training_metrics = {
                'method': 'Prophet',
                'mae': float(mae),
                'rmse': float(rmse),
                'training_days': len(prophet_df),
            }
            self.is_trained = True
            print(f'[FORECAST] Prophet trained for {location_name} — MAE: {mae:.4f}')
        else:
            # ── Fallback: Linear Regression ──
            reason = 'Prophet not installed' if not PROPHET_AVAILABLE else 'insufficient data'
            print(f'[FORECAST] Using fallback for {location_name} ({reason})')
            self._train_fallback(prophet_df)
            self.is_trained = True

        return self

    def predict(self, n_days=None):
        """
        Generate forecast for the next N days.

        Args:
            n_days: Number of days to forecast (default: self.forecast_days)

        Returns:
            DataFrame with columns: ds, yhat, yhat_lower, yhat_upper, trend_direction
        """
        if not self.is_trained:
            raise RuntimeError("Model not trained. Call train() first.")

        n_days = n_days or self.forecast_days

        if self.model is not None and PROPHET_AVAILABLE:
            # Prophet prediction
            future = self.model.make_future_dataframe(periods=n_days, include_history=False)
            forecast = self.model.predict(future)
            result = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].copy()
        else:
            # Fallback prediction
            result = self._predict_fallback(n_days)

        # Add trend direction
        result['trend_direction'] = self._detect_trend(result)

        # Add days_since_today
        today = pd.Timestamp.now().normalize()
        result['days_ahead'] = (result['ds'] - today).dt.days

        return result

    def _detect_trend(self, forecast_df):
        """Detect if forecasted trend is rising, falling, or stable."""
        if len(forecast_df) < 2:
            return ['stable'] * len(forecast_df)

        first_half = forecast_df['yhat'].iloc[:len(forecast_df)//2].mean()
        second_half = forecast_df['yhat'].iloc[len(forecast_df)//2:].mean()

        threshold = 0.03
        if second_half - first_half > threshold:
            return ['rising'] * len(forecast_df)
        elif first_half - second_half > threshold:
            return ['falling'] * len(forecast_df)
        else:
            return ['stable'] * len(forecast_df)

    def get_early_warning(self, forecast_df):
        """
        Check if forecast indicates an emerging outbreak risk.

        Returns:
            dict with warning_level, peak_risk, days_to_peak, message
        """
        if forecast_df.empty:
            return {'warning_level': 'none', 'message': 'No forecast data available.'}

        max_risk = forecast_df['yhat'].max()
        end_risk = forecast_df['yhat'].iloc[-1]
        start_risk = forecast_df['yhat'].iloc[0]
        rise = end_risk - start_risk

        # Find when risk crosses HIGH threshold
        high_dates = forecast_df[forecast_df['yhat'] >= 0.65]['ds']
        days_to_high = (high_dates.iloc[0] - pd.Timestamp.now()).days if not high_dates.empty else None

        if max_risk >= 0.65 or rise > 0.15:
            warning_level = 'high'
            message = f'🚨 HIGH ALERT: Risk forecast to reach {max_risk:.0%} in {days_to_high or "?"} days!'
        elif max_risk >= 0.45 or rise > 0.08:
            warning_level = 'medium'
            message = f'⚠️ CAUTION: Risk trending upward. Forecast peak: {max_risk:.0%}.'
        else:
            warning_level = 'low'
            message = f'✅ Forecast stable. Peak risk: {max_risk:.0%}. No immediate concern.'

        return {
            'warning_level': warning_level,
            'peak_risk': float(max_risk),
            'end_risk': float(end_risk),
            'risk_rise': float(rise),
            'days_to_high_threshold': days_to_high,
            'message': message,
        }

    def get_forecast_data_for_chart(self, forecast_df, historical_df=None):
        """
        Prepare combined historical + forecast data for Plotly charting.

        Args:
            forecast_df: Output from predict()
            historical_df: Original timeline data for the location

        Returns:
            dict with historical and forecast DataFrames ready for Plotly
        """
        chart_data = {
            'forecast': forecast_df,
        }

        if historical_df is not None:
            loc_data = historical_df[
                historical_df['Location'] == self.location
            ].copy() if 'Location' in historical_df.columns else historical_df.copy()

            loc_data['Date'] = pd.to_datetime(loc_data['Date'])
            chart_data['historical'] = loc_data

        return chart_data


def get_multi_location_forecasts(timeline_df, locations=None, forecast_days=14):
    """
    Generate forecasts for multiple locations at once.

    Args:
        timeline_df: Full timeline DataFrame
        locations: List of location names (default: all unique locations)
        forecast_days: Days to forecast for each

    Returns:
        dict mapping location_name -> forecast DataFrame
    """
    if timeline_df is None or timeline_df.empty:
        return {}

    if locations is None:
        locations = timeline_df['Location'].unique().tolist()

    forecasts = {}
    for loc in locations:
        try:
            forecaster = RiskForecaster(forecast_days=forecast_days)
            forecaster.train(timeline_df, loc)
            forecast = forecaster.predict()
            early_warning = forecaster.get_early_warning(forecast)
            forecasts[loc] = {
                'forecast': forecast,
                'forecaster': forecaster,
                'early_warning': early_warning,
            }
        except Exception as e:
            print(f'[FORECAST] Error forecasting for {loc}: {e}')
            forecasts[loc] = None

    return forecasts


def format_forecast_summary(forecast_data):
    """
    Format forecast results into a human-readable summary.

    Args:
        forecast_data: Output from get_early_warning()

    Returns:
        HTML/Markdown string for dashboard display
    """
    if not forecast_data:
        return '<div class="forecast-empty">No forecast data available.</div>'

    level = forecast_data.get('warning_level', 'none')
    colors = {'high': '#E74C3C', 'medium': '#F1C40F', 'low': '#2ECC71', 'none': '#8A8272'}
    emojis = {'high': '🔴', 'medium': '🟡', 'low': '🟢', 'none': '⚪'}
    labels = {'high': 'HIGH ALERT', 'medium': 'CAUTION', 'low': 'STABLE', 'none': 'N/A'}

    color = colors.get(level, '#8A8272')
    emoji = emojis.get(level, '⚪')
    label = labels.get(level, 'N/A')

    return f"""
    <div class="forecast-summary" style="border-left: 4px solid {color}; padding: 12px 16px; 
         background: rgba(255,255,255,0.05); border-radius: 8px; margin: 8px 0;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span style="font-size: 1.2rem;">{emoji}</span>
            <strong style="color: {color};">14-Day Forecast: {label}</strong>
        </div>
        <div style="font-size: 0.85rem; color: #C9BFA9;">
            {forecast_data.get('message', '')}
        </div>
        <div style="font-size: 0.8rem; color: #8A8272; margin-top: 6px;">
            Peak risk: {forecast_data.get('peak_risk', 0):.0%} | 
            Rise: {forecast_data.get('risk_rise', 0):.1%}
            {' | 🔴 HIGH in ~' + str(forecast_data.get('days_to_high_threshold', '?')) + ' days' 
             if forecast_data.get('days_to_high_threshold') is not None else ''}
        </div>
    </div>
    """
