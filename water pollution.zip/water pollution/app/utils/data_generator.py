"""
data_generator.py
Generates synthetic datasets for water quality monitoring and disease symptom reporting.
Since real datasets require Kaggle downloads, this module creates realistic synthetic data
that mirrors the distribution and relationships found in real-world water quality and
epidemiological data.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import os

# ── Seeded RNG for reproducibility ──
RNG = np.random.default_rng(42)

# ── Water Quality Feature Distributions (based on real water potability dataset) ──
WATER_FEATURES = {
    'ph':                {'min': 0.0,   'max': 14.0,   'mean': 7.08,  'std': 1.59},
    'Hardness':          {'min': 47.0,  'max': 323.0,  'mean': 196.0, 'std': 32.9},
    'Solids':            {'min': 320.0, 'max': 61227.0,'mean': 22000,'std': 9000},
    'Chloramines':       {'min': 0.4,   'max': 13.0,   'mean': 4.12,  'std': 1.78},
    'Sulfate':           {'min': 129.0, 'max': 481.0,  'mean': 333.0, 'std': 41.0},
    'Conductivity':      {'min': 180.0, 'max': 753.0,  'mean': 426.0, 'std': 80.0},
    'Organic_carbon':    {'min': 2.2,   'max': 28.0,   'mean': 14.3,  'std': 3.3},
    'Trihalomethanes':   {'min': 0.7,   'max': 124.0,  'mean': 66.6,  'std': 16.2},
    'Turbidity':         {'min': 1.5,   'max': 6.5,    'mean': 4.0,   'std': 0.78},
}

# ── Water-borne diseases and their symptom profiles ──
WATER_BORNE_DISEASES = {
    'Typhoid': {
        'symptoms': ['Fever', 'Fatigue', 'Headache', 'Abdominal_Pain', 'Constipation', 'Loss_of_Appetite'],
        'baseline_fever': 0.95,
        'contamination_link': 0.85,
    },
    'Cholera': {
        'symptoms': ['Diarrhea', 'Vomiting', 'Dehydration', 'Muscle_Cramps', 'Nausea', 'Weakness'],
        'baseline_fever': 0.30,
        'contamination_link': 0.95,
    },
    'Gastroenteritis': {
        'symptoms': ['Diarrhea', 'Vomiting', 'Nausea', 'Abdominal_Pain', 'Fever', 'Fatigue'],
        'baseline_fever': 0.60,
        'contamination_link': 0.80,
    },
    'Hepatitis_A': {
        'symptoms': ['Fatigue', 'Fever', 'Jaundice', 'Dark_Urine', 'Loss_of_Appetite', 'Abdominal_Pain'],
        'baseline_fever': 0.70,
        'contamination_link': 0.75,
    },
    'Dysentery': {
        'symptoms': ['Diarrhea', 'Bloody_Stool', 'Fever', 'Abdominal_Pain', 'Nausea', 'Fatigue'],
        'baseline_fever': 0.75,
        'contamination_link': 0.85,
    },
    'Diarrheal_Disease': {
        'symptoms': ['Diarrhea', 'Vomiting', 'Dehydration', 'Nausea', 'Abdominal_Pain', 'Fever'],
        'baseline_fever': 0.50,
        'contamination_link': 0.90,
    },
}

# Flatten unique symptoms across all diseases
ALL_WATER_BORNE_SYMPTOMS = sorted(set(
    sym for disease in WATER_BORNE_DISEASES.values() for sym in disease['symptoms']
))

DISEASE_NAMES = sorted(WATER_BORNE_DISEASES.keys())


# ── Simulated Location Data ──
LOCATIONS = [
    {'name': 'Greenfield Village',  'lat': 28.6139,  'lon': 77.2090,  'population': 1200},
    {'name': 'Riverside Ward',      'lat': 19.0760,  'lon': 72.8777,  'population': 2500},
    {'name': 'Lakeside Colony',     'lat': 12.9716,  'lon': 77.5946,  'population': 800},
    {'name': 'Valley Nagar',        'lat': 26.9124,  'lon': 75.7873,  'population': 1800},
    {'name': 'Hilltop Settlement',  'lat': 18.5204,  'lon': 73.8567,  'population': 600},
    {'name': 'East Bank Township',  'lat': 22.5726,  'lon': 88.3639,  'population': 3200},
    {'name': 'North Delta Village', 'lat': 25.5941,  'lon': 85.1376,  'population': 950},
    {'name': 'Coastal Union',       'lat': 15.2993,  'lon': 74.1240,  'population': 1400},
]


def _clip_to_range(values, feature_name):
    """Clip generated values to realistic ranges."""
    config = WATER_FEATURES[feature_name]
    return np.clip(values, config['min'], config['max'])


def generate_water_quality_data(n_samples=3200, missing_fraction=0.05):
    """
    Generate synthetic water quality dataset.
    Potability label is derived from a known ground-truth function
    involving pH, turbidity, chloramines, and coliform presence.
    """
    data = {}
    for feat, config in WATER_FEATURES.items():
        # Sample from truncated normal distribution
        vals = RNG.normal(loc=config['mean'], scale=config['std'], size=n_samples)
        vals = _clip_to_range(vals, feat)
        data[feat] = vals

    df = pd.DataFrame(data)

    # ── Potability ground truth (simulated domain logic) ──
    # Good pH range: 6.5-8.5
    ph_good = (df['ph'] >= 6.5) & (df['ph'] <= 8.5)
    # Low turbidity is good
    turbidity_good = df['Turbidity'] < 4.5
    # Moderate chloramines is good
    chloramines_good = (df['Chloramines'] >= 2.0) & (df['Chloramines'] <= 6.0)
    # Lower organic carbon is better
    organic_good = df['Organic_carbon'] < 15.0
    # Lower trihalomethanes is better
    tri_good = df['Trihalomethanes'] < 80.0
    # Moderate solids
    solids_good = (df['Solids'] > 500) & (df['Solids'] < 40000)

    # Potability score from multiple factors
    score = (ph_good.astype(int) * 0.20 +
             turbidity_good.astype(int) * 0.20 +
             chloramines_good.astype(int) * 0.15 +
             organic_good.astype(int) * 0.15 +
             tri_good.astype(int) * 0.15 +
             solids_good.astype(int) * 0.15)

    # Add noise to make it realistic
    noise = RNG.normal(0, 0.15, n_samples)
    score = score + noise

    df['Potability'] = (score >= 0.55).astype(int)

    # Add some missing values (as seen in real datasets)
    missing_cols = ['ph', 'Sulfate', 'Trihalomethanes']
    for col in missing_cols:
        missing_idx = RNG.choice(n_samples, size=int(n_samples * missing_fraction), replace=False)
        df.loc[missing_idx, col] = np.nan

    return df


def generate_disease_symptom_data(n_samples=5000, target_diseases=None):
    """
    Generate synthetic disease-symptom data for water-borne diseases.
    Creates a multi-label symptom matrix with disease labels.
    """
    if target_diseases is None:
        target_diseases = DISEASE_NAMES

    n_diseases = len(target_diseases)
    samples_per_class = n_samples // n_diseases

    rows = []
    for i, disease in enumerate(target_diseases):
        disease_info = WATER_BORNE_DISEASES[disease]
        active_symptoms = disease_info['symptoms']
        inactive_symptoms = [s for s in ALL_WATER_BORNE_SYMPTOMS if s not in active_symptoms]

        for _ in range(samples_per_class):
            row = {s: 0 for s in ALL_WATER_BORNE_SYMPTOMS}

            # Active symptoms appear with high probability
            for sym in active_symptoms:
                if disease == 'Cholera':
                    prob = 0.92 if sym in ['Diarrhea', 'Vomiting', 'Dehydration'] else 0.75
                elif disease == 'Typhoid':
                    prob = 0.95 if sym in ['Fever', 'Fatigue'] else 0.70
                elif disease == 'Hepatitis_A':
                    prob = 0.90 if sym in ['Fatigue', 'Fever', 'Jaundice'] else 0.65
                else:
                    prob = 0.80
                row[sym] = 1 if RNG.random() < prob else 0

            # Inactive symptoms appear with low probability (noise)
            for sym in inactive_symptoms:
                row[sym] = 1 if RNG.random() < 0.05 else 0

            # Add fever baseline (most water-borne diseases have fever component)
            if 'Fever' in active_symptoms:
                if RNG.random() < 0.05:  # 5% chance fever absent even in febrile diseases
                    row['Fever'] = 0

            row['Disease'] = disease
            rows.append(row)

    df = pd.DataFrame(rows)
    # Shuffle the dataset
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


def generate_simulated_timeline(days=60, locations=None):
    """
    Generate a simulated timeline of historical data for trend visualization.
    Creates daily risk scores, alert counts, and case reports per location.
    """
    if locations is None:
        locations = LOCATIONS

    dates = pd.date_range(end=pd.Timestamp.now(), periods=days, freq='D')
    records = []

    for location in locations:
        # Base risk level for each location (some are naturally riskier)
        base_risk = RNG.uniform(0.15, 0.55)

        for date in dates:
            # Add temporal trends + noise
            day_noise = RNG.normal(0, 0.08)
            # Slight upward trend over time (simulating seasonal increase)
            trend = (date - dates[0]).days / days * 0.12
            risk = np.clip(base_risk + day_noise + trend, 0.0, 1.0)

            # Cases correlate with risk
            population_factor = location['population'] / 1000
            cases = max(0, int(RNG.poisson(risk * 3 * population_factor)))

            # Determine risk level
            if risk < 0.35:
                level = 'LOW'
            elif risk < 0.65:
                level = 'MEDIUM'
            else:
                level = 'HIGH'

            records.append({
                'Date': date,
                'Location': location['name'],
                'Latitude': location['lat'],
                'Longitude': location['lon'],
                'Population': location['population'],
                'Risk_Score': round(risk, 3),
                'Risk_Level': level,
                'Reported_Cases': cases,
                'Active_Alerts': 1 if risk > 0.50 else 0,
            })

    df = pd.DataFrame(records)
    return df


def generate_alert_log(timeline_df):
    """Generate alert log entries from high-risk periods in the timeline."""
    high_risk = timeline_df[timeline_df['Risk_Score'] >= 0.45].copy()
    high_risk = high_risk.sample(frac=0.3, random_state=42).head(50)

    alert_reasons = [
        'Elevated turbidity detected',
        'pH level outside safe range',
        'Increased diarrhea case reports',
        'Chloramine level anomaly',
        'Fever cluster reported',
        'Multiple symptom reports in community',
        'Organic carbon above threshold',
        'Coliform contamination suspected',
        'Trihalomethane level spike',
        'Combined risk score escalation',
    ]

    alerts = []
    for _, row in high_risk.iterrows():
        reason = RNG.choice(alert_reasons, size=RNG.integers(1, 3), replace=False)
        alerts.append({
            'Timestamp': row['Date'] + pd.Timedelta(hours=RNG.integers(6, 22)),
            'Location': row['Location'],
            'Risk_Score': row['Risk_Score'],
            'Risk_Level': row['Risk_Level'],
            'Trigger': '; '.join(reason),
            'Cases_Reported': row['Reported_Cases'],
        })

    df = pd.DataFrame(alerts)
    df.sort_values('Timestamp', ascending=False, inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df


def save_datasets(data_dir='data'):
    """Generate and save all datasets to disk."""
    os.makedirs(data_dir, exist_ok=True)

    print("[GEN] Generating water quality dataset...")
    water_df = generate_water_quality_data()
    water_df.to_csv(f'{data_dir}/water_potability.csv', index=False)
    print(f"   -> {len(water_df)} samples, {water_df['Potability'].value_counts().to_dict()}")

    print("\n[GEN] Generating disease symptom dataset...")
    disease_df = generate_disease_symptom_data()
    disease_df.to_csv(f'{data_dir}/disease_symptoms.csv', index=False)
    print(f"   -> {len(disease_df)} samples, {disease_df['Disease'].value_counts().to_dict()}")

    print("\n[GEN] Generating simulated timeline...")
    timeline_df = generate_simulated_timeline()
    timeline_df.to_csv(f'{data_dir}/simulated_timeline.csv', index=False)
    print(f"   -> {len(timeline_df)} records across {timeline_df['Location'].nunique()} locations")

    print("\n[GEN] Generating alert log...")
    alerts_df = generate_alert_log(timeline_df)
    alerts_df.to_csv(f'{data_dir}/alert_log.csv', index=False)
    print(f"   -> {len(alerts_df)} alert entries")

    print("\n[DONE] All datasets saved to", data_dir)
    return water_df, disease_df, timeline_df, alerts_df


if __name__ == '__main__':
    save_datasets()
